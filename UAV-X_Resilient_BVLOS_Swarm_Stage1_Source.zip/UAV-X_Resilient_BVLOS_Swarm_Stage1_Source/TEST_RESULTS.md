# Test Results

Suite `20260925_010007`, generated 2026-09-25T01:43:45 by `./scripts/run_tests.sh`.

**22 PASS, 0 FAIL, 0 NOT RUN** (of 22).

Environment: os: Ubuntu 26.04.1 LTS, kernel: 6.18.33.2-microsoft-standard-WSL2, ros: lyrical, gazebo: 10.5.0, px4: v1.18.0-rc1, python: 3.14.4

A test is PASS only if every execution of it passed. Evidence comes from the recorded run
data (results/runs/<run>/summary.json, events.json, CSVs) or the live checks.

| Test | Status | Evidence |
|---|---|---|
| Unit tests (core algorithms) | **PASS** | *tests/unit*: 35/35 unit tests passed |
| TEST 1: Single UAV PX4 startup | **PASS** | *tests/sim/single_uav*: heartbeat from sysid 1 on udp 14540 after 0.4s, local_position_valid=True, prearm_ok=True, mode=AUTO.LOITER |
| TEST 2: Single UAV takeoff | **PASS** | *tests/sim/single_uav*: armed=True mode=OFFBOARD altitude=14.60 m (target 15.0 m) in 8.9s |
| TEST 3: Single UAV waypoint | **PASS** | *tests/sim/single_uav*: WP1 reached in 3.0s (final error 0.06 m); WP2 reached in 3.0s (final error 0.18 m) |
| TEST 4: Single UAV landing | **PASS** | *tests/sim/single_uav*: landed_state=1 armed=False mode=OFFBOARD altitude=-0.03 m after 19.6s |
| TEST 5: Four UAV startup | **PASS** | *tests/sim/four_uav*: uav1: sysid=1 udp=14540 hb=True prearm=True gz_model=x500_0@(15.0,0.0) home=(15.0,0.0) foreign_sysids=none / uav2: sysid=2 udp=14541 hb=True prearm=True gz_model=x500_1@(15.0,-20.0) home=(15.0,-20.0) foreign_sysids=none / uav3: sysid=3 udp=14542 hb=True prearm=True gz_model=x500_2@(15.0,20.0) home=(15.0,20.0) foreign_sysids=none / uav4: sysid=4 udp=14543 hb=True prearm=True gz_model=x500_3@(15.0,40.0) home=(15.0,40.0) foreign_sysids=none |
| TEST 6: Four UAV independent control | **PASS** | *tests/sim/four_uav*: all airborne=True / uav1: world dx=+0.04 dy=-0.05 alt=10.0m (cmd 10m) held ok / uav2: world dx=+14.88 dy=-0.02 alt=14.0m (cmd 14m) MOVED ok / uav3: world dx=+0.02 dy=+0.06 alt=18.0m (cmd 18m) held ok / uav4: world dx=+0.02 dy=-0.04 alt=22.0m (cmd 22m) held ok |
| TEST 7: ROS communication | **PASS** | *tests/sim/ros_live_check.py*: live graph: 8/8 expected nodes present; 31/31 topics delivered messages <br> *scenario nominal (results/runs/20260925_010224_nominal)*: onboard /uavN/state received from ['uav1', 'uav2', 'uav3', 'uav4'] (expected 4) |
| TEST 8: GCS communication | **PASS** | *scenario nominal (results/runs/20260925_010224_nominal)*: UAV->GCS telemetry delivered 1502/1618, GCS->UAV beacons 747/812, survey reports received 6 |
| TEST 9: UAV-to-UAV communication | **PASS** | *scenario nominal (results/runs/20260925_010224_nominal)*: UAV<->UAV beacons delivered 4442; reports forwarded through other UAVs 6 |
| TEST 10: Multi-hop routing | **PASS** | *scenario nominal (results/runs/20260925_010224_nominal)*: max route length 3 hops (e.g. ['uav3->uav1->uav2->gcs', 'uav4->uav3->uav2->gcs']); max hops of a delivered report 3 |
| TEST 11: Relay selection | **PASS** | *scenario nominal (results/runs/20260925_010224_nominal)*: initial relay uav2 selected by score: Initial relay scores: UAV1=0.66, UAV2=0.66, UAV3=0.64, UAV4=0.66 |
| TEST 12: Relay failure | **PASS** | *scenario scenario_failure (results/runs/20260925_010619_scenario_failure)*: relay uav2 failed at mission t=65.45s; heartbeat loss detected after 3.1s; new relay uav1 (PEER_ELECTED (UAV elected itself as brid) after 13.7s; network reconfigured after 16.6s; mission MISSION_COMPLETE |
| TEST 13: Communication outage | **PASS** | *scenario scenario_comm_outage (results/runs/20260925_011103_scenario_comm_outage)*: relay uav2 degraded 5%->20%->50%->100%; degradation detected before total loss: ['LINK_WARNING', 'LINK_WARNING', 'LINK_DEGRADED']; relay replaced by uav4 at mission t=100.0s (100% loss at 116.46s); mission MISSION_COMPLETE |
| TEST 14: Packet loss | **PASS** | *scenario scenario_packet_loss (results/runs/20260925_011505_scenario_packet_loss)*: telemetry PDR under 15% injected loss = 0.7354; report packets delivered 9/20 (retransmissions until ACK); unique reports at GCS 6/6; mission MISSION_COMPLETE |
| TEST 15: New priority PoI | **PASS** | *scenario scenario_priority (results/runs/20260925_011857_scenario_priority)*: POI7 (CRITICAL) announced at t=65.13s, assigned to uav4 after 0.4s, completed at t=88.0s; mission MISSION_COMPLETE |
| TEST 16: Low battery | **PASS** | *scenario scenario_battery (results/runs/20260925_012254_scenario_battery)*: uav1: battery fault at t=65.51s; RTH at t=101.61s; landed at home=True with lowest battery 23.4% (critical 15.0%); tasks released 1; mission MISSION_COMPLETE |
| TEST 17: Return-to-home | **PASS** | *scenario nominal (results/runs/20260925_010224_nominal)*: uav1 landed at (14.5, -0.5) home=True; uav2 landed at (14.7, -20.0) home=True; uav3 landed at (14.7, 19.7) home=True; uav4 landed at (14.7, 40.1) home=True <br> *scenario scenario_battery (results/runs/20260925_012254_scenario_battery)*: uav1 landed at (14.7, -0.2) home=True; uav2 landed at (14.7, -20.0) home=True; uav3 landed at (14.6, 19.7) home=True; uav4 landed at (14.7, 40.0) home=True <br> *scenario scenario_failure (results/runs/20260925_010619_scenario_failure)*: uav1 landed at (14.7, -0.4) home=True; uav3 landed at (14.7, 19.8) home=True; uav4 landed at (14.7, 40.0) home=True |
| TEST 18: Collision avoidance | **PASS** | *scenario scenario_collision (results/runs/20260925_012707_scenario_collision)*: collisions 0, avoidance activations 10, minimum separation 7.51 m ['uav2', 'uav4'] (collision < 1.5 m, min safe 5.0 m, violations 0); mission MISSION_COMPLETE |
| TEST 19: Geo-fence | **PASS** | *scenario scenario_geofence (results/runs/20260925_013053_scenario_geofence)*: uav4 commanded to [520.0, 60.0, 40.0] (outside fence x<=460.0), clamped to [455.0, 60.0, 40.0]; geofence warnings 1 (GCS events 1), violations 0; mission MISSION_COMPLETE |
| TEST 20: Complete mission | **PASS** | *scenario nominal (results/runs/20260925_010224_nominal)*: MISSION_COMPLETE: 6/6 PoIs, completion time 120.0 s, duration 196.0 s, priority score 1.0 |
| TEST 21: Failure + recovery + mission completion | **PASS** | *scenario stage1_demo (results/runs/20260925_013850_stage1_demo)*: [failure] relay uav2 failed at mission t=69.02s; heartbeat loss detected after 3.5s; new relay uav1 (PEER_ELECTED (UAV elected itself as brid) after 12.7s; network reconfigured after 15.5s; mission MISSION_COMPLETE / [priority] POI7 (CRITICAL) announced at t=104.02s, assigned to uav3 after 0.5s, completed at t=127.58s; mission MISSION_COMPLETE / [battery] uav3: battery fault at t=119.52s; RTH at t=133.95s; landed at home=True with lowest battery 21.7% (critical 15.0%); tasks released 1; mission MISSION_COMPLETE / [mission] MISSION_COMPLETE: 7/7 PoIs, completion time 174.5 s, duration 257.5 s, priority score 1.0 |
