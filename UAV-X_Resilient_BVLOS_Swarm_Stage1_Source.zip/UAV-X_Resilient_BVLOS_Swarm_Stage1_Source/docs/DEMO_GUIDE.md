# Demonstration Video Script (Stage 1)

Target length: 6–8 minutes. The mission itself runs about 4 minutes (mission time about 230–250 s).

## Before recording

1. Close other heavy programs (the simulation uses about 4 CPU cores).
2. In the project directory: `./scripts/stop_all.sh --force` (clean state).
3. Arrange three windows side by side (1920×1080 works well):
   * **Terminal** (left, about 40% width, font ≥ 14 pt): runs the demo and shows the colour-coded
     event console;
   * **Gazebo GUI** (right top): opens automatically;
   * **Browser** with `http://localhost:8080` (right bottom): the dashboard (live map,
     UAV table, metrics, events).
4. Recorder: Windows *Xbox Game Bar* (`Win + Alt + R`) or OBS Studio (capture the
   whole screen).

## Recording

```bash
cd <project directory>          # the folder containing run_demo.sh
./run_demo.sh
```

Open/refresh the dashboard as soon as the terminal prints `dashboard: http://localhost:8080`.
**Maximize the Gazebo window.** The follow camera then keeps the view behind the swarm with
all 4 drones in frame automatically; do not drag the view (the follow camera re-positions it
every 0.5 s). For hand-controlled close-ups, run with `UAVX_CAMERA=fixed ./scripts/run_stage1_demo.sh`
and use right-click on a UAV → *Follow*. The small camera icon at the top-left of the 3D view
saves a screenshot to `~/.gz/gui/pictures`.

## Shot list: what each segment proves

| # | Mission time | Show | Proves (spec §46) | Console lines to point at |
|---|---|---|---|---|
| 1 | before start | Gazebo overview: GCS building + mast, 4 coloured launch pads, yellow geofence, disaster zone with collapsed buildings, 6 coloured PoI beacons | 1 four UAVs, 2 GCS, 3 disaster area, 4 PoIs | `[UAV] UAVn ready (PX4 sysid n, udp 1454x)` |
| 2 | 0 s | Terminal | 5 mission assignment | `[MISSION] Mission started`, `Initial relay scores ...`, `UAVn role = RELAY/SURVEY`, `POIx (HIGH) assigned to UAVy` |
| 3 | 0–20 s | Gazebo: four UAVs climb to different altitude layers | autonomous takeoff, strategic deconfliction | `armed in OFFBOARD`, `reached cruise altitude 25/30/35/40 m`, `Mission phase -> FORMATION/DEPLOY` |
| 4 | 20–65 s | Dashboard map: relay (purple ring) at the relay point, survey UAVs at PoIs, **blue route lines** UAV → relay → GCS | 6 multi-hop communication, 7 relay role | `[NETWORK] [route] UAV4 -> UAV1 -> GCS`, `survey report received ... via UAV2 -> UAV1 -> GCS` |
| 5 | about 67 s | Terminal + Gazebo: the relay UAV descends (injected failure) | 8 UAV failure | `[SCENARIO] Injecting UAV_FAILURE on UAVx (current RELAY)`, `[FAILURE] UAVx heartbeat lost (3.x s)` |
| 6 | +3–8 s | Terminal | failure detection and impact analysis | `UAVy unreachable: partitioned behind UAVx`, `Relay UAVx unavailable`, `Searching for replacement relay` |
| 7 | +6–18 s | Gazebo/dashboard: one survey UAV flies back to the relay point | 9 relay replacement (distributed peer election) | `no GCS contact for 6s -> BRIDGE: elected as bridge among 3 UAVs`, `self-elected as bridge relay`, `UAVz selected as new relay (replacing UAVx): PEER_ELECTED` |
| 8 | +18 s | Dashboard: routes return, all links GOOD/WARNING | 10 network recovery | `route to GCS restored`, `survey report received ... store-and-forward delay 7 s`, `[SWARM] Network reconfigured in 15 s` |
| 9 | failure +35 s | Gazebo: a new purple beacon appears (POI7); dashboard: POI7 appears | 11 new priority PoI | `New CRITICAL PRIORITY PoI detected: POI7`, `Mission phase -> EMERGENCY` |
| 10 | +0.1 s | Terminal | 12 task reassignment / pre-emption | `UAVy pre-empts POI6: POI7 (CRITICAL) takes precedence`, `POI7 (CRITICAL) assigned to UAVy` |
| 11 | POI7 +15 s | Dashboard: battery bar of one UAV drops sharply and turns amber/red | 13 low battery | `battery fault injected`, `sudden battery drop of 25% detected`, `draining 1.8x faster than modelled`, `battery 49% <= RTH threshold` |
| 12 | +13 s | Gazebo: that UAV heads home; another UAV takes its task | 14 return-to-home + takeover | `returning home (LOW_BATTERY)`, `POI6 reassigned to UAV2` |
| | | *In about 1 run in 9 the fault target is already on its last task, still has enough energy and simply finishes it; the mission then completes at about 140 s without a low-battery RTH (see [REPRODUCIBILITY.md §2](REPRODUCIBILITY.md)). Re-run `./run_demo.sh` for a recording that shows step 12.* | | |
| 13 | about 160 s | Terminal | 15 mission completion | `All 7 PoIs completed`, `Mission phase -> RETURN_HOME`, relay returns last |
| 14 | about 240 s | Gazebo: UAVs land on their pads | safe landing | `UAVn landed at (14.7, -20.2)`, `MISSION COMPLETE: 7/7 PoIs` |
| 15 | end | Terminal `[RESULT]` block, then `results/latest/report.md` (open in VS Code / browser) | 16 metrics | PDR, latency, connectivity, relay changes, recovery time, collisions 0, min separation, geofence violations 0 |

Useful narration points:
* "Nothing in this storyline is scripted except the three injected faults. The swarm is
  never told what was injected. It detects the failure from missing heartbeats, the
  degradation from measured packet delivery ratio, and the battery fault from its own
  telemetry."
* "When the relay dies, the survey UAVs are cut off from the GCS. They elect a
  replacement among themselves with a deterministic rule, so they agree without any extra
  messages. The GCS then adopts that UAV as the new relay."
* "Survey reports are store-and-forward: a UAV out of contact keeps its data and delivers
  it, with acknowledgement, once a route exists again."

## Supplementary clips (optional, 30–60 s each)

```bash
./scripts/run_scenario.sh scenarios/scenario_comm_outage.yaml --gui   # 5→20→50→100 % loss on the relay
./scripts/run_scenario.sh scenarios/scenario_collision.yaml --gui     # head-on avoidance, same altitude
./scripts/run_scenario.sh scenarios/scenario_geofence.yaml --gui      # command outside the fence gets clamped
```

## After recording

* `results/latest/report.md` and `results/final_validation_report.md` give the numbers for the
  proposal.
* `./scripts/stop_all.sh` (the demo stops everything automatically unless `--keep`).
