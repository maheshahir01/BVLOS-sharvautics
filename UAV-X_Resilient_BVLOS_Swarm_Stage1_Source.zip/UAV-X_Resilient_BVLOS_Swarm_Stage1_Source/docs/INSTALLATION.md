# Installation Guide

All commands are run from the **project directory**: the folder that contains `install.sh`
and `run_demo.sh` (`uav_x_swarm/` when cloned, `UAV-X_Resilient_BVLOS_Swarm_Stage1_Source/`
when extracted from the submission ZIP). No absolute paths are needed.

## A. Tested environment

| Component | Exact version used for validation |
|---|---|
| OS | Ubuntu 26.04.1 LTS "Resolute Raccoon", x86_64 (kernel 6.18 WSL2; Windows host with WSLg) |
| ROS 2 | Lyrical Luth: `ros-lyrical-desktop` / `ros-lyrical-ros-base` 0.13.0, `ros-lyrical-rclpy` 10.0.10, `ros-lyrical-ros-gz-bridge` 3.0.10, Fast DDS (`rmw_fastrtps_cpp`) |
| Gazebo | Jetty: `gz-jetty` 1.0.0 (gz-sim 10.5.0, gz-transport 15.1.0, gz-msgs 12.0.2, gz-gui 10), `python3-gz-transport15` 15.1.0, `python3-gz-msgs12` 12.0.2 |
| PX4 | PX4-Autopilot `v1.18.0-rc1`, commit `fca3df865af36124a28c9d607e850f111dbaaea9`, target `px4_sitl_default`, airframe 4001 `gz_x500` |
| Python | 3.14.4; pymavlink 2.4.49, PyYAML 6.0.3, pytest 9.0.2; PX4's `Tools/setup/requirements.txt` |
| Compilers | GCC 15.2.0, CMake 4.2.3, Ninja 1.13.2, Git 2.53.0 |

Ubuntu 24.04 + ROS 2 Jazzy + Gazebo Harmonic is supported by the scripts (same code path;
PX4 v1.18 also builds against Harmonic) but was **not** validated.

## B. System requirements

* x86_64 CPU with ≥ 4 cores (validated: Intel i5-12450H, 6 cores / 12 threads). Four PX4 instances
  and Gazebo run at real-time factor 1.0 on this machine.
* ≥ 8 GB RAM (the running simulation uses about 2 GB; the PX4 build needs about 4 GB).
* ≥ 10 GB free disk (PX4 checkout with submodules about 2 GB, build about 1 GB).
* Internet access during installation (Ubuntu/ROS/Gazebo apt repositories, GitHub, PyPI).
* `sudo` rights for installing missing apt packages (nothing else needs root).
* For the Gazebo GUI: a working display (native X11/Wayland, or WSLg on Windows 11). The demo
  also runs without a GUI (`--headless`).

## C. Required packages

`install.sh` installs whatever is missing from this list (see `ros2_dependencies.txt` for versions):

| Group | apt packages |
|---|---|
| Base tools | `ca-certificates curl gnupg lsb-release software-properties-common git build-essential cmake ninja-build pkg-config python3 python3-dev python3-pip python3-setuptools python3-wheel python3-yaml python3-pytest python3-packaging rsync unzip zip file bc libxml2-utils mesa-utils procps iproute2` |
| ROS 2 | `ros-lyrical-ros-base ros-lyrical-ros-gz-bridge python3-colcon-common-extensions` |
| Gazebo | `gz-jetty python3-gz-transport15 python3-gz-msgs12` |
| PX4 build / simulation | `libunwind-dev cppzmq-dev dmidecode libopencv-dev libeigen3-dev protobuf-compiler libprotobuf-dev libgstreamer-plugins-base1.0-dev gstreamer1.0-plugins-bad gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-ugly gstreamer1.0-libav libimage-exiftool-perl` |

Python (pip, only if missing): `requirements.txt` plus PX4's `external/PX4-Autopilot/Tools/setup/requirements.txt`.

## D. ROS 2 setup

If `/opt/ros/lyrical` does not exist, `install.sh` adds the official ROS 2 apt source exactly as
documented on docs.ros.org (the `ros2-apt-source` package) and installs `ros-lyrical-ros-base`.
To do it by hand:

```bash
sudo apt install -y software-properties-common curl && sudo add-apt-repository -y universe
ROS_APT_SOURCE_VERSION=$(curl -s https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest | grep -F '"tag_name"' | awk -F\" '{print $4}')
curl -L -o /tmp/ros2-apt-source.deb "https://github.com/ros-infrastructure/ros-apt-source/releases/download/${ROS_APT_SOURCE_VERSION}/ros2-apt-source_${ROS_APT_SOURCE_VERSION}.$(. /etc/os-release && echo $VERSION_CODENAME)_all.deb"
sudo dpkg -i /tmp/ros2-apt-source.deb && sudo apt update
sudo apt install -y ros-lyrical-ros-base ros-lyrical-ros-gz-bridge python3-colcon-common-extensions
```

## E. Gazebo setup

If `gz sim` is not available, `install.sh` adds packages.osrfoundation.org and installs `gz-jetty`.
By hand:

```bash
sudo curl -fsSL https://packages.osrfoundation.org/gazebo.gpg -o /usr/share/keyrings/pkgs-osrf-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/pkgs-osrf-archive-keyring.gpg] http://packages.osrfoundation.org/gazebo/ubuntu-stable $(. /etc/os-release && echo $VERSION_CODENAME) main" | sudo tee /etc/apt/sources.list.d/gazebo-stable.list
sudo apt update && sudo apt install -y gz-jetty python3-gz-transport15 python3-gz-msgs12
```

> Note: sourcing ROS 2 Lyrical puts a *vendored* `gz` command first on `PATH` that has no
> `sim` sub-command. This is expected. The project always starts Gazebo and PX4 in a clean,
> ROS-free environment (`scripts/lib/common.sh`). Check Gazebo with `env -i PATH=/usr/bin:/bin gz sim --versions`.

## F. PX4 setup

`install.sh` clones PX4 into `external/PX4-Autopilot` at the pinned tag and verifies the commit:

```bash
git clone --branch v1.18.0-rc1 --depth 1 --recurse-submodules --shallow-submodules -j 8 \
    https://github.com/PX4/PX4-Autopilot.git external/PX4-Autopilot
git -C external/PX4-Autopilot rev-parse HEAD      # must print fca3df865af36124a28c9d607e850f111dbaaea9
```

If `external/PX4-Autopilot` already exists at a different commit, `install.sh` stops and does not
modify it. PX4's own `Tools/setup/ubuntu.sh` is **not** run (it targets Ubuntu 22.04/24.04 with
Gazebo Harmonic); the equivalent packages are installed by `install.sh` (section C).

## G. Python dependencies

```bash
python3 -m pip install --user --break-system-packages -r requirements.txt \
    -r external/PX4-Autopilot/Tools/setup/requirements.txt      # only needed if something is missing
```
`install.sh` checks each requirement first and installs only the missing ones (this is the same
`pip --user` method PX4's `ubuntu.sh` uses on Ubuntu ≥ 24.04).

## H. Workspace build

```bash
./scripts/build.sh            # what install.sh runs
```
It (1) generates `worlds/disaster_zone.sdf` from `config/`; (2) builds PX4 SITL (`make px4_sitl`,
about 10 min the first time, in a ROS-free environment); (3) generates the enlarged-visual drone
model in `models/x500_base` (physics verified identical to PX4's); (4) builds the ROS 2 package
with `colcon build --symlink-install` (creates `build/`, `install/`, `log/`).
`./scripts/build.sh --clean` rebuilds the ROS workspace from scratch.

## I. Environment setup

**Nothing needs to be exported by hand, and nothing is added to `~/.bashrc`.** Every script
builds its own environment through `scripts/lib/common.sh`:

| Variable | Value | Purpose |
|---|---|---|
| `ROS_DOMAIN_ID` | `42` | isolated DDS domain |
| `ROS_AUTOMATIC_DISCOVERY_RANGE` | `LOCALHOST` | no discovery traffic on the network |
| `GZ_IP` / `GZ_PARTITION` | `127.0.0.1` / `uavx` | isolated Gazebo transport |
| `GZ_SIM_RESOURCE_PATH` | `models/:worlds/:` PX4 models/worlds | set only for Gazebo/PX4 processes |
| `PX4_SIM_MODEL`, `PX4_GZ_*`, `PX4_PARAM_*` | per UAV | set only for each PX4 process |
| `GALLIUM_DRIVER` | `d3d12` | set only for the Gazebo GUI on WSL2 (hardware OpenGL) |
| `UAVX_CAMERA` (optional) | `fixed` | disable the GUI follow camera |
| `UAVX_CONFIG` (optional) | path | use another configuration file |

Foreign ROS overlays in your shell (e.g. another workspace sourced by `~/.bashrc`) are removed
from the project's environment automatically. For interactive ROS 2 tools:

```bash
source environment_setup.sh
ros2 node list
```

## J. Verification

```bash
./install.sh --check                 # nothing missing, PX4 at the pinned commit
./scripts/check_system.sh            # versions, packages, PX4 build, ports -> "system check passed"
./scripts/run_tests.sh --unit        # 36 unit tests -> "PASS"
./scripts/run_tests.sh --sim         # optional, ~10 min: TEST 1-6 (PX4 + Gazebo, 1 and 4 UAVs)
```

## K. Demo execution

```bash
./run_demo.sh                        # with the Gazebo GUI (if a display is available)
./run_demo.sh --headless             # without the GUI
```
Open **http://localhost:8080** for the dashboard (under WSL2 also from the Windows browser).

## L. Expected output

1. `[sim] simulation running: 4 PX4 vehicles in world 'disaster_zone'`
2. `[run] dashboard: http://localhost:8080`
3. The event console: 4 × `UAVn ready`, `Mission started: 4 UAVs, 6 PoIs`, relay and task
   assignment, takeoff, surveys, `survey report received … via UAVx -> UAVy -> GCS`, relay failure and
   recovery (`PEER_ELECTED`, `Network reconfigured`), `New CRITICAL PRIORITY PoI`, battery fault and
   `returning home (LOW_BATTERY)`, task reassignment, `All 7 PoIs completed`, landings.
4. The end:
   ```
   [MISSION] MISSION COMPLETE: 7/7 PoIs, mission time ~255 s (all UAVs landed)
   [RESULT] MISSION_COMPLETE: 7/7 PoIs, completion time ~172 s, priority score 1.0
   [RESULT] PDR ~0.83, mean latency ~17 ms, connectivity ~0.95, ...
   [RESULT] collisions 0, min separation ~9 m, geofence violations 0
   [run] RESULT: MISSION_COMPLETE          (exit code 0)
   ```
5. `results/latest/report.md` with all metrics. Reference values: README §7 and `results/reference/`.

## M. Troubleshooting

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md). The most common issues:

* **apt asks for a password:** `install.sh` needs `sudo` only for missing apt packages.
* **`PX4 not built`:** run `./install.sh` (or `./scripts/build.sh`); first build about 10 min.
* **`external/PX4-Autopilot is at commit … but … is required`:** move the old checkout away
  (`mv external/PX4-Autopilot external/PX4-old`) and re-run `./install.sh`.
* **Leftover processes / "simulation already running":** `./scripts/stop_all.sh --force`.
* **No GUI window on WSL2:** check `glxinfo -B`; run `./run_demo.sh --headless` and use the dashboard.
* **Port 8080 busy:** close the other program (the dashboard binds `127.0.0.1:8080`).
