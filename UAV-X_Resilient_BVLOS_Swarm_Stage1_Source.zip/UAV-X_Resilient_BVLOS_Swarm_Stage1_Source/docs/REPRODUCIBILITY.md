# Reproducibility

## 1. Pinned inputs

| Input | Pin | Where it is enforced |
|---|---|---|
| PX4-Autopilot | tag `v1.18.0-rc1` = commit `fca3df865af36124a28c9d607e850f111dbaaea9`; submodules at the commits recorded by that tag | `scripts/lib/common.sh` (`PX4_TAG`, `PX4_COMMIT`); `install.sh` clones the tag and refuses any other commit |
| ROS 2 | Lyrical Luth (Ubuntu 26.04 binaries, validated: ros-base 0.13.0, rclpy 10.0.10, ros_gz_bridge 3.0.10) | `install.sh` (distro chosen from the Ubuntu version); `ros2_dependencies.txt` |
| Gazebo | Jetty (gz-sim 10.5.0, gz-transport 15.1.0, gz-msgs 12.0.2) | `install.sh`; PX4 v1.18 CMake finds gz-sim10/gz-transport15 |
| Python packages | pymavlink 2.4.49, PyYAML 6.0.3, pytest 9.0.2 | `requirements.txt` |
| Swarm configuration | all parameters in `config/swarm.yaml`, PoIs in `config/mission_pois.yaml` | copied into every run record (`results/runs/<run>/meta.json`) |
| Scenario | `scenarios/stage1_demo.yaml` (faults triggered by mission progress, not wall-clock time) | `scenario_runner` |
| Random numbers | communication RNG seed `communication.seed: 42` | `comm_manager` |
| PX4 parameters | set from `sim.px4_params` through `PX4_PARAM_*` on every start; every PX4 instance gets a fresh working directory, so no parameters persist between runs | `scripts/start_simulation.sh` |
| World | `worlds/disaster_zone.sdf` generated from the configuration | `scripts/tools/generate_world.py` |

Distribution apt packages (ROS 2, Gazebo, Ubuntu) are installed from their official repositories.
Those repositories serve the current patch release of each package, so a later install may get a
newer *patch* version than the one validated. The validated versions are recorded in
`ros2_dependencies.txt` and in `results/final_validation_report.md`.

## 2. What is and is not deterministic

* **Deterministic:** configuration, scenario, world, PX4 version and parameters, the algorithms
  themselves (unit tests), and the order of the demonstration storyline (triggers depend on
  mission progress: "relay fails after 2 PoIs are reported", etc.).
* **Not bit-for-bit deterministic:** a run is a real-time co-simulation of 4 PX4 processes,
  Gazebo and 8 ROS 2 nodes. Thread scheduling changes message timing, so the seeded
  packet-loss draws fall on different packets and the relay/PoI decisions happen a few seconds
  earlier or later. The outcome and storyline stay the same; the timings vary. Observed on the
  validation machine over all Stage-1 demo runs that ran to the end with the final mission
  logic (25-27 Sep 2026, including the three clean-extraction runs on the host and the fresh
  Ubuntu 26.04 container run, 18 runs):

  | Metric | Typical (median) | Observed range |
  |---|---|---|
  | Result | MISSION_COMPLETE, 7/7 PoIs, 0 collisions | same in all 18 runs |
  | PoI completion time | 174.5 s | 139.5 - 236.0 s |
  | Relay-failure reconfiguration time | about 16 s | 15.0 - 39.5 s |
  | Packet delivery ratio | 0.83 | 0.80 - 0.84 |
  | Minimum inter-UAV separation | about 9 m | 8.1 - 19.9 m |
  | Lowest battery of any UAV at landing (critical 15 %) | 21.7 % | 15.2 - 23.8 % (one run at 15.2 %, all others >= 20.8 %) |
  | Low-battery RTH + task hand-over shown (TEST 16) | yes | 16 of 18 runs |

  **Known intermittent gap (2 of 18 runs):** the battery fault is injected 15 s after the
  CRITICAL PoI appears. In two runs the swarm had re-planned so efficiently after the relay
  failure that the fault target was already on its last task; after the 25 % drop it still had
  enough energy (about 48 %) to finish, the mission completed at about 140 s and all UAVs flew
  the normal end-of-mission RTH. The swarm behaved correctly (a low-battery RTH was not
  needed), but the low-battery storyline was not demonstrated, so TEST 16 and TEST 21 report
  FAIL for such a run. Re-run `./run_demo.sh` if this happens. The scenario trigger was left
  unchanged on purpose so the validated results stay comparable.

  Runs that were stopped by hand before the mission ended (camera development on 26 Sep) are
  not counted. `results/reference/` holds two complete metric sets for comparison.

## 3. Reproducing the validated result

```bash
./install.sh            # dependencies, pinned PX4, build, verification
./run_demo.sh           # expected: "[run] RESULT: MISSION_COMPLETE" (exit code 0)
cat results/latest/report.md
```
Compare with `results/reference/validated_demo_run1_*/report.md`. For the complete procedure
used for the submission (full test suite → demo → stop → clean rebuild → demo):

```bash
./scripts/tools/final_validation.sh      # ~90 min; writes results/final_validation_report.md
```

## 4. Verifying the submission archive

```bash
sha256sum -c UAV-X_Resilient_BVLOS_Swarm_Stage1_Source.zip.sha256
```
The archive contains only version-controlled source (it is produced with `git archive`). It
contains no build output, logs, caches or the PX4 checkout; those are recreated by `install.sh`.

## 5. Evidence

* `results/reproducibility_validation.md`: the packaged archive was extracted into a separate
  directory and installed, built and run end to end, with the original development tree made
  inaccessible.
* `results/final_validation_report.md`: test suite 22/22 PASS, two demo runs across a clean restart.
* `TEST_RESULTS.md`: per-test verdicts with the evidence each one used.
