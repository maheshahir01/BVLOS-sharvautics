# System Compatibility Report

Generated during Phase 1 (system inspection) on 2026-09-24. Every value below was
read from the machine with the command shown. Nothing here is assumed.

## 1. Host machine

| Item | Value | Command |
|---|---|---|
| OS | Ubuntu 26.04.1 LTS "Resolute Raccoon" | `lsb_release -a` |
| Kernel | 6.18.33.2-microsoft-standard-WSL2 (x86_64) | `uname -a` |
| Platform | **WSL2 on Windows** (WSLg display server present) | `/proc/version`, `/mnt/wslg` |
| CPU | 12th Gen Intel Core i5-12450H, 6 cores / 12 threads | `lscpu` |
| RAM | 7.6 GiB visible to WSL (+2 GiB swap). No `.wslconfig`, so WSL uses the default of 50% of host RAM | `free -h` |
| Disk | 1007 GB, 934 GB free on `/` | `df -h` |
| GPU (render) | Default Mesa `llvmpipe` (software). With `GALLIUM_DRIVER=d3d12`: **D3D12 (Intel UHD Graphics), hardware accelerated** | `glxinfo -B` |
| GPU (NVIDIA) | NVIDIA libs exist in `/usr/lib/wsl/lib`, but `nvidia-smi` fails ("Failed to initialize NVML") and the adapter cannot be selected. It is not used | `nvidia-smi` |
| Python | 3.14.4 (`/usr/bin/python3`) | `python3 --version` |
| GCC / G++ | 15.2.0 | `gcc --version` |
| CMake | 4.2.3 | `cmake --version` |
| Git | 2.53.0 | `git --version` |
| Ninja | 1.13.2 | `ninja --version` |
| Docker | not installed (not needed) | `which docker` |

## 2. Robotics software already present before this project

| Component | State found | Notes |
|---|---|---|
| ROS 2 | **Lyrical Luth** at `/opt/ros/lyrical` (`ros-lyrical-desktop`, 292 packages) | `ros2 doctor`: all 5 checks passed |
| Gazebo | **Jetty** (`gz-jetty 1.0.0`, `gz-sim10 10.5.0`, `gz-transport15 15.1.0`, `gz-msgs12 12.0.2`) from `packages.osrfoundation.org` | `gz sim --version` → 10.5.0 |
| colcon | `python3-colcon-common-extensions 0.3.0` | |
| pymavlink | 2.4.49 (in `/usr/local/lib/python3.14/dist-packages`) | |
| PX4 build Python deps | empy 3.3.4, kconfiglib, nunavut, pydsdl, pandas, cerberus, … in `/usr/local` | from an earlier PX4 setup |
| MicroXRCEAgent | `/usr/local/bin/MicroXRCEAgent` (v3.0.x, installed 2026-09-13) | not required by this project |
| PX4 source | **none**. `~/uav-x-stage1/sim/PX4-Autopilot` holds only empty directories from an earlier attempt | left untouched |
| Other ROS workspace | an unrelated colcon workspace was sourced from `~/.bashrc` | left untouched. Project scripts strip foreign overlays from their environment |
| MAVSDK | not installed | not needed (pymavlink is used) |
| Network | github.com, packages.ros.org, packages.osrfoundation.org and pypi.org all reachable | `curl -I` |
| sudo | required only for installing apt packages | |

## 3. Compatibility conflict (spec section 49) and its resolution

**Conflict.** The project brief targets *Ubuntu 24.04 + ROS 2 Jazzy + Gazebo Harmonic*.
This machine runs **Ubuntu 26.04**, where:

* ROS 2 Jazzy has **no binary packages** (Jazzy targets 24.04, per REP-2000).
* Gazebo Harmonic has **no packages** for 26.04 (`apt-cache policy gz-harmonic` → none).
* PX4's official `Tools/setup/ubuntu.sh` (v1.17.0 through `main`) only lists 22.04/24.04 with Harmonic.

**Resolution.** Use the officially paired stack for Ubuntu 26.04 and the first PX4 release
line whose source code supports it:

| Layer | Chosen version | Justification |
|---|---|---|
| OS | Ubuntu 26.04.1 LTS | existing install. Reinstalling the OS would be destructive |
| ROS 2 | **Lyrical Luth** | the official ROS 2 distribution for Ubuntu 26.04 (REP-2000) |
| Gazebo | **Jetty (gz-sim 10.5.0)** | the official Gazebo pairing for ROS 2 Lyrical |
| PX4 | **v1.18.0-rc1** (commit `fca3df865af3`) | first tagged PX4 release whose `gz_bridge`/`gz_plugins` CMake lists `gz-transport15`/`gz-sim10`/`gz-sensors10`/`gz-plugin4` and carries the GCC-15 warning workaround. v1.17.0 lacks both |
| ROS↔Gazebo | `ros-lyrical-ros-gz-bridge 3.0.10` | official binary package |
| Vehicle link | pymavlink 2.4.49 over PX4's per-instance MAVLink UDP ports | already installed. No px4_msgs version coupling |

The project code itself is distribution-agnostic. `scripts/environment_setup.sh` detects
`/opt/ros/<distro>`, so the same repository also runs on Ubuntu 24.04 + Jazzy + Harmonic
with PX4 v1.18 (the `find_package` lists above include Harmonic's gz-sim8).

## 4. Issues found during inspection and how they were handled

1. **ROS vendored Gazebo CLI shadows the system CLI.** Installing `ros_gz_bridge` pulls in
   `gz_tools_vendor`, `gz_transport_vendor` and `gz_msgs_vendor`. Sourcing
   `/opt/ros/lyrical/setup.bash` then puts `/opt/ros/lyrical/opt/gz_tools_vendor/bin/gz`
   first on `PATH` and sets `GZ_CONFIG_PATH` to vendor paths only, so `gz sim` disappears
   ("List of available commands: help, log, msg, param, service, topic").
   *Fix:* Gazebo and PX4 run in a ROS-free environment, and only ROS nodes source ROS.
   The vendored libraries are the same versions as the system ones
   (gz-transport 15.1.0, gz-msgs 12.0.2), so the bridge and the simulator are wire-compatible.
   Verified: ROS 2 received `/clock` from Gazebo via `parameter_bridge`.
2. **`gz sim` process name.** In Jetty, `gz sim` execs `/usr/libexec/gz/sim10/gz-sim-main`.
   The stop script targets that name.
3. **`setsid` forks in this shell**, so `$!` is not the session leader. Launchers record
   the PID from inside the new session (`bash -c 'echo $$ > pidfile; exec …'`).
4. **A foreign ROS workspace overlay** sourced by `~/.bashrc`. Project scripts clear
   `AMENT_PREFIX_PATH`/`CMAKE_PREFIX_PATH`/`PYTHONPATH`/`LD_LIBRARY_PATH` before sourcing ROS,
   so the unrelated workspace can never shadow project packages.
5. **RAM (7.6 GiB)** is modest for 4×PX4 + Gazebo. The Gazebo *server* runs headless (the x500 has
   no camera, so no rendering is needed), and the GUI is optional and hardware accelerated via d3d12.

## 5. Verification results (Phase 1–3)

| Test | Result | Evidence |
|---|---|---|
| `ros2 doctor` | PASS (5/5 checks) | only "newer patch version available" warnings |
| ROS 2 pub/sub, domain 42, localhost discovery | PASS (7/7 messages) | `demo_nodes_py` talker → listener |
| `gz sim --version` (clean env) | PASS → 10.5.0 | |
| Headless Gazebo server publishes `/clock` | PASS | `gz topic -e -t /clock` |
| ROS 2 ↔ Gazebo bridge | PASS | `ros2 topic echo --once /clock` → `sec: 13` |
| d3d12 hardware GL in WSLg | PASS | `glxinfo -B` → Accelerated: yes |
