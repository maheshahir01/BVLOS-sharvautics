# Mission Scenarios

Scenarios are YAML files in `scenarios/`. Faults are **declared**, never coded: the
`scenario_runner` injects them into the component that physically experiences them (a
vehicle, the radio channel, or the GCS operator). The swarm software is never told what was
injected; it has to detect it.

Run any scenario from a clean state with:

```bash
./scripts/run_scenario.sh scenarios/<name>.yaml [--gui] [--keep] [--no-dashboard]
```

## The mission

* GCS at the origin, outside the disaster zone. Launch pads at (15, 0), (15, −20),
  (15, 20), (15, 40).
* Disaster zone x ≈ 180–440 m with collapsed buildings, blocked roads and rubble.
* PoIs (`config/mission_pois.yaml`):

| PoI | Name | Position | Priority | Present at start |
|---|---|---|---|---|
| POI1 | Collapsed apartment block | (250, 110) | MEDIUM | yes |
| POI2 | Blocked road junction | (300, −50) | MEDIUM | yes |
| POI3 | Damaged bridge | (255, −140) | HIGH | yes |
| POI4 | Warehouse fire | (350, 90) | HIGH | yes |
| POI5 | Flooded school | (340, −140) | MEDIUM | yes |
| POI6 | Hospital access road | (380, −20) | LOW | yes |
| POI7 | Trapped survivors signal | (320, 30) | CRITICAL | no (emerges at runtime) |

* Every PoI lies 270–390 m from the GCS, beyond the 250 m GCS radio range, so a relay and
  multi-hop routes are needed. Survey = one 15 m-radius orbit (12 images).

## Scenario catalogue

| File | What happens | Tests |
|---|---|---|
| `nominal.yaml` | No faults. Relay selection, allocation, multi-hop routing, avoidance, geofence monitoring, RTH | 7, 8, 9, 10, 11, 17, 20 |
| `scenario_failure.yaml` | The **current relay** fails (radio silent + emergency descent) after the first PoI report | 12, 17 |
| `scenario_comm_outage.yaml` | The current relay's radio degrades 5% → 20% → 50% → 100% packet loss (15 s steps, 100% at +50 s) | 13 |
| `scenario_packet_loss.yaml` | 15% loss and +40 ms latency on every UAV radio for the whole mission | 14 |
| `scenario_priority.yaml` | CRITICAL POI7 reported by the operator during the survey | 15 |
| `scenario_battery.yaml` | Busiest survey UAV: sudden 25% battery drop, then 2.5× drain | 16, 17 |
| `scenario_collision.yaml` | Altitude layering disabled (all at 25 m). UAV2 and UAV4 are commanded head-on along the pad line through the other UAVs | 18 |
| `scenario_geofence.yaml` | UAV4 is commanded to a point 60 m outside the fence for 30 s | 19 |
| `stage1_demo.yaml` | Relay failure → peer election → new relay; CRITICAL POI7; battery fault → RTH → task takeover; mission complete | 21 (and the demonstration) |

## `stage1_demo.yaml` storyline (what the judges see)

Events trigger on mission progress, so the order holds even if the simulation runs slower
than real time.

| Mission time (typical) | Event | System response |
|---|---|---|
| 0–18 s | Takeoff | 4 UAVs climb to their altitude layers (25/30/35/40 m). Relay chosen by score; PoIs auctioned |
| 18–50 s | Deploy | Relay flies to the planned relay point; survey UAVs fly to their PoIs |
| 50–70 s | Survey | Orbit surveys; reports over multi-hop routes (e.g. `UAV2 → UAV1 → GCS`) |
| ≈ 67 s (2 PoIs done) | **Relay UAV fails** | heartbeat loss detected (≈ 3 s); other UAVs identified as *partitioned*, not failed |
| +6 s | Lost link onboard | the cut-off UAVs elect a bridge among themselves; the others keep surveying and buffer their reports (an isolated UAV finishes its current survey, then flies back into coverage) |
| +14–18 s | Bridge reaches the relay point | routes restored; GCS adopts the bridge as new relay (`PEER_ELECTED`); buffered reports delivered; failed UAV declared FAILED; tasks re-planned; **network reconfigured** |
| failure + 35 s | **CRITICAL POI7** appears | validated, highest priority; assigned within 0.1 s, pre-empting a LOW-priority survey (which is re-queued) |
| POI7 + 15 s | **Battery fault** on the busiest survey UAV | step drop detected at the GCS; drain factor estimated; RTH threshold (1.25 × energy home + 25%) reached; UAV returns and lands on its pad above 20%; its task is **taken over** by another UAV |
| ≈ 150–165 s | All PoIs reported | RTH for everybody, relay last |
| ≈ 230–250 s | All landed | **MISSION COMPLETE** + metrics report |

## Writing a new scenario

```yaml
name: my_test
description: what and why
overrides:                 # optional: any key of config/swarm.yaml
  communication: {uav_range_m: 150}
events:
  - id: e1
    type: COMM_OUTAGE      # see list below
    target: uav2           # uavN | RELAY | SURVEY | ALL
    duration: 20
    trigger: {time: 90}    # or {condition: {completed_pois_gte: 3}, min_time: 60}
                           # or {after_event: e0, delay: 15}
```

Event types: `UAV_FAILURE`, `COMM_DEGRADATION` (`packet_loss`, `latency_ms`, or `ramp: [[t, loss], ...]`),
`COMM_OUTAGE` (`duration`), `COMM_RESTORE`, `LATENCY` (`latency_ms`), `PACKET_LOSS`
(`packet_loss`, `latency_ms`), `BATTERY_DEGRADATION` (`drop_pct`, `drain_multiplier`,
`set_pct`), `NEW_PRIORITY_POI` (`poi` from the PoI file, or inline `poi_def`),
`RETURN_HOME`, `GOTO` (`position`, `duration`).
