# Troubleshooting

Each entry below is a problem actually encountered while building and validating this
project, with the diagnosed root cause and the fix that is now in the code.

## Environment / installation

**`gz sim` prints only `help, log, msg, param, service, topic` after sourcing ROS.**
Cause: `ros-lyrical-ros-gz-bridge` pulls in ROS *vendored* Gazebo packages. Sourcing
`/opt/ros/lyrical/setup.bash` puts `/opt/ros/lyrical/opt/gz_tools_vendor/bin/gz` first on
`PATH` and sets `GZ_CONFIG_PATH` to vendor paths only, which hides the `sim` command.
Fix: Gazebo and PX4 always run in a clean, ROS-free environment (`sim_exec` /
`start_bg_sim` in `scripts/lib/common.sh`). The vendored libraries are the same versions
(gz-transport 15.1.0, gz-msgs 12.0.2), so the ROS bridge and the simulator interoperate.

**PX4 does not build against Gazebo Jetty / GCC 15.** PX4 ≤ v1.17 only knows gz-sim8/9.
Use PX4 v1.18.0-rc1 or newer (pinned by `install.sh`).

**Another ROS workspace in `~/.bashrc` (e.g. `source ~/xyz_ws/install/setup.bash`).**
Project scripts clear `AMENT_PREFIX_PATH`, `CMAKE_PREFIX_PATH`, `PYTHONPATH` and
`LD_LIBRARY_PATH` before sourcing ROS, so a foreign overlay cannot shadow packages.

**`ros2 topic list` shows nothing.** The project runs on `ROS_DOMAIN_ID=42` with localhost
discovery. Run `source environment_setup.sh` (from the project directory) first.

## Starting / stopping

**"simulation already running" or "found PX4/Gazebo processes not started by this project".**
Run `./scripts/stop_all.sh --force`. It only kills processes whose command line references
this project folder, plus the process groups it recorded in `.run/pids/`.

**Processes survive a crash.** Every background process is started as its own session leader
and its process-group ID is stored in `.run/pids/<name>.pid`. `stop_all.sh` sends SIGINT,
then SIGTERM, then SIGKILL to the whole group, removes stale `/tmp/px4_lock-*` files (only if
no PX4 is running) and verifies nothing is left. Note that in Gazebo Jetty `gz sim` execs
`/usr/libexec/gz/sim10/gz-sim-main`, and that is the process name to look for.

**Never `pkill -f <pattern>` from an interactive command line** that itself contains the
pattern: it kills your own shell. `stop_all.sh` excludes its own ancestor processes.

**PX4 "Preflight Fail: No connection to the GCS".** PX4 requires a GCS-type heartbeat.
`px4/link.py` sends `MAV_TYPE_GCS` heartbeats at 1 Hz, and the message disappears as soon
as the agent connects.

## Flight

**A UAV connects to the wrong PX4 instance.** Impossible by construction: UAV k binds UDP
`14540+k-1` and accepts only `MAV_SYS_ID k`. Anything else is logged as
"ignoring MAVLink from unexpected sysid". TEST 5 checks this for every UAV.

**Vehicle lands a few metres off its pad.** Fixed: RTH waits until the UAV is within 1 m of
the pad and slower than 0.6 m/s before commanding AUTO.LAND (landings are within 0.5 m).

## Swarm behaviour (bugs found by end-to-end runs, all fixed)

| Symptom | Root cause | Fix |
|---|---|---|
| Run hangs after all UAVs landed | `swarm_manager` crashed at mission end: an event detail named `mission_time` collided with `make_event()`'s own parameter | details passed as an explicit dict; all callbacks guarded (`SOFTWARE_ERROR` event); a crashed critical node shuts the launch down |
| One UAV idle for the whole mission | allocation cost = *added* distance, which favours chaining tasks on a busy UAV | cost = total route length after insertion (makespan) |
| Link status flapping GOOD/WARNING/DEGRADED | 2-hop steady-state PDR near the thresholds; 12-packet window | realistic loss curve, 10 s window, recovery hysteresis, 1.5 s debounce |
| After a relay failure, every new relay was immediately "LINK_FAILED" and sent home | PDR window still contained the outage; the new relay had no grace period | reset PDR history on reconnection; 15 s grace for a new relay; old relay sent home only if *its* radio is at fault |
| The GCS overrode the peer-elected bridge | bridge's own telemetry arrived one cycle after packets it forwarded | packets forwarded through a UAV prove it is alive; bridges preferred; 2 s selection hold after reconnection |
| "Network reconfigured in 0.0 s" | reconfiguration check used stale link states | requires fresh telemetry (< 1.5 s) from every survivor, held for 2 s |
| UAV with a battery fault reached CRITICAL on the way home | RTH threshold = energy home + 10% reserve, below the 15% critical level; GCS assumed nominal drain | threshold = 1.25 × energy home + critical + reserve (property-tested); GCS drain estimator + step-drop detection |
| A single isolated UAV abandoned its survey to "bridge" for nobody | election ran without peers | isolated UAVs continue their tasks, or fly back into coverage if idle; never self-elect |
| An idle UAV far out drifted out of range and was "declared FAILED" | idle UAVs hovered where their last task ended; silence was treated like a crash | idle UAVs move to a standby point inside coverage; a *faded* link gets 3× the confirmation time |
| Head-on stress test: 2.05 m minimum separation | distance-only trigger (12 m) is too late at 16 m/s closing speed | predictive trigger (closest approach within 4 s); now 7.5 m |
| A healthy UAV that flew out of range at the edge of the area was "declared FAILED" and its tasks reassigned | silence was classified as abrupt because its measured link was still GOOD just before crossing the range limit | last-seen coverage margin (< 20 % of range left counts as a fade, 3× confirmation); isolated UAVs finish only the current survey, then reconnect; relay placement includes lost UAVs |
| Routes flapped "no route / restored" at 50 % injected loss | link estimate hovering at the 0.25 usability threshold | usability hysteresis (remove < 0.25, re-add ≥ 0.35) |

* **The demo completes at about 140 s and TEST 16 / TEST 21 report FAIL ("RTH at t=None"):**
  the battery fault hit a UAV that was already on its last task and still had enough energy,
  so no low-battery return was needed (2 of 18 validation runs). The mission result is still
  MISSION_COMPLETE and the battery episode is reported as *not recovered* (it is not credited
  to the normal end-of-mission return). Run `./run_demo.sh` again to see the full storyline.

## Gazebo view

* **Drones too small / camera too far**: the follow camera (`scripts/tools/swarm_camera.py`,
  log `logs/sim/swarm_camera.log`) frames all 4 UAVs from behind. When they are spread over
  the whole survey area (up to about 300 m apart) each drone is small by necessity; maximize the
  window. `sim.uav_visual_scale` in `config/swarm.yaml` sets the drawing scale (then
  `./scripts/build.sh`).
* **The camera jumps / ignores moves**: gz-gui's CameraTracking keeps one pending move and
  drops a request that arrives while a move is animating (its completion callback clears
  the slot). The helper therefore animates for only 60 % of each 0.5 s period.
* **Want to steer the view manually**: start with `--fixed-camera` / `UAVX_CAMERA=fixed`.

## Reading logs

```
results/latest/console.txt          # the event console of the last run
results/latest/launch.log           # all ROS node output
results/latest/ros_logs/            # per-node ROS logs
results/latest/sim_logs/            # Gazebo + PX4 console logs
logs/ros/<run_id>/ , logs/sim/      # same, for the current/last run
```

A `SOFTWARE_ERROR` line on the console includes the node, callback and exception. The full
traceback is in the node's ROS log.

## Performance

* If the real-time factor drops below 1 (check with the GUI's World Stats, or
  `gz topic -e -t /world/disaster_zone/stats` in a clean environment), run headless. All
  timeouts are generous and scenario triggers are progress-based.
* The Gazebo GUI with software rendering (llvmpipe) is slow. On WSL use `--gui`, which
  enables d3d12 hardware rendering.
