# Stage-1 Requirements Mapping

Every requirement of the UAV-X rulebook (as captured in the project brief) mapped to its
implementation, source file, ROS node, automated test and evidence produced by each run.
Paths: `core/` = `src/uav_x_swarm/uav_x_swarm/core/`, `nodes/` = `.../nodes/`, `px4/` = `.../px4/`.
Evidence files are in `results/runs/<run>/` (`results/latest/` for the newest run).
Test verdicts: [TEST_RESULTS.md](../TEST_RESULTS.md).

## Mission requirements

| Requirement | Implementation | Source file | ROS node | Test | Evidence / log |
|---|---|---|---|---|---|
| Autonomous takeoff | offboard arming + climb to altitude layer | `nodes/uav_agent.py`, `px4/link.py` | `/uavN/uav_agent` | TEST 2, 5, 6, 20 | events `TAKEOFF`, `AIRBORNE`; `battery.csv` flight_state |
| Autonomous navigation | carrot-following position+velocity setpoints, geofence-clamped | `nodes/uav_agent.py` | `/uavN/uav_agent` | TEST 3, 6, 20 | `tests/sim/*/telemetry.csv`, `/uavN/position` |
| Survey assigned PoIs | orbit survey (12 images) + report to GCS, COMPLETE only when received | `core/survey.py`, `nodes/uav_agent.py`, `nodes/gcs.py` | uav_agent, gcs | TEST 20 | events `SURVEY_COMPLETE`, `REPORT_RECEIVED`, `POI_COMPLETED`; `mission.csv` |
| Maintain communication with GCS | telemetry 2 Hz, GCS beacons 1 Hz, measured PDR/latency, reliable commands | `nodes/comm_manager.py`, `core/comm.py`, `nodes/swarm_manager.py` | comm_manager, swarm_manager | TEST 8 | `communication.csv`, summary `communication` |
| Multi-hop UAV-to-UAV communication | ETX shortest-path routing through any UAV | `core/network.py`, `nodes/comm_manager.py` | comm_manager | TEST 9, 10 | `communication.csv` (route, hops); `REPORT_RECEIVED` details.route |
| UAV-to-GCS communication | direct or relayed routes, store-and-forward reports with ACK | `nodes/comm_manager.py`, `nodes/uav_agent.py`, `nodes/gcs.py` | comm_manager, gcs | TEST 8, 14 | summary `communication.per_type` |
| Dynamically assign relay UAVs | suitability score + hysteresis; grid-search relay placement | `core/relay.py`, `nodes/swarm_manager.py` | swarm_manager | TEST 11, 12, 13 | `relay_changes.csv`, events `RELAY_SCORES`, `RELAY_CHANGED`, `RELAY_POSITION` |
| Dynamic role allocation | RELAY / SURVEY / SURVEY_RELAY / RETURN_HOME / EMERGENCY / FAILED at runtime | `core/types.py`, `nodes/swarm_manager.py`, `nodes/uav_agent.py` | swarm_manager, uav_agent | TEST 12, 16, 21 | events `ROLE_ASSIGNED`, `ROLE_CHANGED`; `/uavN/role`; `battery.csv` role |
| Reconfigure when communication degrades | measured PDR → WARNING/DEGRADED/FAILED; degraded relay replaced before total loss | `core/comm.py`, `nodes/swarm_manager.py` | swarm_manager | TEST 13 | events `LINK_*`, `RELAY_INVALID`; `communication.csv` (gcs_pdr, link_status) |
| Reconfigure when UAVs fail | heartbeat timeout, partition inference, peer election, relay replacement, task release | `core/failure.py`, `core/lostlink.py`, `nodes/swarm_manager.py`, `nodes/uav_agent.py` | swarm_manager, uav_agent | TEST 12, 21 | `failures.csv`, events `HEARTBEAT_LOST`, `PARTITION`, `PEER_RELAY_ELECTED`, `UAV_FAILED`, `RECONFIG_COMPLETE` |
| Reconfigure when UAVs return home for charging | RTH releases role + tasks; relay replaced immediately | `nodes/swarm_manager.py` (`reconcile`, `command_rth`) | swarm_manager | TEST 16, 21 | events `RTH_ACKNOWLEDGED`, `TASK_RELEASED`, `TASK_ASSIGNED` (reassigned) |
| Prioritise new high-priority regions | validation, priority weights, earliest-slot insertion, pre-emption | `core/priority.py`, `core/allocation.py`, `nodes/gcs.py` | gcs, swarm_manager | TEST 15, 21 | events `NEW_PRIORITY_POI`, `TASK_PREEMPTED`, `TASK_ASSIGNED`, `POI_COMPLETED` |
| Complete mission safely and in time | mission state machine, timeout, RTH relay-last, landing on pads | `core/mission.py`, `nodes/swarm_manager.py` | swarm_manager | TEST 17, 20, 21 | events `PHASE_CHANGED`, `MISSION_COMPLETE`; summary `mission` |
| No UAV runs out of charge | battery model, safe RTH threshold, drain estimation, critical landing | `core/battery.py`, `nodes/uav_agent.py`, `nodes/swarm_manager.py` | uav_agent, swarm_manager | TEST 16 + unit property test | `battery.csv`; summary `battery.depleted_uavs` = [] |
| No UAV leaves the geofence | planning validation, onboard clamping, GCS monitoring → RTH | `core/geofence.py`, `nodes/uav_agent.py`, `nodes/swarm_manager.py` | uav_agent, swarm_manager | TEST 19 | `safety.csv` geofence_status; summary `safety.geofence_violations` = 0 |
| Minimum inter-drone separation | altitude layers + onboard repulsive avoidance + separation monitor | `core/collision.py`, `nodes/uav_agent.py`, `core/metrics.py` | uav_agent, metrics_logger | TEST 18 | `safety.csv` min_separation; events `AVOIDANCE_ACTIVE` |
| Communication outage handling | onboard lost-link procedure: bridge / continue / reconnect / RTH | `core/lostlink.py`, `nodes/uav_agent.py` | uav_agent | TEST 12, 13 | events `LOST_LINK`, `LINK_RESTORED` |
| Detailed logging & metrics | structured events, 7 CSV/JSON files, report per run | `core/metrics.py`, `nodes/metrics_logger.py` | metrics_logger | all | `results/runs/<run>/` |
| Scalable beyond 4 UAVs | everything driven by `swarm.number_of_uavs` | `core/config.py`, `scripts/tools/sim_plan.py`, `launch/swarm.launch.py` | all | unit `test_config_scales_to_n_uavs` | `config/swarm.yaml` |

## Evaluation categories

| Category (weight) | What demonstrates it | Metrics (report.md) |
|---|---|---|
| Mission completion (25%) | nominal + all fault scenarios end in MISSION_COMPLETE | completion rate, completion time, priority-weighted score |
| Communication resilience (25%) | multi-hop routing, relay placement, degradation detection, store-and-forward | PDR, latency (mean/p95/max), connectivity availability, downtime |
| Autonomous relay & role management (20%) | scored relay selection, peer election, role changes, relay handover on RTH | relay reallocations, task reallocations, relay_changes.csv |
| Fault recovery & reconfiguration (15%) | relay failure, link degradation, battery fault | detection delay, recovery time, communication recovery success, success before/after failure |
| Safety & collision avoidance (10%) | altitude layers, onboard avoidance, geofence, battery RTH | collisions (0), min separation, violations, geofence violations (0), lowest battery |
| Innovation & technical merit (5%) | peer (distributed) relay election without GCS contact; partition inference from route records; passive liveness from forwarded packets; GCS-side battery drain estimation; ETX routing with estimator lag; evidence-based test harness | see ARCHITECTURE.md §5-9 |

## Performance metrics (rulebook list)

| Metric | Where |
|---|---|
| Mission completion rate | summary `mission.completion_rate` |
| Completion time | `mission.completion_time_s`, `mission.mission_duration_s` |
| Priority-weighted mission score | `mission.priority_weighted_score` |
| Packet delivery ratio | `communication.packet_delivery_ratio` (+ per type) |
| Communication latency | `communication.average_latency_ms`, `p95_latency_ms`, `max_latency_ms` |
| Connectivity availability | `communication.connectivity_availability` |
| Communication downtime | `communication.communication_downtime_s` (+ per UAV, longest outage) |
| Number of relay reallocations | `autonomy.relay_reallocation_count`, `relay_changes.csv` |
| Recovery time | `autonomy.recovery_time_s`, `failures.csv` |
| Network reconfiguration efficiency | `autonomy.reconfiguration_count`, detection delay + recovery time per fault |
| Performance after UAV/link failures | `robustness.mission_success_after_failure`, `communication_recovery_success` |
| Collision count | `safety.collision_count` |
| Minimum inter-UAV separation | `safety.minimum_inter_uav_distance_m` |
| Battery safety | `battery.lowest_battery_pct`, `battery.depleted_uavs` |
| Geo-fence compliance | `safety.geofence_violations`, `safety.geofence_warnings` |

## Stage-1 deliverables

| Deliverable | Where |
|---|---|
| Software architecture | [ARCHITECTURE.md](ARCHITECTURE.md) |
| Working proof-of-concept simulation | `./scripts/run_stage1_demo.sh` |
| Source code | `src/`, `scripts/`, `launch/`, `tests/` (git history) |
| Installation instructions | [INSTALLATION.md](INSTALLATION.md), [REPRODUCIBILITY.md](REPRODUCIBILITY.md), `install.sh`, `run_demo.sh` |
| Demonstration video | recording guide: [DEMO_GUIDE.md](DEMO_GUIDE.md) |
| Technical proposal (6-8 pages) | material: ARCHITECTURE.md, METRICS.md, this file, `results/final_validation_report.md` |
