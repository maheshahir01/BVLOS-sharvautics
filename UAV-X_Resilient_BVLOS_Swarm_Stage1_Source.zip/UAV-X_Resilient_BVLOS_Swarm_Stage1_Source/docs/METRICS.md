# Performance Metrics

All metrics are computed automatically after every run by `core/metrics.py` (in the
`metrics_logger` node) from recorded data: the emulator's packet counters, routing tables,
the onboard vehicle states and the event stream. Nothing is estimated after the fact.
Results are in `results/runs/<run_id>/summary.json` and `report.md` (`results/latest` points
to the newest run).

## Mission

| Metric | Definition | Source |
|---|---|---|
| `completion_rate` | PoIs whose survey report **reached the GCS** ÷ PoIs in the mission (announced, not rejected) | GCS `POI_COMPLETED` events, `/swarm/status` |
| `completion_time_s` | mission start → last PoI report received (`ALL_POIS_COMPLETED`) | events |
| `mission_duration_s` | mission start → all surviving UAVs landed (`MISSION_COMPLETE`) | events |
| `priority_weighted_score` | Σ weight(completed) ÷ Σ weight(all); LOW 1, MEDIUM 2, HIGH 3, CRITICAL 5 | PoI states |

## Communication

| Metric | Definition | Source |
|---|---|---|
| `packet_delivery_ratio` | end-to-end unicast packets delivered ÷ sent (TELEMETRY, REPORT, ACK, CMD, GCS_HB). Losses include "no route" drops during partitions | comm_manager counters |
| `average_latency_ms`, `p95_latency_ms`, `max_latency_ms` | end-to-end latency of delivered unicast packets (sum of per-hop latency + jitter) | comm_manager counters / 5 ms histogram |
| `connectivity_availability` | Σ time airborne UAVs had a route to the GCS ÷ Σ time airborne (failed UAVs excluded after failure), sampled at 2 Hz | routing table + onboard states |
| `communication_downtime_s` | Σ over UAVs of airborne time without a route to the GCS (UAV-seconds). Also per UAV, and the longest outage | same |
| `per_type` | sent / delivered / PDR per packet type (incl. one-hop BEACONs) | comm_manager counters |

The GCS also measures PDR per UAV in a 10 s window for its decisions (`communication.csv`,
column `gcs_pdr`), and classifies each link GOOD / WARNING / DEGRADED / FAILED /
DISCONNECTED.

## Autonomy (relay & role management)

| Metric | Definition |
|---|---|
| `relay_reallocation_count` | relay changes after the initial selection (`RELAY_CHANGED` with an old relay) |
| `task_reallocation_count` | tasks released from a UAV (failure, RTH, becoming relay) or pre-empted |
| `reconfiguration_count` | completed network reconfigurations (`RECONFIG_COMPLETE`) |
| `recovery_time_s` | per injected fault, fault injection → recovery (see below) |

## Fault recovery (per injected fault, `failures.csv`)

* **Detection delay**: injection → first event showing the system noticed it for that UAV
  (`HEARTBEAT_LOST`, `LINK_WARNING/DEGRADED/FAILED`, `RELAY_INVALID`, `BATTERY_ANOMALY`, ...).
* **Recovery time**:
  * UAV failure / communication degradation or outage: injection → first `RECONFIG_COMPLETE`
    after detection. This requires a relay assigned with a healthy link, and every surviving
    airborne UAV connected with fresh telemetry and a GOOD/WARNING link, held for 2 s.
  * Battery fault: injection → the UAV's released tasks re-assigned to another UAV (or its
    return-to-home, if it had no tasks).
* `communication_recovery_success`: fraction of injected faults that recovered.

## Safety

| Metric | Definition | Source |
|---|---|---|
| `collision_count` | pairs of airborne UAVs closer than 1.5 m (edge-triggered per encounter) | onboard positions, 2 Hz |
| `minimum_inter_uav_distance_m` | minimum 3-D distance between any two airborne UAVs over the run | same |
| `separation_violations` | encounters closer than the 5 m minimum safe distance | same |
| `avoidance_activations` | onboard avoidance engagements (one per encounter) | events |
| `geofence_violations` / `geofence_warnings` | airborne UAV outside the fence / within 15 m of a face | onboard positions |

## Battery

`lowest_battery_pct` per UAV, `rth_events` (low-battery returns), `battery_warnings`,
`depleted_uavs` (must be empty).

## Robustness

| Metric | Definition |
|---|---|
| `mission_success_before_failure` | PoIs completed before the first injected failure ÷ PoIs known then (progress when the failure hit) |
| `mission_success_after_failure` | PoIs completed after the first failure ÷ PoIs remaining at that time |
| `communication_recovery_success` | recovered faults ÷ injected faults |

## Software health

`software_errors`: exceptions caught in any node callback (each is also a `SOFTWARE_ERROR`
event on the console). A validated run has 0.

## Where to find them

```
results/latest/report.md          # human-readable tables
results/latest/summary.json       # all metrics, machine-readable
results/latest/*.csv, events.json # raw evidence
```
Live values are shown on the dashboard (`http://localhost:8080`).
