# UAV-X Swarm: Technical Architecture

This document describes what is implemented and how it works. Every algorithm named here
exists in `src/uav_x_swarm/uav_x_swarm/core/` (pure Python, unit-tested) and runs inside the
ROS 2 nodes in `src/uav_x_swarm/uav_x_swarm/nodes/`.

## 1. System architecture

```mermaid
flowchart LR
  subgraph SIM["Simulation (ROS-free environment)"]
    GZ["Gazebo Jetty server<br/>world: disaster_zone<br/>physics, IMU, baro, mag, GPS"]
    PX1["PX4 SITL #0<br/>MAV_SYS_ID 1"]
    PX2["PX4 SITL #1<br/>MAV_SYS_ID 2"]
    PX3["PX4 SITL #2<br/>MAV_SYS_ID 3"]
    PX4N["PX4 SITL #3<br/>MAV_SYS_ID 4"]
    GZ <-->|gz-transport<br/>x500_0..3| PX1 & PX2 & PX3 & PX4N
  end
  subgraph ONBOARD["Onboard companion software (one per UAV, ROS 2 ns /uavN)"]
    A1["uav_agent /uav1"]
    A2["uav_agent /uav2"]
    A3["uav_agent /uav3"]
    A4["uav_agent /uav4"]
  end
  PX1 <-->|MAVLink UDP 14540| A1
  PX2 <-->|MAVLink UDP 14541| A2
  PX3 <-->|MAVLink UDP 14542| A3
  PX4N <-->|MAVLink UDP 14543| A4
  NET(["comm_manager<br/>radio network emulator<br/>link model + ETX routing"])
  A1 & A2 & A3 & A4 <-->|/net/tx, /net/rx/uavN| NET
  subgraph GROUND["Ground Control Station"]
    GCS["gcs<br/>mission, reports, ACKs,<br/>GCS beacons, new PoIs"]
    SM["swarm_manager<br/>mission / relay / tasks /<br/>failure / battery / geofence"]
  end
  NET <-->|/net/rx/gcs, /net/tx| GCS & SM
  SCN["scenario_runner<br/>fault injection"] -.->|/uavN/inject, /network/inject, /gcs/inject| A1 & NET & GCS
  MET["metrics_logger<br/>CSV / JSON / report"]
  DASH["dashboard<br/>http://localhost:8080"]
  SM -->|/swarm/status| MET & DASH
  NET -->|/network/state| MET & DASH
```

Separation of concerns (spec §40):

| Layer | Component | Responsibility |
|---|---|---|
| Physics / world | Gazebo Jetty (`gz-sim 10.5`) | rigid-body dynamics, sensors (IMU, baro, mag, GPS), world |
| Flight control | PX4 v1.18.0-rc1 SITL (x500 quadrotor) | estimation (EKF2), position/attitude control, arming, landing |
| Middleware | ROS 2 Lyrical (Fast DDS), domain 42, localhost discovery | all inter-node topics |
| Vehicle interface | `px4/link.py` (pymavlink) | MAVLink offboard setpoints, mode/arm/land, telemetry decoding |
| Onboard autonomy | `uav_agent` node | task execution, battery, RTH, geofence clamp, avoidance, lost-link, store-and-forward |
| Communication | `comm_manager` node + `core/network.py`, `core/comm.py` | link model, loss/latency, routing, delivery, statistics |
| Decision-making | `swarm_manager` node | mission state machine, relay selection/placement, task allocation, failure detection, battery/geofence/collision managers |
| Operator interface | `gcs` node, `dashboard` node | mission definition, report reception, emergency PoIs, visualisation |
| Evaluation | `metrics_logger` node + `core/metrics.py` | structured logs, performance metrics, per-run report |
| Test / fault injection | `scenario_runner` node + `core/scenario.py` | declarative scenarios, no source edits |

Mission logic never lives in Gazebo plugins. Gazebo and PX4 are unmodified upstream builds.

## 2. ROS 2 node and topic graph

```mermaid
flowchart TB
  subgraph uavN["/uavN (N = 1..NUM_UAVS)"]
    AG[uav_agent]
  end
  AG -->|state, position, velocity, battery,<br/>role, mission_status, radio| T1[(/uavN/*)]
  CM[comm_manager] -->|communication| T1
  AG -->|/net/tx| CM
  CM -->|/net/rx/uavN| AG
  CM -->|/net/rx/gcs| GCS[gcs] & SM[swarm_manager]
  GCS -->|/net/tx| CM
  SM -->|/net/tx| CM
  GCS -->|/gcs/mission latched| SM
  SM -->|/mission/start latched| AG & CM & GCS & SR[scenario_runner] & ML[metrics_logger]
  SM -->|/swarm/status| ML & DB[dashboard] & SR
  CM -->|/network/state| ML & DB
  SR -->|/uavN/inject| AG
  SR -->|/network/inject| CM
  SR -->|/gcs/inject| GCS
  AG & CM & GCS & SM & SR -->|/events| ML & DB
  T1 --> ML & DB & CM
```

Per-UAV topics required by the spec (all published, verified by TEST 7):

| Topic | Type | Publisher | Content |
|---|---|---|---|
| `/uavN/state` | `std_msgs/String` (JSON) | uav_agent | full onboard state (position, velocity, battery, role, flight state, tasks, radio, geofence, avoidance) at 10 Hz |
| `/uavN/position` | `geometry_msgs/PointStamped` | uav_agent | world ENU position (frame `world`) |
| `/uavN/velocity` | `geometry_msgs/Vector3Stamped` | uav_agent | world ENU velocity |
| `/uavN/battery` | `sensor_msgs/BatteryState` | uav_agent | simulated battery (0..1) |
| `/uavN/role` | `std_msgs/String` (latched) | uav_agent | SURVEY / RELAY / RETURN_HOME / ... |
| `/uavN/communication` | `std_msgs/String` (JSON) | comm_manager | route to GCS, hops, route quality/latency, neighbours, injected impairments |
| `/uavN/mission_status` | `std_msgs/String` (JSON) | uav_agent | current task, queue, completed, pending reports |

Radio traffic uses JSON packets `{id, src, dst, type, seq, t_sent, payload}` on `/net/tx`.
The emulator adds `{route, hops, latency_ms, t_rx}` on delivery. Packet types:
`TELEMETRY` (UAV→GCS, 2 Hz), `REPORT` (survey report, retransmitted until `ACK`),
`ACK`, `CMD` (GCS→UAV, reliable with retries), `GCS_HB` (GCS beacon 1 Hz),
`BEACON` (UAV one-hop broadcast 2 Hz), `EVENT`.

## 3. PX4 architecture (per vehicle)

* `scripts/start_simulation.sh` starts the Gazebo server with `worlds/disaster_zone.sdf`, then
  N instances of `px4 -d -i <k-1> -w .run/px4/uav<k> build/px4_sitl_default/etc` in
  **standalone** mode (`PX4_GZ_STANDALONE=1`, `PX4_SIM_MODEL=gz_x500`,
  `PX4_GZ_MODEL_POSE=<home>`). Each instance spawns and binds its own model `x500_<k-1>`.
* Unique per UAV: instance number, `MAV_SYS_ID = k`, MAVLink onboard link UDP `14540+k-1`,
  model name, working directory (fresh each run → no persisted parameters), ROS namespace.
* Parameters are set reproducibly with `PX4_PARAM_<NAME>` environment variables from
  `config/swarm.yaml` (`sim.px4_params`): no RC/datalink failsafes in simulation,
  offboard-loss → Hold.
* `uav_agent` uses **offboard position + velocity setpoints** (`SET_POSITION_TARGET_LOCAL_NED`)
  at 20 Hz, a moving "carrot" setpoint limited to 12 m ahead of the vehicle, and
  `MAV_CMD_NAV_LAND` for landing (PX4 AUTO.LAND, auto-disarm).
* Frames: PX4 local NED with origin at the spawn pad ↔ world ENU:
  `world = home + (E, N, -D)`. Verified in TEST 6 against Gazebo ground truth.
* The link filters by source system ID. A MAVLink message from a different vehicle on the
  wrong port is reported and ignored, so one controller can never drive another UAV.

## 4. Gazebo architecture

* World generated by `scripts/tools/generate_world.py` from `config/swarm.yaml` +
  `config/mission_pois.yaml`, so markers, pads, GCS and geofence always match the
  coordinates the software uses. The world has 11 static models with primitive shapes (terrain,
  roads, geofence stripes + corner posts, GCS command post + antenna mast, 4 launch pads,
  about 60 buildings, some collapsed, rubble, 6 PoI markers coloured by priority).
* Only the systems the x500 needs are loaded (physics, user commands, scene broadcaster,
  IMU, air pressure, NavSat, magnetometer). No rendering sensors, so the server runs headless
  at real-time factor 1.0 with 4 vehicles.
* The optional GUI (`--gui`) is a separate `gz sim -g` process using WSLg + Mesa d3d12
  (hardware OpenGL on the laptop's iGPU).
* A runtime PoI (POI7) is shown by spawning its marker through `/world/<w>/create`.
* Visualization only: the GUI camera is driven by `scripts/tools/swarm_camera.py` (Gazebo
  ground-truth poses → `/gui/move_to/pose`; behind the swarm, minimum distance that frames all
  UAVs), and the drones are drawn 6× larger through a generated `models/x500_base` that
  shadows PX4's on the resource path and differs only in `<visual>` elements (verified).

## 5. Communication architecture (what is simulated)

Implemented in `core/network.py`, `core/comm.py` and `nodes/comm_manager.py`. It is a
mathematical channel + network-layer model, not RF propagation (documented honestly):

**Link model (per hop)**, with d = 3-D distance and R = range (250 m GCS↔UAV, 180 m UAV↔UAV):

* unavailable if d > R or either radio is down;
* loss(d) = 0.01 + 0.20 · ramp(d), ramp(d) = 0 for d ≤ 0.6R, else ((d − 0.6R)/(0.4R))²;
* injected impairments combine as independent loss: 1 − (1−loss)(1−inj_a)(1−inj_b);
* latency = 6 ms air/MAC + 4 ms forwarding + injected latency + U(0, 6 ms) jitter per hop;
* quality q = 1 − loss.

**Network graph and routing.** Nodes are the GCS and all UAVs. Every 100 ms each link is
re-evaluated from current positions. A routing layer estimates link quality from simulated
hellos (5 Hz, EWMA α = 0.12, so estimates lag reality like a real protocol) and computes
**ETX shortest paths** (cost Σ 1/q̂). A link leaves the routing table when q̂ < 0.25 and
re-enters only above 0.35 (usability hysteresis). Route hysteresis keeps a valid route
unless the new one is more than 15% cheaper. Each unicast packet follows the
current route. Every hop is a Bernoulli trial with the *true* loss, and the packet is
delivered after the summed latency. Broadcast beacons reach one-hop neighbours only.
Because of this, a UAV beyond direct range of the GCS reaches it through the relay,
through a chain of UAVs, or not at all:

```mermaid
flowchart RL
  U3[UAV3 at far PoI] -->|hop 1| U2[UAV2 surveying] -->|hop 2| U1[UAV1 relay] -->|hop 3| G[GCS]
  U4[UAV4] -->|hop 1| U1
```

Observed in the runs: routes of up to 4 hops (`UAV4 → UAV1 → UAV2 → UAV3 → GCS`).

**Measured, not assumed.** The GCS measures each UAV's end-to-end packet delivery ratio
(PDR) from received telemetry over a 10 s window, plus latency from the delivered packets. It
classifies the result GOOD ≥ 0.80 > WARNING ≥ 0.60 > DEGRADED ≥ 0.30 > FAILED, or
DISCONNECTED when nothing is heard. Classification has hysteresis (recovery needs +0.05)
and a 1.5 s debounce. Metrics come from the emulator's packet counters.

**Store-and-forward (delay-tolerant) reports.** Survey reports stay in the UAV's outbox and
are retransmitted every 2 s until the GCS ACK arrives. A PoI is COMPLETE only when its report
reached the GCS.

## 6. Relay selection algorithm (`core/relay.py`)

Suitability score, with inputs normalised to [0, 1] and weights from `config/swarm.yaml`:

```
score = 0.25·link_quality + 0.25·battery + 0.15·connectivity + 0.25·position
        − 0.05·latency − 0.05·mission_load
link_quality = measured end-to-end PDR       battery  = (b − rth)/(100 − rth)
connectivity = UAV neighbours heard/(N−1)    position = 1 − dist(UAV, relay point)/(2·R_gcs)
latency      = mean latency/250 ms           mission_load = (queued + active tasks)/max_queue
```

Eligibility: not LOST/FAILED, heard by the GCS (not DISCONNECTED), battery ≥ 40%, not
returning home or landing. **Hysteresis**: a healthy relay is replaced only if beaten by
0.10, and at most every 45 s. Failures bypass both. A new relay gets a 15 s grace period
before its measured link is judged, because the window still contains pre-assignment
history. Every change is logged with old relay, new relay, reason, scores, detection time
and change time (`relay_changes.csv`).

**Relay placement** is a grid search (15 m) over positions within 85% of the GCS range and
inside the geofence. Candidates are ranked lexicographically by (1) survey positions (current
positions + current targets of survey UAVs) covered **directly**, (2) positions connected
through any multi-hop path, (3) total ETX, (4) distance to the current relay point. The relay
moves only if the new point is at least 30 m away and strictly better (more coverage or
≥ 25% lower ETX), evaluated at most every 10 s. LOST survey UAVs are included with their last
known position, so the relay moves toward a UAV that flew out of range.

A relay is required only if some task lies more than 200 m from the GCS. Otherwise the
relay UAV is released to survey.

## 7. Failure detection and recovery (`core/failure.py`, `core/lostlink.py`)

```mermaid
sequenceDiagram
  participant R as Relay UAV (fails)
  participant S as Survey UAVs (partitioned)
  participant G as GCS / swarm_manager
  R--xG: telemetry stops (radio silent)
  Note over G: t+3 s HEARTBEAT_LOST (relay).<br/>Other UAVs lost too, but their last route<br/>went through the relay: PARTITIONED, not failed
  Note over S: t+6 s no GCS beacon: lost-link procedure.<br/>Peer election on one-hop beacons:<br/>score = 0.6·position + 0.4·battery
  S->>S: winner = BRIDGE, flies to the relay point.<br/>Others CONTINUE tasks (store-and-forward)
  S->>G: bridge in GCS range: routes restored<br/>(forwarded packets prove the bridge alive)
  G->>S: adopt bridge as relay (PEER_ELECTED), re-plan tasks
  Note over G: relay declared FAILED (10 s),<br/>RECONFIG_COMPLETE when all survivors connected<br/>with fresh, GOOD/WARNING links for 2 s
```

1. **Detection**: no telemetry for 3 s → LOST. UAVs whose last route passed through another
   lost UAV are *partitioned* (re-evaluated every cycle, because the relay may time out a
   moment later). The way the link died and where the UAV was last seen are used as
   evidence. **Abrupt** silence of a UAV well inside coverage means a failure is likely, so
   it is FAILED after 10 s. A **fade** (link already DEGRADED, or last seen within 20% of the
   radio range limit of its best link partner) and a partition are confirmed only after
   30 s. Any UAV heard again is RECONNECTED; packets it forwards for others also prove it is
   alive.
2. **Impact**: cut vertices of the network graph identify which UAVs depend on which relay.
3. **Onboard lost-link** (no GCS contact for 6 s): a relay flies toward the GCS. Survey UAVs
   that can hear each other elect a bridge deterministically (same data, same answer, no
   extra negotiation). An isolated UAV finishes only the survey in progress (the data waits in
   its store-and-forward outbox), then flies back into coverage for new orders, instead of
   working through its queue out of contact. After 90 s any UAV returns home.
4. **Relay replacement at the GCS**: a peer-elected bridge is adopted first. Otherwise the
   best-scored eligible UAV is chosen, after a 2 s hold following reconnections so the
   bridge's telemetry can arrive. The old relay goes home only if its radio fault is specific
   to it; otherwise it returns to surveying.
5. **Task reassignment**: tasks of FAILED, returning or re-roled UAVs are released and
   re-auctioned. LOST (possibly just partitioned) UAVs keep their tasks.
6. **Communication degradation** (not only total loss): a relay whose measured link becomes
   DEGRADED is replaced immediately.

## 8. Mission allocation (`core/allocation.py`, `core/priority.py`)

Greedy **priority-first insertion auction**, re-run every 0.5 s:

* pending PoIs are sorted by priority weight (LOW 1, MEDIUM 2, HIGH 3, CRITICAL 5), then
  announcement time;
* candidates: healthy, reachable, not relay/returning, queue < 3, battery above warning;
* priority order inside a queue is a hard constraint;
* HIGH/CRITICAL: earliest allowed slot, cost = distance until served (+60 m if it pre-empts
  a running lower-priority survey, so an idle UAV nearby is preferred). This minimises
  response time;
* others: cost = total route length after insertion + 40 m × queue length (minimises
  makespan, spreading work over the swarm);
* **energy feasibility**: after flying to and surveying the PoI (with the GCS-estimated
  drain factor), the UAV must still be above its RTH threshold there;
* pre-empted surveys are re-queued, never lost. New PoIs are validated against the
  geofence and rejected if outside it;
* an idle survey UAV waits 10 s, then moves to a standby point 50 m on the GCS side of the
  relay point (offset 25 m per UAV). It stays in coverage there, ready for new tasks.

## 9. Battery management (`core/battery.py`)

* Deterministic onboard model: drain = [0.09 %/s airborne + 0.012 %/m flown + 0.02 %/s relay
  radio + 0.02 %/s survey payload] × fault multiplier. No drain on the ground.
* **RTH threshold** = max(30%, 1.25 × energy_to_home + critical 15% + reserve 10%). A UAV
  that turns home at the threshold therefore arrives above 25%. This is property-tested
  for 0–600 m and 1–4× drain.
* Onboard: WARNING at 40%, autonomous RTH at the threshold (also without GCS contact),
  emergency land at 15%.
* GCS: `DrainEstimator` compares observed drain with the model for the reported speed and
  role, reports step drops (cell failure) as BATTERY_ANOMALY, and feeds the estimated
  drain factor into task feasibility and the GCS-side RTH threshold.
* Relay eligibility requires ≥ 40% battery. An RTH relay is replaced immediately.

## 10. Collision avoidance (`core/collision.py`)

* **Strategic**: each UAV cruises on its own altitude layer (25/30/35/40 m).
* **Tactical (onboard, decentralised, predictive)**: each UAV uses detect-and-avoid sensing of
  neighbour positions and velocities (independent of the lossy radio). A neighbour is a threat
  if it is within 12 m, **or** if the predicted closest point of approach within the next 4 s
  (constant-velocity extrapolation) is closer than 1.6 × the 5 m minimum safe distance. The UAV
  adds up to 6 m/s of avoidance velocity, directed away from the predicted closest-approach
  point, with a deterministic vertical split (the lower index climbs) and a right-hand turn
  when closing. Both UAVs reach the same decision without messages.
  Result in the head-on stress scenario (same altitude, 16 m/s closing): threat detected at
  about 53 m, minimum separation 7.5 m (it was 2.05 m with proximity-only avoidance).
  Kinematic unit tests cover head-on, 90° crossing and three-UAV encounters.
* Monitoring: pairwise separation of airborne UAVs. Violations (< 5 m) and collisions
  (< 1.5 m) are counted edge-triggered. The minimum separation is logged in `safety.csv`.

## 11. Geo-fencing (`core/geofence.py`)

Box x ∈ [−60, 460], y ∈ [−230, 230], z ≤ 60 m (ENU). Three layers: planning (PoIs outside
are rejected), onboard setpoint clamping 5 m inside the fence (an operator command to a point
outside is clamped), and monitoring (WARNING within 15 m of a face, BREACH → RTH, counted as a
violation).

## 12. Mission state machine (`core/mission.py`)

```mermaid
stateDiagram-v2
  [*] --> INITIALIZING
  INITIALIZING --> TAKEOFF: all UAVs READY (or timeout with >= 2)
  TAKEOFF --> FORMATION: all at their altitude layers
  FORMATION --> DEPLOY: plans sent
  DEPLOY --> SURVEY: first survey started
  SURVEY --> RECONFIGURING: UAV lost / relay invalid
  RECONFIGURING --> SURVEY: network reconfigured
  SURVEY --> EMERGENCY: new HIGH/CRITICAL PoI
  EMERGENCY --> SURVEY: priority task assigned
  SURVEY --> RETURN_HOME: all PoIs reported
  RECONFIGURING --> RETURN_HOME
  RETURN_HOME --> LAND: all UAVs landing (relay last)
  LAND --> MISSION_COMPLETE: all landed, all PoIs complete
  SURVEY --> MISSION_FAILED: timeout
```

Transitions are validated against an explicit table (an illegal transition raises), and
every transition is logged with its reason.

## 13. Logging architecture

* Every node publishes structured events on `/events`:
  `{t, mission_time, event_type, category, uav_id, message, source, details}`.
* `metrics_logger` writes per run to `results/runs/<run_id>/` (and `results/latest`):
  `events.json(l)`, `mission.csv`, `communication.csv`, `battery.csv`, `safety.csv`,
  `failures.csv`, `relay_changes.csv`, `summary.json`, `report.md`, `console.txt`, plus
  the PX4/Gazebo/ROS logs of that run.
* All callbacks are guarded: an exception becomes a `SOFTWARE_ERROR` event (visible, counted
  in the report). A critical node that exits shuts the launch down, so a run never hangs
  silently.

## 14. Scalability

Nothing is written per UAV. `swarm.number_of_uavs` in `config/swarm.yaml` drives the PX4
instances, ports, system IDs, models, pads (generated beyond the listed ones), altitude layers,
ROS namespaces, launch file and all algorithms (dictionaries keyed by UAV id). Complexity:
routing O(N²) links per 100 ms plus N Dijkstra runs; relay placement about 800 grid points ×
O(N²). This is comfortable for tens of UAVs. Beyond that, the next steps are a distributed
swarm manager and ns-3 for RF fidelity. Unit tests verify the configuration scales to
N = 7.
