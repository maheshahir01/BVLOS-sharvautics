#!/usr/bin/env bash
# Stage-1 demonstration (spec section 33): Gazebo world + 4 PX4 UAVs + GCS + swarm
# autonomy + relay failure + peer relay election + new CRITICAL PoI + battery fault/RTH
# + mission completion + metrics report.
#
#   ./scripts/run_stage1_demo.sh               # with the Gazebo GUI (if a display is available)
#   ./scripts/run_stage1_demo.sh --headless    # without the Gazebo GUI
#   ./scripts/run_stage1_demo.sh --keep        # leave everything running after MISSION_COMPLETE
#
# Live dashboard: http://localhost:8080   (also from the Windows browser under WSL2)
# Results/report: results/latest/  (report.md, *.csv, events.json)
set -u
source "$(dirname "$0")/lib/common.sh"
cd "$PROJECT_ROOT"
ARGS=(); GUI=1
for a in "$@"; do
  case "$a" in
    --headless) GUI=0 ;;
    *) ARGS+=("$a") ;;
  esac
done
if (( GUI )) && [[ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]]; then ARGS+=(--gui); fi
exec ./scripts/run_scenario.sh scenarios/stage1_demo.yaml "${ARGS[@]}"
