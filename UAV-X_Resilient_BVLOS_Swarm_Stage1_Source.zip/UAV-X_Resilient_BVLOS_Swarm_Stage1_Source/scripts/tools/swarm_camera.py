#!/usr/bin/env python3
"""Gazebo GUI follow camera for the UAV swarm (visualization only).

Keeps the Gazebo GUI camera behind the swarm (on the -x side, i.e. looking east, the
direction in which the UAVs fly out from the GCS toward the disaster zone), elevated,
and aimed at the centre of the formation, at the *minimum* distance that keeps every
UAV inside the field of view with a margin.

It only reads the UAV model poses from Gazebo (ground truth) and calls the GUI's
`/gui/move_to/pose` service. It does not touch PX4, ROS or the swarm software, so
mission behaviour and metrics are unaffected. Runs in the ROS-free simulator
environment (python3-gz-transport15 bindings).

    python3 swarm_camera.py --world disaster_zone --models x500_0 x500_1 x500_2 x500_3
    python3 swarm_camera.py --print-pose x,y,z ...   # compute a static pose (used for the world file)
"""
from __future__ import annotations

import argparse
import math
import time

# Must match <horizontal_fov> of the MinimalScene plugin in the world's <gui> block
# (scripts/tools/generate_world.py).
DEFAULT_HFOV_DEG = 75.0
DEFAULT_PITCH_DEG = 30.0      # camera looks 30 deg down: third-person, formation readable
DEFAULT_ASPECT = 16.0 / 9.0   # conservative: a taller window only adds vertical room
DEFAULT_MARGIN = 0.70         # UAVs stay within the central 70 % of the image
MIN_DISTANCE = 18.0           # never closer than this to the formation centre (m)
MIN_HEIGHT = 8.0              # camera never below this altitude (m)


def frame_swarm(points, pitch_deg=DEFAULT_PITCH_DEG, hfov_deg=DEFAULT_HFOV_DEG, aspect=DEFAULT_ASPECT,
                margin=DEFAULT_MARGIN, min_distance=MIN_DISTANCE, yaw=0.0):
    """Camera pose (x, y, z, roll, pitch, yaw) behind the points, looking along `yaw`,
    tilted down by `pitch`, aimed at the centre of their bounding box, at the smallest
    distance D such that every point lies inside `margin` of the half-FOV, horizontally
    and vertically. Returns (pose, D).

    For a camera at C = T - D*f (T = target, f = unit view direction), a point p has
    depth (p-T).f + D and lateral/vertical offsets (p-T).r, (p-T).u that do not depend
    on D, so each point gives a linear lower bound on D; D is the largest of them."""
    th = math.radians(pitch_deg)
    cy, sy = math.cos(yaw), math.sin(yaw)
    f = (math.cos(th) * cy, math.cos(th) * sy, -math.sin(th))      # forward (looking down)
    r = (sy, -cy, 0.0)                                             # right
    u = (math.sin(th) * cy, math.sin(th) * sy, math.cos(th))       # up
    xs, ys, zs = zip(*points)
    t = ((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, (min(zs) + max(zs)) / 2)
    tan_h = math.tan(math.radians(hfov_deg) / 2) * margin
    tan_v = math.tan(math.radians(hfov_deg) / 2) / aspect * margin
    dist = min_distance
    for p in points:
        d = (p[0] - t[0], p[1] - t[1], p[2] - t[2])
        depth0 = sum(a * b for a, b in zip(d, f))
        lat = abs(sum(a * b for a, b in zip(d, r)))
        ver = abs(sum(a * b for a, b in zip(d, u)))
        dist = max(dist, lat / tan_h - depth0, ver / tan_v - depth0, 5.0 - depth0)
    cam = [t[0] - dist * f[0], t[1] - dist * f[1], t[2] - dist * f[2]]
    cam[2] = max(cam[2], MIN_HEIGHT)
    return (cam[0], cam[1], cam[2], 0.0, th, yaw), dist


def euler_to_quat(roll, pitch, yaw):
    cr, sr = math.cos(roll / 2), math.sin(roll / 2)
    cp, sp = math.cos(pitch / 2), math.sin(pitch / 2)
    cy, sy = math.cos(yaw / 2), math.sin(yaw / 2)
    return (cr * cp * cy + sr * sp * sy, sr * cp * cy - cr * sp * sy,
            cr * sp * cy + sr * cp * sy, cr * cp * sy - sr * sp * cy)   # w, x, y, z


def run(world: str, models: list[str], period: float, smooth: float, args) -> None:
    from gz.msgs.boolean_pb2 import Boolean
    from gz.msgs.gui_camera_pb2 import GUICamera
    from gz.msgs.pose_v_pb2 import Pose_V
    from gz.transport import Node

    node = Node()
    latest: dict[str, tuple] = {}

    def on_poses(msg: Pose_V) -> None:
        for p in msg.pose:
            if p.name in models:
                latest[p.name] = (p.position.x, p.position.y, p.position.z)

    node.subscribe(Pose_V, f"/world/{world}/pose/info", on_poses)
    cam = None
    prev: dict[str, tuple] = {}
    vel: dict[str, tuple] = {}
    last_log = 0.0
    while True:
        time.sleep(period)
        if len(latest) < len(models):
            continue                          # wait until every UAV model exists
        now_pts = {m: latest[m] for m in models}
        for m, p in now_pts.items():          # velocity estimate (low-pass) for look-ahead framing
            if m in prev:
                v = tuple((a - b) / period for a, b in zip(p, prev[m]))
                vel[m] = tuple(0.5 * a + 0.5 * b for a, b in zip(v, vel.get(m, v)))
        prev = now_pts
        pts = list(now_pts.values()) + [tuple(p[i] + args.lookahead * vel.get(m, (0, 0, 0))[i] for i in range(3))
                                        for m, p in now_pts.items()]
        target, dist = frame_swarm(pts, args.pitch, args.hfov, args.aspect, args.margin, args.min_distance)
        if cam is None:
            cam, cam_dist = list(target[:3]), dist
        else:
            # zoom out at once (a UAV must never leave the image), zoom in / pan gently
            tau = 0.25 if dist > cam_dist + 1.0 else smooth
            a = 1.0 - math.exp(-period / tau)
            cam = [c + a * (g - c) for c, g in zip(cam, target[:3])]
            cam_dist += a * (dist - cam_dist)
        req = GUICamera()
        req.pose.position.x, req.pose.position.y, req.pose.position.z = cam
        w, x, y, z = euler_to_quat(*target[3:])
        req.pose.orientation.w, req.pose.orientation.x = w, x
        req.pose.orientation.y, req.pose.orientation.z = y, z
        # The GUI keeps a single pending move and discards one that arrives while a move is
        # still animating (gz-gui CameraTracking), so each move must finish before the next
        # request: animate for 60 % of the period.
        req.duration = 0.6 * period
        try:
            node.request("/gui/move_to/pose", req, GUICamera, Boolean, 1000)
        except Exception:
            pass                              # GUI not up (yet): keep trying
        if time.time() - last_log > 10.0:
            last_log = time.time()
            print(f"camera ({cam[0]:.0f}, {cam[1]:.0f}, {cam[2]:.0f}) distance {dist:.0f} m", flush=True)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--world", default="disaster_zone")
    ap.add_argument("--models", nargs="+", default=[f"x500_{i}" for i in range(4)])
    ap.add_argument("--period", type=float, default=0.5)
    ap.add_argument("--smooth", type=float, default=1.5, help="pan/zoom-in smoothing time constant (s)")
    ap.add_argument("--lookahead", type=float, default=2.0, help="also frame positions this far ahead (s)")
    ap.add_argument("--pitch", type=float, default=DEFAULT_PITCH_DEG)
    ap.add_argument("--hfov", type=float, default=DEFAULT_HFOV_DEG)
    ap.add_argument("--aspect", type=float, default=DEFAULT_ASPECT)
    ap.add_argument("--margin", type=float, default=DEFAULT_MARGIN)
    ap.add_argument("--min-distance", type=float, default=MIN_DISTANCE)
    ap.add_argument("--print-pose", nargs="+", metavar="X,Y,Z",
                    help="print the framing pose for these points and exit")
    a = ap.parse_args()
    if a.print_pose:
        pts = [tuple(float(v) for v in s.split(",")) for s in a.print_pose]
        pose, dist = frame_swarm(pts, a.pitch, a.hfov, a.aspect, a.margin, a.min_distance)
        print(" ".join(f"{v:.3f}" for v in pose))
        return 0
    run(a.world, a.models, a.period, a.smooth, a)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
