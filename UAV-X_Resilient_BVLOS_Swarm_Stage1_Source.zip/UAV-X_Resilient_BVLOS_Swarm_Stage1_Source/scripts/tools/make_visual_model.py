#!/usr/bin/env python3
"""Generate models/x500_base: PX4's x500_base with ENLARGED VISUALS ONLY (demo visibility).

The project's models/ directory comes first on GZ_SIM_RESOURCE_PATH, so when PX4
spawns `x500` (which includes `model://x500_base`), Gazebo loads this copy instead of
PX4's. PX4's own source tree is not modified.

What changes (visual elements only):
  * every <visual> of the drone is scaled by k about the landing-skid contact point
    (mesh <scale> x k, visual position scaled about that point), so the enlarged drone
    still stands on the ground and all parts stay aligned;
  * the propeller / motor-bell visuals are moved from the spinning rotor links to the
    body (same place, same size factor): a visual on a rotor link can only be enlarged
    in place around the physical motor axis, which would leave small propellers
    inside an enlarged frame. At demo viewing distances, propeller spin cannot be seen.
What does NOT change (verified below, the script fails otherwise): links, link poses,
mass, inertia, collision geometry, joints, sensors and their poses, plugins. The script
strips all <visual> elements from the original and the generated model and requires the
remaining XML to be identical.

Usage: make_visual_model.py [--scale K]   (default: sim.uav_visual_scale in config/swarm.yaml)
"""
from __future__ import annotations

import argparse
import copy
import os
import shutil
import sys
import xml.etree.ElementTree as ET

import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
PX4_MODELS = os.path.join(ROOT, "external", "PX4-Autopilot", "Tools", "simulation", "gz", "models")
SRC = os.path.join(PX4_MODELS, "x500_base")
DST = os.path.join(ROOT, "models", "x500_base")
PIVOT = (0.0, 0.0, -0.2270)   # bottom of the landing skids in the base_link frame (collision boxes)


def fl(text: str) -> list[float]:
    return [float(v) for v in text.split()]


def fmt(vals) -> str:
    return " ".join(f"{v:.6g}" for v in vals)


def strip_visuals(model: ET.Element) -> str:
    m = copy.deepcopy(model)
    for link in m.iter("link"):
        for v in list(link.findall("visual")):
            link.remove(v)
    return ET.tostring(m, encoding="unicode")


def scale_visual(vis: ET.Element, k: float, offset=(0.0, 0.0, 0.0)) -> None:
    """Scale one visual by k about PIVOT; `offset` = its link's position in the base frame."""
    pose = vis.find("pose")
    p = fl(pose.text) if pose is not None else [0.0] * 6
    base = [p[i] + offset[i] for i in range(3)]
    scaled = [PIVOT[i] + k * (base[i] - PIVOT[i]) for i in range(3)]
    if pose is None:
        pose = ET.SubElement(vis, "pose")
    pose.text = fmt(scaled + p[3:])
    geo = vis.find("geometry")
    mesh = geo.find("mesh")
    if mesh is not None:
        sc = mesh.find("scale")
        s = fl(sc.text) if sc is not None else [1.0, 1.0, 1.0]
        if sc is None:
            sc = ET.SubElement(mesh, "scale")
        sc.text = fmt([v * k for v in s])
        return
    for tag in ("box", "plane", "cylinder", "sphere"):          # primitive visuals (FMU labels)
        g = geo.find(tag)
        if g is None:
            continue
        for dim in ("size", "radius", "length"):
            d = g.find(dim)
            if d is not None:
                d.text = fmt([v * k for v in fl(d.text)])


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", type=float, default=None)
    a = ap.parse_args()
    k = a.scale
    if k is None:
        cfg = yaml.safe_load(open(os.path.join(ROOT, "config", "swarm.yaml")))
        k = float(cfg.get("sim", {}).get("uav_visual_scale", 1.0))
    if not os.path.isfile(os.path.join(SRC, "model.sdf")):
        print(f"PX4 model not found at {SRC} (run ./install.sh)", file=sys.stderr)
        return 1
    tree = ET.parse(os.path.join(SRC, "model.sdf"))
    model = tree.getroot().find("model")
    original = copy.deepcopy(model)
    base = model.find("link[@name='base_link']")
    moved = 0
    for link in model.findall("link"):
        visuals = link.findall("visual")
        if link is base:
            for v in visuals:
                scale_visual(v, k)
            continue
        lp = link.find("pose")
        lpv = fl(lp.text) if lp is not None else [0.0] * 6
        if any(abs(x) > 1e-9 for x in lpv[3:]):
            print(f"unexpected rotated link {link.get('name')}", file=sys.stderr)
            return 1
        for v in visuals:                      # rotor visuals -> body, scaled about the pivot
            link.remove(v)
            scale_visual(v, k, offset=lpv[:3])
            base.append(v)
            moved += 1
    # --- physics identity check
    if strip_visuals(original) != strip_visuals(model):
        print("REFUSING: non-visual content differs from PX4's x500_base", file=sys.stderr)
        return 1
    os.makedirs(DST, exist_ok=True)
    tree.write(os.path.join(DST, "model.sdf"), encoding="unicode", xml_declaration=True)
    shutil.copyfile(os.path.join(SRC, "model.config"), os.path.join(DST, "model.config"))
    for sub in ("meshes", "materials", "thumbnails"):   # share PX4's assets (no copies)
        link_path = os.path.join(DST, sub)
        if os.path.islink(link_path):
            os.remove(link_path)
        if os.path.isdir(os.path.join(SRC, sub)):
            os.symlink(os.path.relpath(os.path.join(SRC, sub), DST), link_path)
    with open(os.path.join(DST, "README.txt"), "w") as f:
        f.write(f"GENERATED by scripts/tools/make_visual_model.py from PX4 x500_base (visual scale {k:g}).\n"
                "Only <visual> elements differ from PX4's model; physics is verified identical.\n")
    n_vis = len(model.findall(".//visual"))
    print(f"wrote {DST}/model.sdf: {n_vis} visuals scaled x{k:g} ({moved} rotor visuals moved to base_link); "
          f"physics identical to PX4 x500_base: yes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
