#!/usr/bin/env python3
"""Save a screenshot of the Gazebo GUI 3D view (needs the Screenshot GUI plugin).
Usage: gui_screenshot.py [out_dir]   -> prints the saved file path"""
import glob
import os
import sys
import time

from gz.msgs.boolean_pb2 import Boolean
from gz.msgs.stringmsg_pb2 import StringMsg
from gz.transport import Node

out = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser("~/.gz/gui/pictures"))
os.makedirs(out, exist_ok=True)
before = set(glob.glob(os.path.join(out, "*.png")))
req = StringMsg()
req.data = out
ok, rep = Node().request("/gui/screenshot", req, StringMsg, Boolean, 5000)
for _ in range(50):
    new = sorted(set(glob.glob(os.path.join(out, "*.png"))) - before)
    if new:
        print(new[-1])
        sys.exit(0)
    time.sleep(0.1)
print(f"no screenshot saved (service ok={ok})", file=sys.stderr)
sys.exit(1)
