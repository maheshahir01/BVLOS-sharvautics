#!/usr/bin/env python3
"""Generate worlds/<world_name>.sdf from config/swarm.yaml + config/mission_pois.yaml.

The world is deliberately lightweight: all static scenery lives in a handful
of static models built from primitive shapes (no meshes, no rendering sensors), so
the headless Gazebo server spends its CPU on the four vehicles.

Because the world is generated from the same files the swarm software reads,
PoI markers, launch pads, the GCS and the geofence in Gazebo always match
the coordinates the software uses.
"""
from __future__ import annotations

import argparse
import math
import os
import random
import sys

import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

PRIORITY_RGB = {
    "LOW": (0.95, 0.85, 0.10),
    "MEDIUM": (1.00, 0.55, 0.05),
    "HIGH": (0.90, 0.10, 0.10),
    "CRITICAL": (0.75, 0.00, 0.55),
}
UAV_RGB = [(0.1, 0.35, 0.95), (0.1, 0.75, 0.2), (1.0, 0.5, 0.0), (0.6, 0.2, 0.85),
           (0.0, 0.7, 0.7), (0.85, 0.85, 0.1), (0.9, 0.3, 0.5), (0.4, 0.4, 0.4)]


def material(rgb, alpha=1.0, emissive=0.0):
    r, g, b = rgb
    em = f"<emissive>{r*emissive:.3f} {g*emissive:.3f} {b*emissive:.3f} 1</emissive>" if emissive else ""
    return (f"<material><ambient>{r:.3f} {g:.3f} {b:.3f} {alpha}</ambient>"
            f"<diffuse>{r:.3f} {g:.3f} {b:.3f} {alpha}</diffuse>"
            f"<specular>0.1 0.1 0.1 1</specular>{em}</material>")


class Model:
    """Collects primitive visuals/collisions into one static model (one link)."""

    def __init__(self, name: str):
        self.name = name
        self.parts: list[str] = []
        self.n = 0

    def box(self, x, y, z, sx, sy, sz, rgb, yaw=0.0, roll=0.0, pitch=0.0, collide=True, alpha=1.0):
        self.n += 1
        geo = f"<geometry><box><size>{sx:.2f} {sy:.2f} {sz:.2f}</size></box></geometry>"
        pose = f"<pose>{x:.2f} {y:.2f} {z:.2f} {roll:.3f} {pitch:.3f} {yaw:.3f}</pose>"
        s = f"<visual name='v{self.n}'>{pose}{geo}{material(rgb, alpha)}</visual>"
        if collide:
            s += f"<collision name='c{self.n}'>{pose}{geo}</collision>"
        self.parts.append(s)

    def cylinder(self, x, y, z, r, h, rgb, collide=False, emissive=0.0, alpha=1.0):
        self.n += 1
        geo = f"<geometry><cylinder><radius>{r:.2f}</radius><length>{h:.2f}</length></cylinder></geometry>"
        pose = f"<pose>{x:.2f} {y:.2f} {z:.2f} 0 0 0</pose>"
        s = f"<visual name='v{self.n}'>{pose}{geo}{material(rgb, alpha, emissive)}</visual>"
        if collide:
            s += f"<collision name='c{self.n}'>{pose}{geo}</collision>"
        self.parts.append(s)

    def sphere(self, x, y, z, r, rgb, emissive=0.0):
        self.n += 1
        self.parts.append(
            f"<visual name='v{self.n}'><pose>{x:.2f} {y:.2f} {z:.2f} 0 0 0</pose>"
            f"<geometry><sphere><radius>{r:.2f}</radius></sphere></geometry>{material(rgb, 1.0, emissive)}</visual>")

    def sdf(self) -> str:
        return (f"<model name='{self.name}'><static>true</static><link name='link'>"
                + "".join(self.parts) + "</link></model>")


def poi_marker_sdf(poi: dict, name: str | None = None) -> str:
    """A standalone static model for one PoI (also used for runtime spawning)."""
    m = Model(name or f"poi_{poi['id'].lower()}")
    x, y = poi["position"][:2]
    rgb = PRIORITY_RGB.get(poi.get("priority", "MEDIUM"), PRIORITY_RGB["MEDIUM"])
    m.cylinder(0, 0, 0.08, 7.0, 0.16, rgb, alpha=0.85)            # survey area pad
    m.cylinder(0, 0, 0.10, 4.0, 0.20, (1, 1, 1))                    # white inner ring
    m.cylinder(0, 0, 0.12, 3.2, 0.24, rgb)
    m.cylinder(0, 0, 6.0, 0.25, 12.0, (0.9, 0.9, 0.9))              # pole
    m.sphere(0, 0, 12.8, 1.4, rgb, emissive=0.6)                    # beacon
    body = m.sdf().replace("<static>true</static>", f"<static>true</static><pose>{x:.2f} {y:.2f} 0 0 0 0</pose>", 1)
    return body


def build(cfg: dict, pois: list[dict]) -> str:
    rnd = random.Random(7)
    world = cfg["sim"]["world_name"]
    gf = cfg["safety"]["geofence"]
    (x0, x1), (y0, y1) = gf["x"], gf["y"]
    n_uav = int(cfg["swarm"]["number_of_uavs"])
    homes = list(cfg["swarm"]["home_positions"])
    gen = cfg["swarm"].get("pad_generator", {"origin": [35.0, -40.0], "spacing": [0.0, 20.0]})
    while len(homes) < n_uav:
        k = len(homes) - len(cfg["swarm"]["home_positions"])
        homes.append([gen["origin"][0] + k * gen["spacing"][0], gen["origin"][1] + k * gen["spacing"][1]])
    gcs = cfg["gcs"]["position"]

    models: list[str] = []

    # ---------------------------------------------------------------- terrain
    t = Model("terrain")
    t.box((x0 + x1) / 2, 0, -0.05, 1600, 1100, 0.1, (0.42, 0.52, 0.34), collide=False)       # grass
    t.box(305, 0, 0.01, 290, 430, 0.02, (0.55, 0.47, 0.38), collide=False)                    # disaster soil
    road = (0.22, 0.22, 0.24)
    t.box((x0 + 20 + 440) / 2, 0, 0.03, 440 - x0 - 20, 9, 0.02, road, collide=False)                 # main road
    for rx in (215, 300, 395):
        t.box(rx, 0, 0.035, 8, 400, 0.02, road, collide=False)
    for ry in (-95, 60):
        t.box(305, ry, 0.035, 270, 8, 0.02, road, collide=False)
    models.append(t.sdf())

    # ---------------------------------------------------------------- geofence (ground stripes + posts)
    f = Model("geofence")
    yl = (1.0, 0.85, 0.0)
    f.box((x0 + x1) / 2, y0, 0.06, x1 - x0, 1.2, 0.04, yl, collide=False)
    f.box((x0 + x1) / 2, y1, 0.06, x1 - x0, 1.2, 0.04, yl, collide=False)
    f.box(x0, 0, 0.06, 1.2, y1 - y0, 0.04, yl, collide=False)
    f.box(x1, 0, 0.06, 1.2, y1 - y0, 0.04, yl, collide=False)
    for cx in (x0, x1):
        for cy in (y0, y1):
            f.cylinder(cx, cy, 10, 0.6, 20, yl, collide=False, emissive=0.3)
    models.append(f.sdf())

    # ---------------------------------------------------------------- GCS + launch pads
    g = Model("ground_control_station")
    gx, gy = gcs[0], gcs[1]
    g.box(gx - 14, gy, 2.0, 10, 7, 4, (0.92, 0.92, 0.95))                 # command post
    g.box(gx - 14, gy, 4.1, 10.4, 7.4, 0.2, (0.1, 0.3, 0.8))              # roof
    g.cylinder(gx, gy, 6.0, 0.25, 12.0, (0.7, 0.7, 0.7), collide=True)     # antenna mast
    g.sphere(gx, gy, 12.4, 0.7, (0.1, 0.4, 1.0), emissive=0.8)            # antenna head
    g.box(gx - 24, gy + 8, 1.5, 6, 3, 3, (0.35, 0.45, 0.3))                # support vehicle
    for k, (hx, hy) in enumerate(homes[:n_uav]):
        rgb = UAV_RGB[k % len(UAV_RGB)]
        g.cylinder(hx, hy, 0.03, 3.0, 0.06, rgb)
        g.cylinder(hx, hy, 0.04, 2.2, 0.08, (0.95, 0.95, 0.95))
        g.box(hx, hy, 0.09, 0.4, 2.2, 0.02, rgb, collide=False)            # "H" crossbar approximation
        g.box(hx - 0.8, hy, 0.09, 1.8, 0.35, 0.02, rgb, collide=False)
        g.box(hx + 0.8, hy, 0.09, 1.8, 0.35, 0.02, rgb, collide=False)
    models.append(g.sdf())

    # ---------------------------------------------------------------- disaster-zone buildings
    b = Model("disaster_buildings")
    poi_xy = [tuple(p["position"][:2]) for p in pois]
    road_x = (215, 300, 395)
    road_y = (0, -95, 60)
    for bx in range(190, 430, 26):
        for by in range(-195, 200, 26):
            jx, jy = bx + rnd.uniform(-5, 5), by + rnd.uniform(-5, 5)
            if any(math.hypot(jx - px, jy - py) < 28 for px, py in poi_xy):
                continue
            if any(abs(jx - rx) < 12 for rx in road_x) or any(abs(jy - ry) < 12 for ry in road_y):
                continue
            if rnd.random() < 0.35:
                continue
            sx, sy = rnd.uniform(8, 15), rnd.uniform(8, 15)
            h = rnd.uniform(5, 18)
            collapsed = rnd.random() < 0.3
            shade = rnd.uniform(0.45, 0.7)
            rgb = (shade, shade * 0.95, shade * 0.9) if not collapsed else (0.45, 0.38, 0.32)
            if collapsed:
                b.box(jx, jy, h * 0.2, sx, sy, h * 0.4, rgb, yaw=rnd.uniform(0, 3.14),
                      roll=rnd.uniform(-0.25, 0.25), pitch=rnd.uniform(-0.25, 0.25))
            else:
                b.box(jx, jy, h / 2, sx, sy, h, rgb, yaw=rnd.uniform(-0.2, 0.2))
    # rubble near damaged PoIs
    for p in pois:
        if not p.get("initial", True):
            continue
        px, py = p["position"][:2]
        for _ in range(5):
            a, r = rnd.uniform(0, 6.28), rnd.uniform(9, 14)
            b.box(px + r * math.cos(a), py + r * math.sin(a), 0.6, rnd.uniform(1.5, 3.5),
                  rnd.uniform(1.5, 3.5), 1.2, (0.5, 0.42, 0.35), yaw=rnd.uniform(0, 3),
                  roll=rnd.uniform(-0.3, 0.3), collide=False)
    models.append(b.sdf())

    # ---------------------------------------------------------------- PoI markers (initial ones only)
    for p in pois:
        if p.get("initial", True):
            models.append(poi_marker_sdf(p))

    # GUI start camera: behind the launch pads (looking east, the outbound flight direction),
    # framing the UAVs both on the pads and at their cruise altitude layers; the follow
    # camera (scripts/tools/swarm_camera.py) takes over once the simulation runs.
    from swarm_camera import DEFAULT_HFOV_DEG, frame_swarm
    fl = cfg["flight"]
    layer = lambda k: float(fl["cruise_altitude_m"]) + k * float(fl.get("altitude_layer_spacing_m", 0.0))  # noqa: E731
    cam_pts = [(hx, hy, 0.3) for hx, hy in homes[:n_uav]] + \
              [(hx, hy, layer(k)) for k, (hx, hy) in enumerate(homes[:n_uav])]
    cam_pose, _ = frame_swarm(cam_pts)
    cam_pose_str = " ".join(f"{v:.2f}" for v in cam_pose)
    lat = cfg["sim"].get("latitude_deg", 19.1334)      # IIT Bombay, Powai (for GPS realism)
    lon = cfg["sim"].get("longitude_deg", 72.9133)

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!-- GENERATED by scripts/tools/generate_world.py from config/swarm.yaml and
     config/mission_pois.yaml. Do not edit by hand; re-run ./scripts/build.sh. -->
<sdf version="1.9">
  <world name="{world}">
    <physics type="ode">
      <max_step_size>0.004</max_step_size>
      <real_time_factor>1.0</real_time_factor>
      <real_time_update_rate>250</real_time_update_rate>
    </physics>
    <!-- Only the systems PX4's x500 needs (no rendering sensors -> light headless server) -->
    <plugin filename="gz-sim-physics-system" name="gz::sim::systems::Physics"/>
    <plugin filename="gz-sim-user-commands-system" name="gz::sim::systems::UserCommands"/>
    <plugin filename="gz-sim-scene-broadcaster-system" name="gz::sim::systems::SceneBroadcaster"/>
    <plugin filename="gz-sim-contact-system" name="gz::sim::systems::Contact"/>
    <plugin filename="gz-sim-imu-system" name="gz::sim::systems::Imu"/>
    <plugin filename="gz-sim-air-pressure-system" name="gz::sim::systems::AirPressure"/>
    <plugin filename="gz-sim-apply-link-wrench-system" name="gz::sim::systems::ApplyLinkWrench"/>
    <plugin filename="gz-sim-navsat-system" name="gz::sim::systems::NavSat"/>
    <plugin filename="gz-sim-magnetometer-system" name="gz::sim::systems::Magnetometer"/>
    <gravity>0 0 -9.8</gravity>
    <magnetic_field>6e-06 2.3e-05 -4.2e-05</magnetic_field>
    <atmosphere type="adiabatic"/>
    <scene>
      <grid>false</grid>
      <ambient>0.5 0.5 0.5 1</ambient>
      <background>0.62 0.75 0.88 1</background>
      <shadows>false</shadows>
    </scene>
    <gui fullscreen="0">
      <plugin filename="MinimalScene" name="3D View">
        <gz-gui><title>3D View</title><property type="bool" key="showTitleBar">false</property>
          <property type="string" key="state">docked</property></gz-gui>
        <engine>ogre2</engine>
        <scene>scene</scene>
        <ambient_light>0.5 0.5 0.5</ambient_light>
        <background_color>0.62 0.75 0.88</background_color>
        <camera_pose>{cam_pose_str}</camera_pose>
        <horizontal_fov>{DEFAULT_HFOV_DEG:g}</horizontal_fov>
        <camera_clip><near>0.5</near><far>5000</far></camera_clip>
      </plugin>
      <plugin filename="GzSceneManager" name="Scene Manager">
        <gz-gui><property key="state" type="string">floating</property>
          <property key="width" type="double">5</property><property key="height" type="double">5</property>
          <property key="showTitleBar" type="bool">false</property></gz-gui>
      </plugin>
      <plugin filename="InteractiveViewControl" name="Interactive view control">
        <gz-gui><property key="state" type="string">floating</property>
          <property key="width" type="double">5</property><property key="height" type="double">5</property>
          <property key="showTitleBar" type="bool">false</property></gz-gui>
      </plugin>
      <plugin filename="CameraTracking" name="Camera Tracking">
        <gz-gui><property key="state" type="string">floating</property>
          <property key="width" type="double">5</property><property key="height" type="double">5</property>
          <property key="showTitleBar" type="bool">false</property></gz-gui>
      </plugin>
      <plugin filename="Screenshot" name="Screenshot">
        <gz-gui><title>Screenshot</title><property type="bool" key="showTitleBar">false</property>
          <property type="bool" key="resizable">false</property><property type="double" key="height">50</property>
          <property type="double" key="width">50</property><property type="double" key="z">1</property>
          <property type="string" key="state">floating</property>
          <anchors target="3D View"><line own="left" target="left"/><line own="top" target="top"/></anchors></gz-gui>
      </plugin>
      <plugin filename="WorldControl" name="World control">
        <gz-gui><title>World control</title><property type="bool" key="showTitleBar">false</property>
          <property type="bool" key="resizable">false</property><property type="double" key="height">72</property>
          <property type="double" key="width">121</property><property type="double" key="z">1</property>
          <property type="string" key="state">floating</property>
          <anchors target="3D View"><line own="left" target="left"/><line own="bottom" target="bottom"/></anchors></gz-gui>
        <play_pause>true</play_pause><step>true</step><start_paused>false</start_paused>
      </plugin>
      <plugin filename="WorldStats" name="World stats">
        <gz-gui><title>World stats</title><property type="bool" key="showTitleBar">false</property>
          <property type="bool" key="resizable">false</property><property type="double" key="height">110</property>
          <property type="double" key="width">290</property><property type="double" key="z">1</property>
          <property type="string" key="state">floating</property>
          <anchors target="3D View"><line own="right" target="right"/><line own="bottom" target="bottom"/></anchors></gz-gui>
        <sim_time>true</sim_time><real_time>true</real_time><real_time_factor>true</real_time_factor>
      </plugin>
    </gui>
    <light name="sun" type="directional">
      <pose>0 0 500 0 0 0</pose>
      <cast_shadows>false</cast_shadows>
      <intensity>1</intensity>
      <direction>-0.3 0.4 -0.85</direction>
      <diffuse>0.95 0.95 0.95 1</diffuse>
      <specular>0.2 0.2 0.2 1</specular>
    </light>
    <model name="ground_plane">
      <static>true</static>
      <link name="link">
        <collision name="collision">
          <geometry><plane><normal>0 0 1</normal><size>2000 2000</size></plane></geometry>
        </collision>
      </link>
    </model>
    {os.linesep.join('    ' + m for m in models)}
    <spherical_coordinates>
      <surface_model>EARTH_WGS84</surface_model>
      <world_frame_orientation>ENU</world_frame_orientation>
      <latitude_deg>{lat}</latitude_deg>
      <longitude_deg>{lon}</longitude_deg>
      <elevation>10</elevation>
    </spherical_coordinates>
  </world>
</sdf>
"""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(ROOT, "config", "swarm.yaml"))
    ap.add_argument("--pois", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--marker", default=None, help="print a standalone PoI marker SDF for this PoI id")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config))
    pois_path = a.pois or os.path.join(ROOT, cfg["mission"]["pois_file"])
    pois = yaml.safe_load(open(pois_path))["pois"]
    if a.marker:
        poi = next(p for p in pois if p["id"] == a.marker)
        print(f"<?xml version='1.0'?><sdf version='1.9'>{poi_marker_sdf(poi)}</sdf>")
        return 0
    out = a.out or os.path.join(ROOT, "worlds", f"{cfg['sim']['world_name']}.sdf")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as fh:
        fh.write(build(cfg, pois))
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
