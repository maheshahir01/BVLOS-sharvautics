#!/usr/bin/env python3
"""Build results/final_validation_report.md from recorded evidence.

Usage: final_report.py --suite results/tests/<suite> --demo <run_dir_1> [<run_dir_2> ...]
                       [--restart-note "text"]
Every number is read from the suite's test_results.json and the runs' summary.json/meta.json.
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import subprocess

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def sh(cmd: str) -> str:
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception:
        return ""


def fmt(v, unit="", nd=3):
    if v is None:
        return "n/a"
    if isinstance(v, float):
        return f"{v:.{nd}f}{unit}" if abs(v) < 10 else f"{v:.1f}{unit}"
    return f"{v}{unit}"


def run_section(title: str, run_dir: str) -> list[str]:
    s = json.load(open(os.path.join(run_dir, "summary.json")))
    meta = s.get("meta", {})
    m, c, a, sf, b, r = (s[k] for k in ("mission", "communication", "autonomy", "safety", "battery", "robustness"))
    out = [f"### {title}", "",
           f"Run `{meta.get('run_id', os.path.basename(run_dir))}` (scenario `{os.path.basename(meta.get('scenario', ''))}`), "
           f"evidence in `results/runs/{os.path.basename(run_dir)}/`.", "",
           "| Area | Metric | Value |", "|---|---|---|",
           f"| Mission | result | **{m['result']}** |",
           f"| Mission | PoIs completed | {m['pois_completed']}/{m['pois_total']} (rate {fmt(m['completion_rate'])}) |",
           f"| Mission | completion time (all PoIs reported) | {fmt(m['completion_time_s'], ' s')} |",
           f"| Mission | mission duration (start → all landed) | {fmt(m['mission_duration_s'], ' s')} |",
           f"| Mission | priority-weighted score | {fmt(m['priority_weighted_score'])} |",
           f"| Communication | packet delivery ratio | {fmt(c['packet_delivery_ratio'])} ({c['packets_delivered']}/{c['packets_sent']}) |",
           f"| Communication | latency mean / p95 / max | {fmt(c['average_latency_ms'], ' ms', 1)} / {fmt(c['p95_latency_ms'], ' ms', 1)} / {fmt(c['max_latency_ms'], ' ms', 1)} |",
           f"| Communication | connectivity availability | {fmt(c['connectivity_availability'])} |",
           f"| Communication | downtime (UAV-seconds) | {fmt(c['communication_downtime_s'], ' s', 1)} {c['downtime_per_uav_s']} |",
           f"| Swarm | relay changes | {a['relay_reallocation_count']} |",
           f"| Swarm | task reallocations | {a['task_reallocation_count']} |",
           f"| Swarm | network reconfigurations | {a['reconfiguration_count']} |",
           f"| Swarm | recovery times | {a['recovery_time_s']} s |",
           f"| Safety | collisions | {sf['collision_count']} |",
           f"| Safety | minimum inter-UAV separation | {fmt(sf['minimum_inter_uav_distance_m'], ' m')} {tuple(sf['closest_pair'])} |",
           f"| Safety | separation violations (< 5 m) | {sf['separation_violations']} |",
           f"| Safety | avoidance activations | {sf['avoidance_activations']} |",
           f"| Safety | geofence violations / warnings | {sf['geofence_violations']} / {sf['geofence_warnings']} |",
           f"| Battery | lowest battery per UAV | {b['lowest_battery_pct']} |",
           f"| Battery | low-battery RTH events / depleted UAVs | {b['rth_events']} / {b['depleted_uavs'] or 'none'} |",
           f"| Software | caught exceptions | {s.get('software', {}).get('software_errors', 'n/a')} |", ""]
    eps = r.get("episodes", [])
    if eps:
        out += ["Injected failures:", "",
                "| Fault | Target | Injected at (mission s) | Detected by | Detection delay | Recovered by | Recovery time |",
                "|---|---|---|---|---|---|---|"]
        for e in eps:
            out.append(f"| {e['type']} | {', '.join(e['targets'])} | {fmt(e['mission_time_injected'], '', 1)} | "
                       f"{e['detected_by']} | {fmt(e['detection_delay_s'], ' s', 2)} | {e.get('recovered_by')} | "
                       f"{fmt(e['recovery_time_s'], ' s', 1)} |")
        out += ["", f"Mission success before / after first failure: {fmt(r['mission_success_before_failure'])} / "
                    f"{fmt(r['mission_success_after_failure'])}; communication recovery success "
                    f"{fmt(r['communication_recovery_success'])}.", ""]
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", required=True)
    ap.add_argument("--demo", nargs="+", required=True)
    ap.add_argument("--restart-note", default="")
    a = ap.parse_args()
    tr = json.load(open(os.path.join(a.suite, "test_results.json")))
    res = tr["results"]
    n_pass = sum(1 for v in res.values() if v["status"] == "PASS")
    distro = sh("ls /opt/ros | head -1")
    bridge_version = sh("dpkg-query -W -f='${Version}' ros-" + distro + "-ros-gz-bridge")
    lines = [
        "# Final Validation Report: UAV-X Stage-1 Swarm", "",
        f"Generated {datetime.datetime.now().isoformat(timespec='seconds')} by `scripts/tools/final_report.py` "
        "from recorded evidence only.", "",
        "## System", "",
        "| Component | Version |", "|---|---|",
        f"| Ubuntu | {sh('lsb_release -ds')} (kernel {sh('uname -r')}) |",
        f"| ROS 2 | {sh('ls /opt/ros')} |",
        f"| Gazebo | gz-sim {sh('env -i PATH=/usr/bin:/bin gz sim --versions | head -1')} (Jetty) |",
        f"| PX4 | {sh(f'git -C {ROOT}/external/PX4-Autopilot describe --tags')} "
        f"({sh(f'git -C {ROOT}/external/PX4-Autopilot rev-parse --short=12 HEAD')}) |",
        f"| Python | {sh('python3 --version')} |",
        f"| pymavlink | {sh('python3 -c \"import pymavlink; print(pymavlink.__version__)\"')} |",
        f"| ros_gz_bridge | {bridge_version} |",
        f"| Project commit | {sh(f'git -C {ROOT} rev-parse --short HEAD')} |",
        f"| Hardware | {sh('lscpu | grep \"Model name\" | cut -d: -f2 | xargs')}, "
        f"{sh('free -h | awk \"/Mem/{print \\$2}\"')} RAM (WSL2) |", "",
        "## Simulation", "",
        "* 4 PX4 SITL x500 quadrotors (instances 0-3, MAV_SYS_ID 1-4, MAVLink UDP 14540-14543), Gazebo world "
        "`disaster_zone` (GCS, 4 launch pads, geofence 520 m x 460 m x 60 m, about 60 buildings, rubble, roads).",
        "* PoIs: POI1-POI6 at start (priorities LOW..HIGH, 270-390 m from the GCS, beyond the 250 m GCS radio "
        "range), POI7 CRITICAL emerging at runtime.",
        "* Communication: range-limited, distance-dependent loss/latency model with ETX multi-hop routing "
        "(docs/ARCHITECTURE.md §5).", "",
        "## Automated tests", "",
        f"Suite `{os.path.basename(a.suite)}`: **{n_pass}/{len(res)} PASS** "
        f"(details: `results/tests/{os.path.basename(a.suite)}/TEST_RESULTS.md`, copied to `TEST_RESULTS.md`).", "",
        "| Test | Status |", "|---|---|"]
    for k, v in res.items():
        lines.append(f"| {k} | {v['status']} |")
    lines += ["", "## Stage-1 demonstration runs", ""]
    if a.restart_note:
        lines += [a.restart_note, ""]
    for i, d in enumerate(a.demo, 1):
        lines += run_section(f"Demonstration run {i}", d)
    lines += ["## Honest limitations", "",
              "* Communication is a documented mathematical model (range, distance-dependent loss, latency, estimator "
              "lag, routing), not RF propagation. Gazebo does not simulate radio.",
              "* The battery is a deterministic model maintained by each UAV agent, not PX4's simulated battery "
              "(PX4's is held at >= 50 % so it never triggers PX4 failsafes).",
              "* Survey imaging is simulated (orbit + image count); no computer vision.",
              "* Collision avoidance uses simulated detect-and-avoid sensing (true neighbour states), independent "
              "of the radio model.",
              "* Validation was done on WSL2. A full Windows-side `wsl --shutdown` restart could not be performed "
              "from inside the session. The restart test re-ran everything from a clean process state and a "
              "clean colcon rebuild (see above).", ""]
    out = os.path.join(ROOT, "results", "final_validation_report.md")
    open(out, "w").write("\n".join(lines) + "\n")
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
