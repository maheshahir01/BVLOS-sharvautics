#!/usr/bin/env bash
# Final validation procedure (spec section 47), fully automated:
#   1. run ALL tests (TEST 1-21 + unit tests)
#   2. run the Stage-1 demo from a clean login shell
#   3. stop everything and verify nothing is left
#   4. restart from scratch: wipe colcon build/install/log and runtime state, clean rebuild,
#      system check, all from a clean login shell
#   5. run the Stage-1 demo again
#   6. write results/final_validation_report.md from the recorded evidence
#
#   ./scripts/tools/final_validation.sh          (~90 min)
set -u
LOG_TAG=validate
source "$(dirname "$0")/../lib/common.sh"
cd "$PROJECT_ROOT"
V="$LOG_DIR/final_validation"
mkdir -p "$V"

fresh_shell() {   # run a command in a clean login shell (like a new terminal)
  env -i HOME="$HOME" USER="${USER:-$(id -un)}" TERM=xterm-256color LANG=C.UTF-8 \
    PATH=/usr/local/bin:/usr/bin:/bin DISPLAY="${DISPLAY:-}" WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-}" \
    XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-}" bash -l -c "cd '$PROJECT_ROOT' && $1"
}

c_info "1/6 full automated test suite"
./scripts/run_tests.sh > "$V/1_tests.log" 2>&1
suite_rc=$?
# newest timestamped suite directory (YYYYmmdd_HHMMSS); other folders under results/tests are ignored
SUITE="$(ls -d "$PROJECT_ROOT"/results/tests/[0-9]*_[0-9]*/ 2>/dev/null | sort | tail -1)"; SUITE="${SUITE%/}"
tail -1 "$V/1_tests.log"

c_info "2/6 Stage-1 demo from a clean login shell"
./scripts/stop_all.sh --force > /dev/null 2>&1
fresh_shell "./scripts/run_stage1_demo.sh" > "$V/2_demo1.log" 2>&1
demo1_rc=$?
DEMO1="$(readlink -f results/latest)"
tail -1 "$V/2_demo1.log"

c_info "3/6 stop everything"
./scripts/stop_all.sh > "$V/3_stop.log" 2>&1; stop_rc=$?
left="$(pgrep -a -x px4; pgrep -a gz-sim-main)"
[[ -z "$left" ]] && echo "no PX4/Gazebo processes left" >> "$V/3_stop.log" || { echo "LEFT: $left" >> "$V/3_stop.log"; stop_rc=1; }
cat "$V/3_stop.log"

c_info "4/6 restart from scratch (wipe build/install/log/.run, clean rebuild, system check)"
rm -rf build install log "$RUN_DIR"
rm -f /tmp/px4_lock-* /tmp/px4-sock-* 2>/dev/null
fresh_shell "./scripts/build.sh --clean && ./scripts/check_system.sh" > "$V/4_rebuild.log" 2>&1
rebuild_rc=$?
tail -2 "$V/4_rebuild.log"

c_info "5/6 Stage-1 demo again"
fresh_shell "./scripts/run_stage1_demo.sh" > "$V/5_demo2.log" 2>&1
demo2_rc=$?
DEMO2="$(readlink -f results/latest)"
tail -1 "$V/5_demo2.log"

c_info "6/6 final report"
note="Procedure (\`scripts/tools/final_validation.sh\`): full test suite (exit $suite_rc) → demo run 1 from a clean login shell (exit $demo1_rc) → \`stop_all.sh\` (exit $stop_rc, no PX4/Gazebo processes left) → wiped \`build/ install/ log/ .run/\` and PX4 lock files, clean \`colcon\` rebuild + system check from a clean login shell (exit $rebuild_rc) → demo run 2 (exit $demo2_rc). Logs: \`logs/final_validation/\`."
python3 scripts/tools/final_report.py --suite "$SUITE" --demo "$DEMO1" "$DEMO2" --restart-note "$note"
report_rc=$?
cp "$SUITE/TEST_RESULTS.md" "$PROJECT_ROOT/TEST_RESULTS.md" || report_rc=1
if (( suite_rc == 0 && demo1_rc == 0 && stop_rc == 0 && rebuild_rc == 0 && demo2_rc == 0 && report_rc == 0 )); then
  c_ok "FINAL VALIDATION PASSED"; exit 0
fi
c_err "FINAL VALIDATION FAILED (suite=$suite_rc demo1=$demo1_rc stop=$stop_rc rebuild=$rebuild_rc demo2=$demo2_rc report=$report_rc)"
exit 1
