#!/usr/bin/env python3
"""Print the per-UAV simulation plan derived from config/swarm.yaml.

Output lines (tab separated):
  UAV <k> <px4_instance> <sysid> <udp_port> <home_x> <home_y> <model_name>
  PARAM <NAME> <VALUE>
  WORLD <world_name>
  MODEL <px4_sim_model>
  AUTOSTART <id>
Used by scripts/start_simulation.sh so shell scripts never duplicate config logic.
"""
import os
import sys

import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def home_positions(cfg: dict) -> list[list[float]]:
    n = int(cfg["swarm"]["number_of_uavs"])
    homes = [list(h) for h in cfg["swarm"]["home_positions"]]
    gen = cfg["swarm"].get("pad_generator", {"origin": [35.0, -40.0], "spacing": [0.0, 20.0]})
    base = len(homes)
    while len(homes) < n:
        k = len(homes) - base
        homes.append([gen["origin"][0] + k * gen["spacing"][0], gen["origin"][1] + k * gen["spacing"][1]])
    return homes[:n]


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "config", "swarm.yaml")
    cfg = yaml.safe_load(open(path))
    model = cfg["sim"]["px4_model"]
    base_name = model.split("gz_", 1)[-1]
    for k, (x, y) in enumerate(home_positions(cfg), start=1):
        inst = k - 1
        print(f"UAV\t{k}\t{inst}\t{inst + 1}\t{14540 + inst}\t{x}\t{y}\t{base_name}_{inst}")
    for name, value in (cfg["sim"].get("px4_params") or {}).items():
        print(f"PARAM\t{name}\t{value}")
    print(f"WORLD\t{cfg['sim']['world_name']}")
    print(f"MODEL\t{model}")
    print(f"AUTOSTART\t{cfg['sim']['px4_autostart']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
