#!/usr/bin/env bash
# Shared helpers for all UAV-X scripts. Source this file; do not execute it.
#
# Design rules (see docs/TROUBLESHOOTING.md):
#  * Gazebo and PX4 run in a ROS-free environment. Sourcing ROS Lyrical puts a
#    vendored `gz` CLI first on PATH and hides `gz sim`.
#  * Every background process is started as its own session leader and its
#    PGID is written to .run/pids/<name>.pid, so stop_all.sh can terminate the
#    complete process tree without pattern-matching unrelated processes.

set -o pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PX4_DIR="${PX4_DIR:-$PROJECT_ROOT/external/PX4-Autopilot}"
PX4_BUILD="$PX4_DIR/build/px4_sitl_default"
PX4_TAG="v1.18.0-rc1"                                    # validated PX4 release candidate
PX4_COMMIT="fca3df865af36124a28c9d607e850f111dbaaea9"    # exact commit of that tag (verified by install.sh)
RUN_DIR="$PROJECT_ROOT/.run"
PID_DIR="$RUN_DIR/pids"
LOG_DIR="$PROJECT_ROOT/logs"
CONFIG_FILE="${UAVX_CONFIG:-$PROJECT_ROOT/config/swarm.yaml}"

export GZ_IP="${GZ_IP:-127.0.0.1}"
export GZ_PARTITION="${GZ_PARTITION:-uavx}"
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-42}"
export ROS_AUTOMATIC_DISCOVERY_RANGE="${ROS_AUTOMATIC_DISCOVERY_RANGE:-LOCALHOST}"

mkdir -p "$PID_DIR" "$LOG_DIR"

c_info()  { printf '\033[1;36m[%s]\033[0m %s\n' "${LOG_TAG:-uavx}" "$*"; }
c_ok()    { printf '\033[1;32m[%s]\033[0m %s\n' "${LOG_TAG:-uavx}" "$*"; }
c_warn()  { printf '\033[1;33m[%s]\033[0m %s\n' "${LOG_TAG:-uavx}" "$*" >&2; }
c_err()   { printf '\033[1;31m[%s]\033[0m %s\n' "${LOG_TAG:-uavx}" "$*" >&2; }

detect_ros_distro() {
  if [[ -n "${UAVX_ROS_DISTRO:-}" ]]; then echo "$UAVX_ROS_DISTRO"; return; fi
  for d in lyrical kilted jazzy; do
    [[ -f "/opt/ros/$d/setup.bash" ]] && { echo "$d"; return; }
  done
  echo ""
}

# Minimal, ROS-free environment for Gazebo + PX4.
sim_env_args() {
  local args=(
    "HOME=$HOME" "USER=${USER:-$(id -un)}" "LANG=C.UTF-8"
    "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    "GZ_IP=$GZ_IP" "GZ_PARTITION=$GZ_PARTITION"
    "GZ_SIM_RESOURCE_PATH=$PROJECT_ROOT/models:$PROJECT_ROOT/worlds:$PX4_DIR/Tools/simulation/gz/models:$PX4_DIR/Tools/simulation/gz/worlds"
    "GZ_SIM_SYSTEM_PLUGIN_PATH=$PX4_BUILD/src/modules/simulation/gz_plugins"
    "GZ_SIM_SERVER_CONFIG_PATH=$PX4_DIR/src/modules/simulation/gz_bridge/server.config"
    "PX4_GZ_MODELS=$PX4_DIR/Tools/simulation/gz/models"
    "PX4_GZ_WORLDS=$PROJECT_ROOT/worlds"
  )
  # Display variables are needed only by the optional GUI.
  [[ -n "${DISPLAY:-}" ]] && args+=("DISPLAY=$DISPLAY")
  [[ -n "${WAYLAND_DISPLAY:-}" ]] && args+=("WAYLAND_DISPLAY=$WAYLAND_DISPLAY")
  [[ -n "${XDG_RUNTIME_DIR:-}" ]] && args+=("XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR")
  printf '%s\n' "${args[@]}"
}

# Run a command in the clean simulator environment (foreground).
sim_exec() {
  local -a envargs; mapfile -t envargs < <(sim_env_args)
  env -i "${envargs[@]}" "$@"
}

# Source ROS + the project workspace into the *current* shell, after removing
# any unrelated overlays (e.g. another colcon workspace sourced by ~/.bashrc).
ros_env() {
  local distro; distro="$(detect_ros_distro)"
  if [[ -z "$distro" ]]; then c_err "No ROS 2 installation found in /opt/ros"; return 1; fi
  unset AMENT_PREFIX_PATH CMAKE_PREFIX_PATH COLCON_PREFIX_PATH PYTHONPATH LD_LIBRARY_PATH
  # shellcheck disable=SC1090
  set +u; source "/opt/ros/$distro/setup.bash"
  if [[ -f "$PROJECT_ROOT/install/setup.bash" ]]; then
    # shellcheck disable=SC1091
    source "$PROJECT_ROOT/install/setup.bash"
  fi
  export ROS_DOMAIN_ID ROS_AUTOMATIC_DISCOVERY_RANGE GZ_IP GZ_PARTITION
  export UAVX_ROOT="$PROJECT_ROOT"
  export PYTHONUNBUFFERED=1
}

# start_bg <name> <logfile> <cmd...>
# Starts <cmd> as a new session leader; the leader writes its own PID (== PGID)
# into .run/pids/<name>.pid before exec'ing the command.
start_bg() {
  local name="$1" log="$2"; shift 2
  local pidfile="$PID_DIR/$name.pid"
  if [[ -f "$pidfile" ]] && kill -0 -- "-$(cat "$pidfile")" 2>/dev/null; then
    c_warn "$name already running (pgid $(cat "$pidfile"))"; return 0
  fi
  mkdir -p "$(dirname "$log")"
  setsid bash -c 'echo $$ > "$0"; exec "$@"' "$pidfile" "$@" > "$log" 2>&1 < /dev/null &
  local i
  for i in $(seq 1 50); do [[ -s "$pidfile" ]] && break; sleep 0.1; done
  if [[ ! -s "$pidfile" ]]; then c_err "failed to start $name"; return 1; fi
}

# start_bg_sim <name> <logfile> <cmd...>  -- same, inside the clean sim env
start_bg_sim() {
  local name="$1" log="$2"; shift 2
  local -a envargs; mapfile -t envargs < <(sim_env_args)
  start_bg "$name" "$log" env -i "${envargs[@]}" "$@"
}

is_running() {
  local pidfile="$PID_DIR/$1.pid"
  [[ -f "$pidfile" ]] && kill -0 -- "-$(cat "$pidfile")" 2>/dev/null
}

# stop_group <name> [timeout_s]: SIGINT -> SIGTERM -> SIGKILL on the process group.
stop_group() {
  local name="$1" timeout="${2:-8}" pidfile="$PID_DIR/$1.pid" pgid i
  [[ -f "$pidfile" ]] || return 0
  pgid="$(cat "$pidfile")"
  if kill -0 -- "-$pgid" 2>/dev/null; then
    kill -INT -- "-$pgid" 2>/dev/null
    for i in $(seq 1 $((timeout * 5))); do kill -0 -- "-$pgid" 2>/dev/null || break; sleep 0.2; done
    if kill -0 -- "-$pgid" 2>/dev/null; then
      kill -TERM -- "-$pgid" 2>/dev/null; sleep 2
    fi
    if kill -0 -- "-$pgid" 2>/dev/null; then
      c_warn "$name did not exit, sending SIGKILL"; kill -KILL -- "-$pgid" 2>/dev/null; sleep 0.5
    fi
  fi
  rm -f "$pidfile"
}

# Read a value from config/swarm.yaml with a dotted path (python3 + PyYAML).
cfg() {
  python3 - "$CONFIG_FILE" "$1" <<'PY'
import sys, yaml
data = yaml.safe_load(open(sys.argv[1]))
node = data
for key in sys.argv[2].split('.'):
    node = node[key]
if isinstance(node, (list, dict)):
    import json; print(json.dumps(node))
else:
    print(node)
PY
}

wait_for() {  # wait_for <timeout_s> <description> <cmd...>
  local timeout="$1" desc="$2"; shift 2
  local t0=$SECONDS
  until "$@" >/dev/null 2>&1; do
    if (( SECONDS - t0 >= timeout )); then c_err "timeout waiting for $desc"; return 1; fi
    sleep 1
  done
}
