#!/usr/bin/env bash
# Start the web dashboard on its own (the swarm launch already includes it unless it
# was started with dashboard:=false / ./scripts/start_swarm.sh without --with-dashboard).
#   ./scripts/start_dashboard.sh [port]      -> http://localhost:8080
set -u
LOG_TAG=dashboard
source "$(dirname "$0")/lib/common.sh"
cd "$PROJECT_ROOT"
PORT="${1:-8080}"
if (echo > "/dev/tcp/127.0.0.1/$PORT") 2>/dev/null; then
  c_warn "port $PORT is already in use (the swarm launch may already serve the dashboard): http://localhost:$PORT"
  exit 0
fi
ros_env || exit 1
start_bg dashboard "$LOG_DIR/dashboard.log" ros2 run uav_x_swarm dashboard --ros-args \
  -p config:="$PROJECT_ROOT/config/swarm.yaml" -p port:="$PORT"
c_ok "dashboard: http://localhost:$PORT  (stop with ./scripts/stop_all.sh)"
