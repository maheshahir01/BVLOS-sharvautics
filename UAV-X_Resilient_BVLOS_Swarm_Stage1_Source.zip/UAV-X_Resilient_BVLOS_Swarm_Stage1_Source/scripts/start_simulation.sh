#!/usr/bin/env bash
# Start the Gazebo world (headless server) and N PX4 SITL instances.
#
#   ./scripts/start_simulation.sh            # headless (default)
#   ./scripts/start_simulation.sh --gui      # also open the Gazebo GUI (WSLg / X11)
#   ./scripts/start_simulation.sh --gui --fixed-camera   # GUI without the follow camera
#
# With the GUI, scripts/tools/swarm_camera.py keeps the view behind the swarm, framing all
# UAVs (visualization only). UAVX_CAMERA=fixed has the same effect as --fixed-camera.
#
# Each UAV k (1..N) gets: PX4 instance k-1, MAV_SYS_ID k, MAVLink UDP 14540+k-1,
# Gazebo model x500_<k-1>, a fresh working directory (.run/px4/uav<k>) so no
# parameters persist between runs, and PX4_PARAM_* overrides from config/swarm.yaml.
set -u
LOG_TAG=sim
source "$(dirname "$0")/lib/common.sh"

GUI=0
CAMERA="${UAVX_CAMERA:-follow}"
for arg in "$@"; do
  case "$arg" in
    --gui) GUI=1 ;;
    --headless) GUI=0 ;;
    --fixed-camera) CAMERA=fixed ;;
    *) c_err "unknown argument $arg"; exit 2 ;;
  esac
done

[[ -x "$PX4_BUILD/bin/px4" ]] || { c_err "PX4 not built ($PX4_BUILD/bin/px4). Run ./scripts/build.sh"; exit 1; }

# ---------------------------------------------------------------- plan from config
mapfile -t PLAN < <(python3 "$PROJECT_ROOT/scripts/tools/sim_plan.py" "$CONFIG_FILE")
WORLD=""; MODEL=""; AUTOSTART=""; UAVS=(); PARAM_ENV=()
for line in "${PLAN[@]}"; do
  IFS=$'\t' read -r kind a b c d e f g <<< "$line"
  case "$kind" in
    UAV) UAVS+=("$a $b $c $d $e $f $g") ;;
    PARAM) PARAM_ENV+=("PX4_PARAM_$a=$b") ;;
    WORLD) WORLD="$a" ;;
    MODEL) MODEL="$a" ;;
    AUTOSTART) AUTOSTART="$a" ;;
  esac
done
WORLD_FILE="$PROJECT_ROOT/worlds/$WORLD.sdf"
[[ -f "$WORLD_FILE" ]] || python3 "$PROJECT_ROOT/scripts/tools/generate_world.py" >/dev/null
[[ -f "$WORLD_FILE" ]] || { c_err "world file $WORLD_FILE missing"; exit 1; }
# enlarged-visual drone model (shadows PX4's x500_base via GZ_SIM_RESOURCE_PATH)
[[ -f "$PROJECT_ROOT/models/x500_base/model.sdf" ]] || python3 "$PROJECT_ROOT/scripts/tools/make_visual_model.py" >/dev/null

if is_running gz_server; then
  c_err "simulation already running. Use ./scripts/stop_all.sh first"; exit 1
fi
if pgrep -x px4 >/dev/null || pgrep -x gz-sim-main >/dev/null; then
  c_err "found PX4/Gazebo processes not started by this project:"
  ps -eo pid,comm,args | grep -E "[p]x4 |[g]z-sim-main" | cut -c1-150 >&2
  c_err "stop them first (./scripts/stop_all.sh --force)"; exit 1
fi

SIM_LOG_DIR="$LOG_DIR/sim"
mkdir -p "$SIM_LOG_DIR"
rm -f "$SIM_LOG_DIR"/*.log

# ---------------------------------------------------------------- Gazebo server
c_info "starting Gazebo server (world: $WORLD, headless)"
start_bg_sim gz_server "$SIM_LOG_DIR/gz_server.log" gz sim -s -r -v 2 "$WORLD_FILE"
world_ready() { sim_exec gz service -l 2>/dev/null | grep -q "^/world/$WORLD/scene/info$"; }
if ! wait_for 60 "Gazebo world $WORLD" world_ready; then
  tail -20 "$SIM_LOG_DIR/gz_server.log" >&2; exit 1
fi
c_ok "Gazebo world '$WORLD' is up"

if (( GUI )); then
  c_info "starting Gazebo GUI (hardware GL via d3d12 when available)"
  GUI_ENV=()
  [[ -e /dev/dxg ]] && GUI_ENV+=(GALLIUM_DRIVER=d3d12)
  start_bg_sim gz_gui "$SIM_LOG_DIR/gz_gui.log" env "${GUI_ENV[@]}" gz sim -g -v 1
fi

# ---------------------------------------------------------------- PX4 instances
for u in "${UAVS[@]}"; do
  read -r k inst sysid port hx hy mname <<< "$u"
  work="$RUN_DIR/px4/uav$k"
  rm -rf "$work"; mkdir -p "$work"
  c_info "starting PX4 uav$k: instance $inst, sysid $sysid, udp $port, model $mname at ($hx, $hy)"
  start_bg_sim "px4_uav$k" "$SIM_LOG_DIR/px4_uav$k.log" env \
    PX4_SYS_AUTOSTART="$AUTOSTART" PX4_SIM_MODEL="$MODEL" PX4_GZ_STANDALONE=1 \
    PX4_GZ_WORLD="$WORLD" PX4_GZ_MODEL_POSE="$hx,$hy,0.25,0,0,0" PX4_GZ_NO_FOLLOW=1 \
    "${PARAM_ENV[@]}" \
    "$PX4_BUILD/bin/px4" -d -i "$inst" -w "$work" "$PX4_BUILD/etc"
  # wait until this instance has spawned its model before starting the next one
  if ! wait_for 60 "PX4 uav$k startup" grep -q "Startup script returned successfully" "$SIM_LOG_DIR/px4_uav$k.log"; then
    tail -30 "$SIM_LOG_DIR/px4_uav$k.log" >&2; exit 1
  fi
  if grep -qE "ERROR \[init\]|gz_bridge failed" "$SIM_LOG_DIR/px4_uav$k.log"; then
    c_err "PX4 uav$k reported an init error:"; grep -E "ERROR" "$SIM_LOG_DIR/px4_uav$k.log" >&2; exit 1
  fi
done

if (( GUI )) && [[ "$CAMERA" == follow ]]; then
  MODELS=(); for u in "${UAVS[@]}"; do read -r _ _ _ _ _ _ mname <<< "$u"; MODELS+=("$mname"); done
  c_info "starting follow camera (behind the swarm, framing ${MODELS[*]})"
  start_bg_sim gz_camera "$SIM_LOG_DIR/swarm_camera.log" python3 -u "$PROJECT_ROOT/scripts/tools/swarm_camera.py" \
    --world "$WORLD" --models "${MODELS[@]}"
fi

printf '%s\n' "${UAVS[@]}" > "$RUN_DIR/uavs.txt"
c_ok "simulation running: ${#UAVS[@]} PX4 vehicles in world '$WORLD' (logs: logs/sim/)"
