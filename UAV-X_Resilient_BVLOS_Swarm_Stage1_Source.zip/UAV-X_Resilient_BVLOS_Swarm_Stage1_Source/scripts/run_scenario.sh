#!/usr/bin/env bash
# Run one complete scenario from a clean state and collect its results.
#
#   ./scripts/run_scenario.sh scenarios/stage1_demo.yaml [--gui] [--keep] [--timeout S] [--no-dashboard] [--quiet]
#
# Steps: stop leftovers -> start Gazebo + N PX4 -> launch the swarm stack ->
# stream the event console -> wait for MISSION_COMPLETE / MISSION_FAILED ->
# stop everything (unless --keep) -> print the report location.
# Exit code 0 only if the mission result is MISSION_COMPLETE.
set -u
LOG_TAG=run
source "$(dirname "$0")/lib/common.sh"
cd "$PROJECT_ROOT"

SCEN="${1:-}"
[[ -n "$SCEN" && -f "$SCEN" ]] || { c_err "usage: $0 <scenario.yaml> [--gui] [--keep] [--timeout S] [--no-dashboard]"; exit 2; }
shift
GUI=0; KEEP=0; DASH=true; QUIET=0
TIMEOUT="$(python3 -c "import yaml;c=yaml.safe_load(open('$CONFIG_FILE'));s=yaml.safe_load(open('$SCEN')) or {};o=(s.get('overrides') or {}).get('mission',{});print(int(float(o.get('timeout_s',c['mission']['timeout_s']))+240))")"
while (( $# )); do
  case "$1" in
    --gui) GUI=1 ;;
    --keep) KEEP=1 ;;
    --no-dashboard) DASH=false ;;
    --quiet) QUIET=1 ;;
    --timeout) TIMEOUT="$2"; shift ;;
    *) c_err "unknown option $1"; exit 2 ;;
  esac
  shift
done

[[ -f "$PROJECT_ROOT/install/setup.bash" ]] || { c_info "workspace not built yet"; ./scripts/build.sh || exit 1; }

./scripts/stop_all.sh --force >/dev/null 2>&1

RUN_ID="$(date +%Y%m%d_%H%M%S)_$(basename "$SCEN" .yaml)"
RUN_DIR="$PROJECT_ROOT/results/runs/$RUN_ID"
mkdir -p "$RUN_DIR"
ln -sfn "runs/$RUN_ID" "$PROJECT_ROOT/results/latest"
c_info "run $RUN_ID  (scenario $SCEN, timeout ${TIMEOUT}s)"

SIM_ARGS=(); (( GUI )) && SIM_ARGS+=(--gui)
if ! ./scripts/start_simulation.sh "${SIM_ARGS[@]}"; then
  c_err "simulation failed to start"; ./scripts/stop_all.sh --force >/dev/null 2>&1; exit 1
fi
cp -r "$LOG_DIR/sim" "$RUN_DIR/sim_logs" 2>/dev/null

ros_env || exit 1
export ROS_LOG_DIR="$LOG_DIR/ros/$RUN_ID"
start_bg swarm "$RUN_DIR/launch.log" ros2 launch "$PROJECT_ROOT/launch/swarm.launch.py" \
  scenario:="$PROJECT_ROOT/$SCEN" run_dir:="$RUN_DIR" dashboard:="$DASH"
[[ "$DASH" == true ]] && c_info "dashboard: http://localhost:8080"

for i in $(seq 1 30); do [[ -f "$RUN_DIR/console.txt" ]] && break; sleep 1; done
TAIL_PID=""
if (( ! QUIET )); then
  tail -n +1 -f "$RUN_DIR/console.txt" &
  TAIL_PID=$!
fi

cleanup() {
  [[ -n "$TAIL_PID" ]] && kill "$TAIL_PID" 2>/dev/null
  if (( ! KEEP )); then "$PROJECT_ROOT/scripts/stop_all.sh" >/dev/null 2>&1 || "$PROJECT_ROOT/scripts/stop_all.sh" --force >/dev/null 2>&1; fi
}
trap 'c_warn "interrupted"; cleanup; exit 130' INT TERM

t0=$SECONDS
result="TIMEOUT"
while (( SECONDS - t0 < TIMEOUT )); do
  if [[ -f "$RUN_DIR/DONE" ]]; then result="$(cat "$RUN_DIR/DONE")"; break; fi
  if ! is_running swarm; then result="STACK_EXITED"; break; fi
  if ! is_running gz_server; then result="SIMULATOR_EXITED"; break; fi
  sleep 1
done
sleep 1
if [[ "$result" == "TIMEOUT" || "$result" == "STACK_EXITED" || "$result" == "SIMULATOR_EXITED" ]]; then
  c_err "run ended without a mission result: $result"
fi
# keep the process logs of this run next to its results
cp -r "$LOG_DIR/sim" "$RUN_DIR/sim_logs" 2>/dev/null
cleanup
cp -r "$ROS_LOG_DIR" "$RUN_DIR/ros_logs" 2>/dev/null
echo
c_info "results: $RUN_DIR"
[[ -f "$RUN_DIR/report.md" ]] && c_info "report:  $RUN_DIR/report.md"
if [[ "$result" == "MISSION_COMPLETE" ]]; then c_ok "RESULT: $result"; exit 0; fi
c_err "RESULT: $result"; exit 1
