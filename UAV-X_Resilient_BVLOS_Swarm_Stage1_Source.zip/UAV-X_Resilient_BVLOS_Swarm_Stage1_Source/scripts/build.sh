#!/usr/bin/env bash
# Build everything: Gazebo world (generated from config), PX4 SITL (if needed),
# and the ROS 2 workspace (colcon).
#
#   ./scripts/build.sh            # incremental
#   ./scripts/build.sh --clean    # wipe colcon build/install/log first
set -u
LOG_TAG=build
source "$(dirname "$0")/lib/common.sh"
cd "$PROJECT_ROOT"

if [[ "${1:-}" == "--clean" ]]; then
  c_info "removing colcon build/ install/ log/"
  rm -rf build install log
fi

c_info "generating Gazebo world from config"
python3 scripts/tools/generate_world.py || exit 1

if [[ ! -x "$PX4_BUILD/bin/px4" ]]; then
  [[ -d "$PX4_DIR" ]] || { c_err "PX4 source missing at $PX4_DIR. Run ./install.sh"; exit 1; }
  c_info "building PX4 SITL ($PX4_TAG) in a ROS-free environment (takes ~10 min the first time)"
  ( cd "$PX4_DIR" && sim_exec make px4_sitl ) > "$LOG_DIR/px4_build.log" 2>&1 \
    || { c_err "PX4 build failed, see logs/px4_build.log"; tail -20 "$LOG_DIR/px4_build.log" >&2; exit 1; }
fi
c_ok "PX4 SITL binary: $PX4_BUILD/bin/px4"
c_info "generating enlarged-visual x500 model (visual scale from config; physics verified identical)"
python3 scripts/tools/make_visual_model.py || exit 1

c_info "building ROS 2 workspace (colcon)"
ros_env || exit 1
colcon build --symlink-install --base-paths src 2>&1 | tee "$LOG_DIR/colcon_build.log" | grep -vE "^\s*$" | tail -5
rc=${PIPESTATUS[0]}
if (( rc != 0 )); then c_err "colcon build failed (logs/colcon_build.log)"; exit "$rc"; fi
c_ok "build complete. Source the environment with: source scripts/environment_setup.sh"
