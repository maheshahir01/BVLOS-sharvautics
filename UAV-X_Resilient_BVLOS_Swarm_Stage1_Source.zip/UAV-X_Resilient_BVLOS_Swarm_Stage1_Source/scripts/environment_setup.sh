#!/usr/bin/env bash
# Source this file in an interactive shell to use ros2 CLI tools with this project:
#
#   source scripts/environment_setup.sh     (run from the project directory)
#   ros2 topic list
#
# It removes unrelated ROS overlays, sources /opt/ros/<distro> and install/setup.bash,
# and sets the isolated DDS domain (ROS_DOMAIN_ID=42, localhost-only discovery).
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  echo "This file must be sourced:  source ${BASH_SOURCE[0]}" >&2
  exit 1
fi
source "$(dirname "${BASH_SOURCE[0]}")/lib/common.sh"
ros_env && echo "[uavx] ROS_DISTRO=$ROS_DISTRO ROS_DOMAIN_ID=$ROS_DOMAIN_ID workspace=$PROJECT_ROOT/install"
set +o pipefail
