#!/usr/bin/env bash
# Stop everything this project started: ROS nodes, dashboard, PX4 instances,
# Gazebo (server + GUI) and the ROS-Gazebo bridge.
#
#   ./scripts/stop_all.sh           # stop process groups recorded in .run/pids
#   ./scripts/stop_all.sh --force   # also kill stray project processes (e.g. after a crash)
#
# Safety: only process groups recorded by our launchers are signalled. With
# --force, a stray process is killed only if its command line references this
# project directory.
set -u
LOG_TAG=stop
source "$(dirname "$0")/lib/common.sh"

FORCE=0
[[ "${1:-}" == "--force" ]] && FORCE=1

# Stop order: consumers first, simulator last.
ORDER=(demo_runner swarm dashboard ros_gz_bridge gz_gui)
for f in "$PID_DIR"/px4_uav*.pid; do [[ -e "$f" ]] && ORDER+=("$(basename "$f" .pid)"); done
ORDER+=(gz_server)
for f in "$PID_DIR"/*.pid; do
  [[ -e "$f" ]] || continue
  n="$(basename "$f" .pid)"
  [[ " ${ORDER[*]} " == *" $n "* ]] || ORDER=("$n" "${ORDER[@]}")
done

stopped=0
for name in "${ORDER[@]}"; do
  if [[ -f "$PID_DIR/$name.pid" ]]; then
    if is_running "$name"; then c_info "stopping $name"; stopped=$((stopped + 1)); fi
    stop_group "$name" 10
  fi
done

# Our own ancestor chain (shells that invoked this script) is never a target.
ANCESTORS=" "
_p=$$
while [[ -n "$_p" && "$_p" != "0" ]]; do
  ANCESTORS+="$_p "
  _p="$(awk '{print $4}' "/proc/$_p/stat" 2>/dev/null)"
done

filter_ancestors() { local pid; while read -r pid _; do [[ -n "$pid" && "$ANCESTORS" != *" $pid "* ]] && echo "$pid"; done; }

project_procs() {
  # PIDs of processes whose command line references this project (never ourselves).
  local pid cmd
  for pid in $(pgrep -f "$PROJECT_ROOT" 2>/dev/null | filter_ancestors); do
    cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)" || continue
    [[ "$cmd" == *stop_all.sh* ]] && continue
    echo "$pid"
  done
}

if (( FORCE )); then
  mapfile -t stray < <(project_procs)
  if (( ${#stray[@]} )); then
    c_warn "killing ${#stray[@]} stray project process(es): ${stray[*]}"
    kill -TERM "${stray[@]}" 2>/dev/null; sleep 2
    mapfile -t stray < <(project_procs)
    (( ${#stray[@]} )) && kill -KILL "${stray[@]}" 2>/dev/null
  fi
fi

# PX4 leaves lock/socket files in /tmp; remove them only when no PX4 is running.
if ! pgrep -x px4 >/dev/null; then
  rm -f /tmp/px4_lock-* /tmp/px4-sock-* 2>/dev/null
fi

sleep 0.5
# pgrep never matches itself; the patterns do not occur in this script's own argv.
left_pids="$(pgrep -f "px4 -d -i|gz-sim-main|parameter_bridge|uav_x_swarm/lib/|uav_x_swarm/launch/" | filter_ancestors)"
left=""
for pid in $left_pids; do left+="$pid $(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)"$'\n'; done
left="${left%$'\n'}"
if [[ -n "$left" ]]; then
  c_warn "processes still running:"; echo "$left" | cut -c1-160 >&2
  c_warn "run ./scripts/stop_all.sh --force"
  exit 1
fi
c_ok "all project processes stopped ($stopped group(s) signalled)"
