#!/usr/bin/env bash
# Start the ROS 2 swarm stack against an already running simulation
# (./scripts/start_simulation.sh). Use this when you want to drive the pieces by hand;
# ./scripts/run_scenario.sh does start_simulation + start_swarm + wait + stop for you.
#
#   ./scripts/start_swarm.sh [scenarios/<name>.yaml] [--with-dashboard] [--follow]
set -u
LOG_TAG=swarm
source "$(dirname "$0")/lib/common.sh"
cd "$PROJECT_ROOT"
SCEN="scenarios/nominal.yaml"; DASH=false; FOLLOW=0
for a in "$@"; do
  case "$a" in
    --with-dashboard) DASH=true ;;
    --follow) FOLLOW=1 ;;
    *.yaml) SCEN="$a" ;;
    *) c_err "unknown argument $a"; exit 2 ;;
  esac
done
is_running gz_server || { c_err "simulation is not running: ./scripts/start_simulation.sh first"; exit 1; }
is_running swarm && { c_err "swarm stack already running (./scripts/stop_all.sh)"; exit 1; }
[[ -f install/setup.bash ]] || ./scripts/build.sh || exit 1
RUN_ID="$(date +%Y%m%d_%H%M%S)_$(basename "$SCEN" .yaml)"
RUN_DIR="$PROJECT_ROOT/results/runs/$RUN_ID"
mkdir -p "$RUN_DIR"; ln -sfn "runs/$RUN_ID" "$PROJECT_ROOT/results/latest"
ros_env || exit 1
export ROS_LOG_DIR="$LOG_DIR/ros/$RUN_ID"
start_bg swarm "$RUN_DIR/launch.log" ros2 launch "$PROJECT_ROOT/launch/swarm.launch.py" \
  scenario:="$PROJECT_ROOT/$SCEN" run_dir:="$RUN_DIR" dashboard:="$DASH"
c_ok "swarm stack started (scenario $SCEN) -> $RUN_DIR"
c_info "event console: tail -f $RUN_DIR/console.txt"
if (( FOLLOW )); then
  for i in $(seq 1 30); do [[ -f "$RUN_DIR/console.txt" ]] && break; sleep 1; done
  exec tail -n +1 -f "$RUN_DIR/console.txt"
fi
