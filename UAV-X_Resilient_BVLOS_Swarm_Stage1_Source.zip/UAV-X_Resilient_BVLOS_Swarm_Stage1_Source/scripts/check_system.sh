#!/usr/bin/env bash
# Inspect the machine and verify every dependency of this project (read-only).
#   ./scripts/check_system.sh
# Exit code 0 if nothing FAILs (WARN is informational).
set -u
LOG_TAG=check
source "$(dirname "$0")/lib/common.sh"
cd "$PROJECT_ROOT"
FAILS=0
pass() { printf '  \033[32mPASS\033[0m %-28s %s\n' "$1" "$2"; }
warn() { printf '  \033[33mWARN\033[0m %-28s %s\n' "$1" "$2"; }
fail() { printf '  \033[31mFAIL\033[0m %-28s %s\n' "$1" "$2"; FAILS=$((FAILS + 1)); }

echo "== Host"
os="$(lsb_release -ds 2>/dev/null)"; rel="$(lsb_release -rs 2>/dev/null)"
case "$rel" in 26.04|24.04) pass "Ubuntu" "$os" ;; *) warn "Ubuntu" "$os (tested on 26.04; 24.04 supported by the same code)" ;; esac
grep -qi microsoft /proc/version && warn "Platform" "WSL2 ($(uname -r)); Gazebo GUI via WSLg" || pass "Platform" "native Linux $(uname -r)"
pass "CPU" "$(lscpu | awk -F: '/Model name/{gsub(/^ +/,"",$2);print $2; exit}') ($(nproc) threads)"
mem_gb=$(awk '/MemTotal/{printf "%.1f", $2/1048576}' /proc/meminfo)
awk "BEGIN{exit !($mem_gb >= 7)}" && pass "RAM" "${mem_gb} GiB" || warn "RAM" "${mem_gb} GiB (>= 8 GiB recommended)"
free_gb=$(df -BG --output=avail "$PROJECT_ROOT" | tail -1 | tr -dc 0-9)
(( free_gb >= 10 )) && pass "Disk" "${free_gb} GiB free" || warn "Disk" "${free_gb} GiB free (PX4 build needs ~3 GiB)"
if [[ -e /dev/dxg ]] && GALLIUM_DRIVER=d3d12 glxinfo -B 2>/dev/null | grep -q "Accelerated: yes"; then
  pass "GPU (GUI rendering)" "$(GALLIUM_DRIVER=d3d12 glxinfo -B 2>/dev/null | awk -F: '/Device/{print $2; exit}' | xargs)"
elif glxinfo -B 2>/dev/null | grep -q "Accelerated: yes"; then
  pass "GPU (GUI rendering)" "$(glxinfo -B | awk -F: '/Device/{print $2; exit}' | xargs)"
else
  warn "GPU (GUI rendering)" "software rendering only (GUI optional; the simulation runs headless)"
fi

echo "== Toolchain"
for t in git cmake gcc g++ python3 colcon; do
  if ! command -v "$t" >/dev/null; then fail "$t" "not found"; continue; fi
  case "$t" in
    colcon) pass "$t" "$(dpkg-query -W -f='${Version}' python3-colcon-common-extensions 2>/dev/null || echo installed) ($(command -v colcon))" ;;
    *) pass "$t" "$("$t" --version 2>&1 | head -1)" ;;
  esac
done

echo "== ROS 2"
distro="$(detect_ros_distro)"
if [[ -n "$distro" ]]; then
  pass "ROS 2 distro" "$distro (/opt/ros/$distro)"
  ( ros_env >/dev/null 2>&1
    ros2 pkg prefix ros_gz_bridge >/dev/null 2>&1 && echo "OK_BRIDGE"
    python3 -c "import rclpy" 2>/dev/null && echo "OK_RCLPY"
    ros2 pkg prefix uav_x_swarm >/dev/null 2>&1 && echo "OK_PKG" ) > "$RUN_DIR/check_ros.txt" 2>/dev/null
  grep -q OK_RCLPY "$RUN_DIR/check_ros.txt" && pass "rclpy" "importable" || fail "rclpy" "not importable"
  grep -q OK_BRIDGE "$RUN_DIR/check_ros.txt" && pass "ros_gz_bridge" "installed" || fail "ros_gz_bridge" "sudo apt install ros-$distro-ros-gz-bridge"
  grep -q OK_PKG "$RUN_DIR/check_ros.txt" && pass "uav_x_swarm package" "built (install/)" || warn "uav_x_swarm package" "not built yet: ./scripts/build.sh"
else
  fail "ROS 2 distro" "no /opt/ros/<distro>; see docs/INSTALLATION.md"
fi

echo "== Gazebo (clean, ROS-free environment)"
gzv="$(sim_exec gz sim --versions 2>/dev/null | head -1)"
[[ -n "$gzv" ]] && pass "gz sim" "$gzv" || fail "gz sim" "not found (install gz-jetty on 26.04 / gz-harmonic on 24.04)"

echo "== PX4"
if [[ -x "$PX4_BUILD/bin/px4" ]]; then
  pass "PX4 SITL build" "$(git -C "$PX4_DIR" describe --tags 2>/dev/null) ($PX4_BUILD/bin/px4)"
elif [[ -d "$PX4_DIR" ]]; then
  warn "PX4 SITL build" "source present, not built: ./scripts/build.sh"
else
  fail "PX4 source" "missing: ./install.sh clones $PX4_TAG into external/"
fi

echo "== Python packages"
for m in yaml pymavlink pytest; do
  v="$(python3 -c "import $m; print(getattr($m, '__version__', 'ok'))" 2>/dev/null)"
  [[ -n "$v" ]] && pass "python3-$m" "$v" || fail "python3-$m" "missing (pip install -r requirements.txt)"
done

echo "== Ports / processes"
busy=""
for p in 14540 14541 14542 14543; do ss -uln 2>/dev/null | grep -q ":$p " && busy+=" udp/$p"; done
ss -tln 2>/dev/null | grep -q ":8080 " && busy+=" tcp/8080"
if [[ -z "$busy" ]]; then pass "ports" "MAVLink 14540-14543/udp and dashboard 8080/tcp free"
elif is_running gz_server; then warn "ports" "in use by the running simulation:$busy"
else warn "ports" "in use:$busy"; fi
if pgrep -x px4 >/dev/null || pgrep -x gz-sim-main >/dev/null; then warn "running sim" "PX4/Gazebo already running (./scripts/stop_all.sh)"
else pass "running sim" "none"; fi

echo
if (( FAILS )); then c_err "$FAILS check(s) FAILED"; exit 1; fi
c_ok "system check passed"
