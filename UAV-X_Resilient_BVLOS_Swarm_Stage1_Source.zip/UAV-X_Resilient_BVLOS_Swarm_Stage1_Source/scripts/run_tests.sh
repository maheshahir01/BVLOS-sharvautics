#!/usr/bin/env bash
# Automated test suite (spec TEST 1-21). Every PASS is derived from executed tests.
#
#   ./scripts/run_tests.sh            # everything (~60 min: unit + simulator + 9 scenario runs)
#   ./scripts/run_tests.sh --unit     # unit tests only (seconds)
#   ./scripts/run_tests.sh --sim      # TEST 1-6 (single UAV + four UAVs)
#   ./scripts/run_tests.sh --scenarios [name ...]   # scenario tests (TEST 7-21)
#
# Results: results/tests/<suite_id>/ (per-test JSON + logs) and TEST_RESULTS.md.
set -u
LOG_TAG=tests
source "$(dirname "$0")/lib/common.sh"
cd "$PROJECT_ROOT"

MODE="all"; ONLY=()
case "${1:-}" in
  --unit) MODE=unit ;;
  --sim) MODE=sim ;;
  --scenarios) MODE=scenarios; shift; ONLY=("$@") ;;
  ""|--all) MODE=all ;;
  *) c_err "unknown option $1"; exit 2 ;;
esac

SUITE="$(date +%Y%m%d_%H%M%S)"
OUT="$PROJECT_ROOT/results/tests/$SUITE"
mkdir -p "$OUT"
c_info "test suite $SUITE ($MODE) -> $OUT"
[[ -f install/setup.bash ]] || ./scripts/build.sh >/dev/null || { c_err "build failed"; exit 1; }

# ------------------------------------------------------------------ unit tests
run_unit() {
  c_info "unit tests (core algorithms)"
  python3 -m pytest tests/unit -q --junitxml="$OUT/unit_junit.xml" 2>&1 | tee "$OUT/unit.log" | tail -3
  python3 - "$OUT" <<'PY'
import sys, json, xml.etree.ElementTree as ET
out = sys.argv[1]
r = ET.parse(f"{out}/unit_junit.xml").getroot()
suite = r if r.tag == "testsuite" else r.find("testsuite")
tests, fails, errs = int(suite.get("tests")), int(suite.get("failures")), int(suite.get("errors"))
json.dump({"unit_tests": {"pass": fails == 0 and errs == 0 and tests > 0,
                          "detail": f"{tests - fails - errs}/{tests} unit tests passed"}},
          open(f"{out}/unit.json", "w"), indent=2)
PY
}

# ------------------------------------------------------------------ simulator tests
run_sim() {
  c_info "TEST 1-4: single UAV (PX4 SITL + Gazebo)"
  ./scripts/stop_all.sh --force >/dev/null 2>&1
  python3 - "$CONFIG_FILE" "$RUN_DIR/test_single_uav.yaml" <<'PY'
import sys, yaml
c = yaml.safe_load(open(sys.argv[1])); c["swarm"]["number_of_uavs"] = 1
yaml.safe_dump(c, open(sys.argv[2], "w"))
PY
  if UAVX_CONFIG="$RUN_DIR/test_single_uav.yaml" ./scripts/start_simulation.sh > "$OUT/single_sim.log" 2>&1; then
    timeout 400 python3 tests/sim/single_uav_flight.py --instance 0 --out "$OUT/single_uav" 2>&1 | tee "$OUT/single_uav.log"
  else
    c_err "simulation start failed (see $OUT/single_sim.log)"
    mkdir -p "$OUT/single_uav"
    echo '{"test_01_px4_startup": {"pass": false, "detail": "simulation did not start"}}' > "$OUT/single_uav/results.json"
  fi
  cp -r logs/sim "$OUT/single_uav_sim_logs" 2>/dev/null
  ./scripts/stop_all.sh >/dev/null 2>&1 || ./scripts/stop_all.sh --force >/dev/null 2>&1

  c_info "TEST 5-6: four UAVs (startup, unique addressing, independent control)"
  if ./scripts/start_simulation.sh > "$OUT/four_sim.log" 2>&1; then
    timeout 500 python3 tests/sim/four_uav_check.py --out "$OUT/four_uav" 2>&1 | tee "$OUT/four_uav.log"
  else
    mkdir -p "$OUT/four_uav"
    echo '{"test_05_four_uav_startup": {"pass": false, "detail": "simulation did not start"}}' > "$OUT/four_uav/results.json"
  fi
  cp -r logs/sim "$OUT/four_uav_sim_logs" 2>/dev/null
  ./scripts/stop_all.sh >/dev/null 2>&1 || ./scripts/stop_all.sh --force >/dev/null 2>&1
}

# ------------------------------------------------------------------ scenario tests
declare -A SCEN_TESTS=(
  [nominal]="test_07_ros_communication test_08_gcs_communication test_09_uav_to_uav_communication test_10_multi_hop_routing test_11_relay_selection test_17_return_to_home test_20_complete_mission"
  [scenario_failure]="test_12_relay_failure test_17_return_to_home"
  [scenario_comm_outage]="test_13_communication_outage"
  [scenario_packet_loss]="test_14_packet_loss"
  [scenario_priority]="test_15_new_priority_poi"
  [scenario_battery]="test_16_low_battery test_17_return_to_home"
  [scenario_collision]="test_18_collision_avoidance"
  [scenario_geofence]="test_19_geofence"
  [stage1_demo]="test_21_failure_recovery_mission_completion"
)
SCEN_ORDER=(nominal scenario_failure scenario_comm_outage scenario_packet_loss scenario_priority scenario_battery scenario_collision scenario_geofence stage1_demo)

run_scenarios() {
  local list=("${SCEN_ORDER[@]}")
  (( ${#ONLY[@]} )) && list=("${ONLY[@]}")
  for s in "${list[@]}"; do
    [[ -n "${SCEN_TESTS[$s]:-}" ]] || { c_err "unknown scenario $s"; continue; }
    c_info "scenario $s -> ${SCEN_TESTS[$s]}"
    ./scripts/run_scenario.sh "scenarios/$s.yaml" --quiet --no-dashboard > "$OUT/$s.log" 2>&1 &
    local rpid=$!
    if [[ "$s" == nominal ]]; then
      # live ROS graph check while the mission is running
      local t0=$SECONDS
      until grep -qs "Mission started" "$PROJECT_ROOT/results/latest/console.txt" || (( SECONDS - t0 > 300 )); do sleep 2; done
      sleep 25
      ( ros_env && timeout 120 python3 tests/sim/ros_live_check.py --uavs "$(cfg swarm.number_of_uavs)" \
          --out "$OUT/ros_live.json" ) 2>&1 | grep -E "PASS|FAIL" | tee "$OUT/ros_live.log"
    fi
    wait "$rpid"
    local run_dir; run_dir="$(readlink -f "$PROJECT_ROOT/results/latest")"
    echo "$run_dir" > "$OUT/$s.run_dir"
    python3 tests/sim/check_run.py "$run_dir" ${SCEN_TESTS[$s]} 2>&1 | tee "$OUT/$s.checks.log"
    cp "$run_dir/checks.json" "$OUT/$s.checks.json" 2>/dev/null
  done
}

case "$MODE" in
  unit) run_unit ;;
  sim) run_sim ;;
  scenarios) run_scenarios ;;
  all) run_unit; run_sim; run_scenarios ;;
esac

PARTIAL=(); [[ "$MODE" != all ]] && PARTIAL=(--partial)
python3 tests/sim/aggregate.py "$OUT" "${PARTIAL[@]}"
