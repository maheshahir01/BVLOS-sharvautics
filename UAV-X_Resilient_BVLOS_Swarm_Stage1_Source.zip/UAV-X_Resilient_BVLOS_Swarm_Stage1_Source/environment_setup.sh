#!/usr/bin/env bash
# Source this to use the ros2 CLI with this project in the current shell:
#   source environment_setup.sh        (run from the project directory)
source "$(dirname "${BASH_SOURCE[0]}")/scripts/environment_setup.sh"
