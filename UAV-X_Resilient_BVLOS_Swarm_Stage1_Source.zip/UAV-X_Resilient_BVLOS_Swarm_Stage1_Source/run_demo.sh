#!/usr/bin/env bash
# Evaluator entry point: run the validated Stage-1 demonstration.
# Thin wrapper around scripts/run_stage1_demo.sh (same behaviour, same options):
#   ./run_demo.sh               # Gazebo GUI (if a display is available) + dashboard + event console
#   ./run_demo.sh --headless    # without the Gazebo GUI
#   ./run_demo.sh --keep        # leave everything running after MISSION_COMPLETE
# Dashboard: http://localhost:8080     Report: results/latest/report.md
exec "$(cd "$(dirname "$0")" && pwd)/scripts/run_stage1_demo.sh" "$@"
