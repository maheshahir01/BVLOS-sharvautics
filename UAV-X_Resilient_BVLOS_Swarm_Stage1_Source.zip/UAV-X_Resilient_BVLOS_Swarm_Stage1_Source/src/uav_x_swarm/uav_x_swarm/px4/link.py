"""MAVLink interface to one PX4 SITL instance (pymavlink, no ROS dependency).

Each PX4 SITL instance ``i`` opens an *onboard* MAVLink link that sends to
UDP port ``14540 + i`` on localhost. One :class:`PX4Link` binds exactly that
port and only accepts messages from ``MAV_SYS_ID = i + 1``, so two controllers can
never talk to the same vehicle by accident.

Frames: PX4 local NED (x north, y east, z down), with the origin at the vehicle's
EKF origin (its spawn point). The swarm layer uses world ENU. Use
:func:`ned_to_enu` / :func:`enu_to_ned` together with the home offset.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field

from pymavlink import mavutil

mavlink = mavutil.mavlink

# PX4 custom main modes (px4_custom_mode.h)
PX4_MAIN_MANUAL = 1
PX4_MAIN_ALTCTL = 2
PX4_MAIN_POSCTL = 3
PX4_MAIN_AUTO = 4
PX4_MAIN_OFFBOARD = 6
# PX4 AUTO sub modes
PX4_AUTO_TAKEOFF = 2
PX4_AUTO_LOITER = 3
PX4_AUTO_MISSION = 4
PX4_AUTO_RTL = 5
PX4_AUTO_LAND = 6

# SET_POSITION_TARGET_LOCAL_NED type masks
_IGN_ACC = 64 | 128 | 256
_IGN_YAW_RATE = 2048
MASK_POS_VEL_YAW = _IGN_ACC | _IGN_YAW_RATE
MASK_POS_YAW = 8 | 16 | 32 | _IGN_ACC | _IGN_YAW_RATE


def ned_to_enu(n: float, e: float, d: float) -> tuple[float, float, float]:
    return (e, n, -d)


def enu_to_ned(x: float, y: float, z: float) -> tuple[float, float, float]:
    return (y, x, -z)


@dataclass
class VehicleTelemetry:
    """Latest vehicle state decoded from MAVLink (thread-safe snapshot copy)."""
    heartbeat_time: float = 0.0
    armed: bool = False
    main_mode: int = 0
    sub_mode: int = 0
    system_status: int = 0
    landed_state: int = 0                # MAV_LANDED_STATE_*
    prearm_ok: bool = False
    local_valid: bool = False
    local_time: float = 0.0
    ned: tuple[float, float, float] = (0.0, 0.0, 0.0)
    ned_vel: tuple[float, float, float] = (0.0, 0.0, 0.0)
    lat: float = 0.0
    lon: float = 0.0
    alt_msl: float = 0.0
    px4_battery_pct: float = -1.0
    statustext: list = field(default_factory=list)

    @property
    def is_offboard(self) -> bool:
        return self.main_mode == PX4_MAIN_OFFBOARD

    @property
    def mode_name(self) -> str:
        if self.main_mode == PX4_MAIN_OFFBOARD:
            return "OFFBOARD"
        if self.main_mode == PX4_MAIN_AUTO:
            return {PX4_AUTO_TAKEOFF: "AUTO.TAKEOFF", PX4_AUTO_LOITER: "AUTO.LOITER",
                    PX4_AUTO_MISSION: "AUTO.MISSION", PX4_AUTO_RTL: "AUTO.RTL",
                    PX4_AUTO_LAND: "AUTO.LAND"}.get(self.sub_mode, f"AUTO.{self.sub_mode}")
        return {PX4_MAIN_MANUAL: "MANUAL", PX4_MAIN_ALTCTL: "ALTCTL",
                PX4_MAIN_POSCTL: "POSCTL"}.get(self.main_mode, f"MODE{self.main_mode}")


class PX4Link:
    """Owns the UDP socket for one PX4 instance and decodes its telemetry."""

    def __init__(self, udp_port: int, target_sysid: int, *, source_sysid: int = 245,
                 source_compid: int = 190, host: str = "127.0.0.1", logger=None):
        self.udp_port = udp_port
        self.target_sysid = target_sysid
        self.log = logger
        self._conn = mavutil.mavlink_connection(
            f"udpin:{host}:{udp_port}", source_system=source_sysid,
            source_component=source_compid, autoreconnect=True)
        self._tx_lock = threading.Lock()
        self._rx_lock = threading.Lock()
        self._telem = VehicleTelemetry()
        self._acks: dict[int, tuple[int, float]] = {}
        self._foreign_sysids: set[int] = set()
        self._running = True
        self._last_hb_tx = 0.0
        self._thread = threading.Thread(target=self._rx_loop, name=f"px4link{udp_port}", daemon=True)
        self._thread.start()

    # ------------------------------------------------------------------ rx
    def _rx_loop(self) -> None:
        while self._running:
            try:
                msg = self._conn.recv_match(blocking=True, timeout=0.2)
            except Exception as exc:  # socket errors should not kill the thread
                self._warn(f"recv error: {exc}")
                time.sleep(0.2)
                continue
            now = time.monotonic()
            if now - self._last_hb_tx > 1.0:
                self._send_gcs_heartbeat()
                self._last_hb_tx = now
            if msg is None:
                continue
            mtype = msg.get_type()
            if mtype == "BAD_DATA":
                continue
            src = msg.get_srcSystem()
            if src != self.target_sysid:
                # Safety check: a different vehicle on our port means a mis-configuration.
                if src not in self._foreign_sysids and src not in (0, 245, 255):
                    self._foreign_sysids.add(src)
                    self._warn(f"ignoring MAVLink from unexpected sysid {src} on port {self.udp_port}")
                continue
            self._handle(mtype, msg, now)

    def _handle(self, mtype: str, msg, now: float) -> None:
        with self._rx_lock:
            t = self._telem
            if mtype == "HEARTBEAT" and msg.get_srcComponent() == mavlink.MAV_COMP_ID_AUTOPILOT1:
                t.heartbeat_time = now
                t.armed = bool(msg.base_mode & mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
                t.main_mode = (msg.custom_mode >> 16) & 0xFF
                t.sub_mode = (msg.custom_mode >> 24) & 0xFF
                t.system_status = msg.system_status
            elif mtype == "LOCAL_POSITION_NED":
                t.ned = (msg.x, msg.y, msg.z)
                t.ned_vel = (msg.vx, msg.vy, msg.vz)
                t.local_valid = True
                t.local_time = now
            elif mtype == "EXTENDED_SYS_STATE":
                t.landed_state = msg.landed_state
            elif mtype == "SYS_STATUS":
                t.prearm_ok = bool(msg.onboard_control_sensors_health & mavlink.MAV_SYS_STATUS_PREARM_CHECK)
                if msg.battery_remaining >= 0:
                    t.px4_battery_pct = float(msg.battery_remaining)
            elif mtype == "GLOBAL_POSITION_INT":
                t.lat = msg.lat * 1e-7
                t.lon = msg.lon * 1e-7
                t.alt_msl = msg.alt * 1e-3
            elif mtype == "COMMAND_ACK":
                self._acks[msg.command] = (msg.result, now)
            elif mtype == "STATUSTEXT":
                text = msg.text if isinstance(msg.text, str) else msg.text.decode(errors="ignore")
                t.statustext.append((now, msg.severity, text.strip("\x00")))
                del t.statustext[:-50]

    # ------------------------------------------------------------------ helpers
    def _warn(self, text: str) -> None:
        if self.log is not None:
            self.log.warning(text)

    def telemetry(self) -> VehicleTelemetry:
        with self._rx_lock:
            t = self._telem
            return VehicleTelemetry(**{k: (list(v) if isinstance(v, list) else v)
                                       for k, v in t.__dict__.items()})

    def connected(self, timeout: float = 2.0) -> bool:
        with self._rx_lock:
            return time.monotonic() - self._telem.heartbeat_time < timeout

    def last_ack(self, command: int) -> tuple[int, float] | None:
        with self._rx_lock:
            return self._acks.get(command)

    # ------------------------------------------------------------------ tx
    def _send(self, fn, *args) -> None:
        with self._tx_lock:
            fn(*args)

    def _send_gcs_heartbeat(self) -> None:
        # Identifies this controller as a GCS-type component, which satisfies
        # PX4's "No connection to the GCS" preflight check.
        try:
            self._send(self._conn.mav.heartbeat_send, mavlink.MAV_TYPE_GCS,
                       mavlink.MAV_AUTOPILOT_INVALID, 0, 0, mavlink.MAV_STATE_ACTIVE)
        except Exception:
            pass  # no peer address yet (nothing received)

    def command_long(self, command: int, *params: float) -> None:
        p = list(params) + [0.0] * (7 - len(params))
        self._send(self._conn.mav.command_long_send, self.target_sysid,
                   mavlink.MAV_COMP_ID_AUTOPILOT1, command, 0, *p)

    def set_mode(self, main_mode: int, sub_mode: int = 0) -> None:
        self.command_long(mavlink.MAV_CMD_DO_SET_MODE,
                          mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED, main_mode, sub_mode)

    def set_offboard(self) -> None:
        self.set_mode(PX4_MAIN_OFFBOARD)

    def arm(self) -> None:
        self.command_long(mavlink.MAV_CMD_COMPONENT_ARM_DISARM, 1)

    def disarm(self, force: bool = False) -> None:
        self.command_long(mavlink.MAV_CMD_COMPONENT_ARM_DISARM, 0, 21196 if force else 0)

    def land(self) -> None:
        self.command_long(mavlink.MAV_CMD_NAV_LAND, 0, 0, 0, float("nan"), float("nan"),
                          float("nan"), float("nan"))

    def hold(self) -> None:
        self.set_mode(PX4_MAIN_AUTO, PX4_AUTO_LOITER)

    def request_interval(self, msg_id: int, hz: float) -> None:
        self.command_long(mavlink.MAV_CMD_SET_MESSAGE_INTERVAL, msg_id, 1e6 / hz)

    def send_setpoint_ned(self, n: float, e: float, d: float, vn: float = 0.0, ve: float = 0.0,
                          vd: float = 0.0, yaw: float = float("nan"), use_velocity: bool = True) -> None:
        mask = MASK_POS_VEL_YAW if use_velocity else MASK_POS_YAW
        self._send(self._conn.mav.set_position_target_local_ned_send, 0, self.target_sysid,
                   mavlink.MAV_COMP_ID_AUTOPILOT1, mavlink.MAV_FRAME_LOCAL_NED, mask,
                   n, e, d, vn, ve, vd, 0.0, 0.0, 0.0, yaw, 0.0)

    def close(self) -> None:
        self._running = False
        self._thread.join(timeout=1.0)
        try:
            self._conn.close()
        except Exception:
            pass
