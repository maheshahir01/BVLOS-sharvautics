"""UAV failure detection from missing heartbeats (telemetry), with partition inference.

A UAV whose telemetry has not arrived for `heartbeat_timeout_s` becomes LOST.
If several UAVs are lost at once, the GCS cannot tell from silence alone who failed
and who is merely cut off. It therefore uses each UAV's *last known route* to the
GCS: if that route passed through another UAV that is now also lost, the UAV is
marked PARTITIONED (probably alive, behind a failed relay) rather than suspected
failed. How the link died also matters. If the UAV's link was already DEGRADED/FAILED before it
went silent, or it was last seen at the edge of radio coverage (a *fade*: flying out of
range, interference), the confirmation takes 3x longer. If it vanished while the link was GOOD/WARNING (*abrupt* silence), a real failure is
likely and the normal `failure_confirm_s` applies. A partitioned UAV is declared FAILED only
after 3x that time. Any UAV that is heard again is RECONNECTED.
"""
from __future__ import annotations

from .types import Health, LinkStatus, UAVView


class FailureDetector:
    def __init__(self, heartbeat_timeout: float, confirm_s: float):
        self.hb_timeout = heartbeat_timeout
        self.confirm = confirm_s
        self.partitioned_behind: dict[str, str] = {}
        self.faded: set[str] = set()

    def _root_cause(self, uid: str, views: dict[str, UAVView], lost: set[str]) -> str | None:
        route = views[uid].route or []
        # route: [uid, hop1, hop2, ..., 'gcs']; the lost hop nearest to the GCS is the root cause
        inner = [n for n in route[1:-1] if n in lost]
        return inner[-1] if inner else None

    def update(self, views: dict[str, UAVView], now: float) -> list[dict]:
        events: list[dict] = []
        lost_now = {uid for uid, v in views.items()
                    if v.last_heartbeat is not None and now - v.last_heartbeat > self.hb_timeout}
        for uid, v in sorted(views.items()):
            if v.last_heartbeat is None:
                continue
            age = now - v.last_heartbeat
            if uid in lost_now:
                if v.health in (Health.OK, Health.WARNING):
                    v.health = Health.LOST
                    v.lost_since = now
                    root = self._root_cause(uid, views, lost_now)
                    if root:
                        self.partitioned_behind[uid] = root
                    # "fade": the link was already degraded, or the UAV was last seen at the edge of
                    # radio coverage -> most likely out of range, not crashed
                    fade = v.link_status in (LinkStatus.DEGRADED, LinkStatus.FAILED) or v.coverage_margin < 0.2
                    if fade:
                        self.faded.add(uid)
                    events.append({"type": "HEARTBEAT_LOST", "uav_id": uid, "age": round(age, 2),
                                   "last_route": list(v.route or []), "partitioned_behind": root,
                                   "fade": fade})
                elif v.health == Health.LOST:
                    root = self.partitioned_behind.get(uid)
                    if root is None:
                        # the relay may have timed out after this UAV: re-examine the partition
                        root = self._root_cause(uid, views, lost_now)
                        if root:
                            self.partitioned_behind[uid] = root
                            events.append({"type": "HEARTBEAT_LOST", "uav_id": uid, "age": round(age, 2),
                                           "last_route": list(v.route or []), "partitioned_behind": root,
                                           "late_inference": True})
                    limit = self.confirm * (3.0 if (root or uid in self.faded) else 1.0)
                    if now - (v.lost_since or now) > limit:
                        v.health = Health.FAILED
                        events.append({"type": "UAV_FAILED", "uav_id": uid, "lost_for": round(now - v.lost_since, 2),
                                       "partitioned_behind": root})
            else:
                if v.health in (Health.LOST, Health.FAILED):
                    was = v.health
                    down = now - (v.lost_since or now)
                    v.health = Health.OK
                    v.lost_since = None
                    root = self.partitioned_behind.pop(uid, None)
                    self.faded.discard(uid)
                    events.append({"type": "RECONNECTED", "uav_id": uid, "was": was.value,
                                   "down_time": round(down, 2), "partitioned_behind": root})
        return events
