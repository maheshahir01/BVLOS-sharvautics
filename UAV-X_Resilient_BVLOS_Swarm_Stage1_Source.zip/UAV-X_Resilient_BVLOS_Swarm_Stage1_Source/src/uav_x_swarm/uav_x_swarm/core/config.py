"""Configuration loading (config/swarm.yaml + optional scenario overrides)."""
from __future__ import annotations

import copy
import os
from typing import Any

import yaml


def project_root() -> str:
    """Project root: $UAVX_ROOT if set, else walk up from this file to find config/swarm.yaml."""
    env = os.environ.get("UAVX_ROOT")
    if env and os.path.isfile(os.path.join(env, "config", "swarm.yaml")):
        return env
    here = os.path.dirname(os.path.realpath(__file__))
    for _ in range(8):
        if os.path.isfile(os.path.join(here, "config", "swarm.yaml")):
            return here
        here = os.path.dirname(here)
    raise RuntimeError("cannot locate the project root (config/swarm.yaml); set UAVX_ROOT to the "
                       "repository directory")


def deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


class Config:
    """Thin wrapper around the merged YAML dictionary with dotted-path access."""

    def __init__(self, data: dict, root: str | None = None):
        self.data = data
        self.root = root or project_root()

    @classmethod
    def load(cls, path: str | None = None, scenario_path: str | None = None) -> "Config":
        root = project_root()
        path = path or os.path.join(root, "config", "swarm.yaml")
        with open(path) as f:
            data = yaml.safe_load(f)
        if scenario_path:
            with open(scenario_path) as f:
                scen = yaml.safe_load(f) or {}
            data = deep_merge(data, scen.get("overrides") or {})
        return cls(data, root)

    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self.data
        for key in dotted.split("."):
            if not isinstance(node, dict) or key not in node:
                return default
            node = node[key]
        return node

    def __getitem__(self, dotted: str) -> Any:
        val = self.get(dotted, _MISSING)
        if val is _MISSING:
            raise KeyError(dotted)
        return val

    def path(self, rel: str) -> str:
        return rel if os.path.isabs(rel) else os.path.join(self.root, rel)

    # ------------------------------------------------------------- derived values
    @property
    def num_uavs(self) -> int:
        return int(self["swarm.number_of_uavs"])

    def uav_ids(self) -> list[str]:
        prefix = self.get("swarm.id_prefix", "uav")
        return [f"{prefix}{k}" for k in range(1, self.num_uavs + 1)]

    def home_positions(self) -> dict[str, tuple[float, float]]:
        homes = [tuple(h) for h in self["swarm.home_positions"]]
        gen = self.get("swarm.pad_generator", {"origin": [35.0, -40.0], "spacing": [0.0, 20.0]})
        base = len(homes)
        while len(homes) < self.num_uavs:
            k = len(homes) - base
            homes.append((gen["origin"][0] + k * gen["spacing"][0], gen["origin"][1] + k * gen["spacing"][1]))
        return {uid: (float(h[0]), float(h[1])) for uid, h in zip(self.uav_ids(), homes)}

    def uav_index(self, uav_id: str) -> int:
        """1-based index of a UAV id (uav3 -> 3)."""
        return self.uav_ids().index(uav_id) + 1

    def cruise_altitude(self, uav_id: str) -> float:
        base = float(self["flight.cruise_altitude_m"])
        spacing = float(self.get("flight.altitude_layer_spacing_m", 0.0))
        return base + (self.uav_index(uav_id) - 1) * spacing

    def initial_battery(self, uav_id: str) -> float:
        val = self.get("swarm.initial_battery_pct", 100.0)
        if isinstance(val, list):
            idx = self.uav_index(uav_id) - 1
            return float(val[idx]) if idx < len(val) else 100.0
        return float(val)

    def gcs_position(self) -> tuple[float, float, float]:
        p = self["gcs.position"]
        return (float(p[0]), float(p[1]), float(p[2]))

    def pois(self) -> list[dict]:
        path = self.path(self["mission.pois_file"])
        with open(path) as f:
            return yaml.safe_load(f)["pois"]


_MISSING = object()
