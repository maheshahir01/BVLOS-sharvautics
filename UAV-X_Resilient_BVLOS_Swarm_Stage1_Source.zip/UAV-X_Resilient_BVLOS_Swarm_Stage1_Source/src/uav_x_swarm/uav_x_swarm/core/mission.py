"""Mission state machine with explicit, validated transitions."""
from __future__ import annotations

from .types import MissionPhase as P

TRANSITIONS: dict[P, set[P]] = {
    P.INITIALIZING: {P.TAKEOFF, P.MISSION_FAILED},
    P.TAKEOFF: {P.FORMATION, P.MISSION_FAILED},
    P.FORMATION: {P.DEPLOY, P.MISSION_FAILED},
    P.DEPLOY: {P.SURVEY, P.RECONFIGURING, P.EMERGENCY, P.RETURN_HOME, P.MISSION_FAILED},
    P.SURVEY: {P.RECONFIGURING, P.EMERGENCY, P.RETURN_HOME, P.MISSION_FAILED},
    P.RECONFIGURING: {P.SURVEY, P.EMERGENCY, P.RETURN_HOME, P.MISSION_FAILED},
    P.EMERGENCY: {P.SURVEY, P.RECONFIGURING, P.RETURN_HOME, P.MISSION_FAILED},
    P.RETURN_HOME: {P.LAND, P.RECONFIGURING, P.MISSION_FAILED},
    P.LAND: {P.MISSION_COMPLETE, P.MISSION_FAILED},
    P.MISSION_COMPLETE: set(),
    P.MISSION_FAILED: set(),
}


class InvalidTransition(RuntimeError):
    pass


class MissionStateMachine:
    def __init__(self):
        self.phase = P.INITIALIZING
        self.history: list[tuple[float, str, str, str]] = []   # (t, from, to, reason)
        self.entered_at = 0.0

    def can(self, to: P) -> bool:
        return to in TRANSITIONS[self.phase]

    def transition(self, to: P, t: float, reason: str) -> bool:
        if to == self.phase:
            return False
        if not self.can(to):
            raise InvalidTransition(f"{self.phase.value} -> {to.value} not allowed ({reason})")
        self.history.append((t, self.phase.value, to.value, reason))
        self.phase = to
        self.entered_at = t
        return True

    @property
    def terminal(self) -> bool:
        return self.phase in (P.MISSION_COMPLETE, P.MISSION_FAILED)
