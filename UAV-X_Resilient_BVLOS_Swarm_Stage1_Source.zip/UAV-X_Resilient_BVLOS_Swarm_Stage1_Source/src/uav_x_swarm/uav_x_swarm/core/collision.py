"""Inter-UAV collision avoidance (onboard) and separation monitoring.

Avoidance runs on every UAV (decentralised) using neighbour positions from its
detect-and-avoid sensing (in simulation: the other UAVs' position topics, which
do not depend on the lossy radio network). The avoidance command is a velocity
that is added to the nominal navigation velocity:

* trigger    : inside `avoidance_radius` (proximity) OR predicted closest approach within
               4 s closer than 1.6 x `minimum_safe_distance` (velocity-based prediction)
* repulsion  : up to `gain` m/s, directed away from the predicted closest-approach point (3-D)
* vertical   : the pair separates vertically; the UAV with the lower index climbs
               and the other descends (deterministic, so both agree without messages)
* tangential : when closing head-on, both turn right (right-hand rule) to break symmetry

Strategic deconfliction comes first: each UAV cruises on its own altitude layer.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from .geometry import add, norm, scale, sub, unit


def avoidance_velocity(own_idx: int, own_pos, own_vel, neighbours: list[tuple[int, tuple, tuple]],
                       radius: float, min_safe: float, gain: float,
                       horizon: float = 4.0) -> tuple[tuple[float, float, float], list[int]]:
    """Return (avoidance velocity, indices of neighbours that triggered it).

    A neighbour is a threat if it is inside `radius` (proximity) OR if, keeping the
    current velocities, the closest point of approach within `horizon` seconds would be
    closer than 1.6 x min_safe (prediction, which gives head-on encounters at 16 m/s closing
    speed enough time to react). The response pushes the UAV away from the predicted
    closest-approach point, splits the pair vertically (lower index climbs) and, for a
    near-perfect head-on geometry, turns right. Strength ramps with urgency up to `gain`.
    """
    v = (0.0, 0.0, 0.0)
    active = []
    guard = 1.6 * min_safe
    for idx, pos, vel in neighbours:
        d = sub(own_pos, pos)
        dist = norm(d)
        rel_v = sub(own_vel, vel)
        vv = rel_v[0] ** 2 + rel_v[1] ** 2 + rel_v[2] ** 2
        t_ca = 0.0
        if vv > 1e-6:
            t_ca = max(0.0, min(horizon, -(d[0] * rel_v[0] + d[1] * rel_v[1] + d[2] * rel_v[2]) / vv))
        miss_vec = add(d, scale(rel_v, t_ca))
        miss = norm(miss_vec)
        prox = max(0.0, min(1.0, (radius - dist) / max(1e-3, radius - min_safe))) if dist < radius else 0.0
        pred = 0.0
        if t_ca > 0.0 and miss < guard:
            pred = (1.0 - t_ca / horizon) * (1.0 - miss / guard)
            pred = max(0.0, min(1.0, 1.5 * pred))
        urgency = max(prox, pred)
        if urgency <= 0.0:
            continue
        active.append(idx)
        strength = gain * urgency
        # push away from the predicted closest approach (current offset if already closest)
        away_src = miss_vec if t_ca > 0.0 else d
        if norm(away_src) < 0.5:
            hx, hy = own_vel[0], own_vel[1]
            hn = math.hypot(hx, hy)
            away = (hy / hn, -hx / hn, 0.0) if hn > 0.3 else ((1.0, 0.0, 0.0) if own_idx < idx else (-1.0, 0.0, 0.0))
        else:
            away = unit(away_src)
        v = add(v, scale(away, strength))
        # deterministic vertical split: lower index climbs
        v = add(v, (0.0, 0.0, 0.6 * strength * (1.0 if own_idx < idx else -1.0)))
        # right-hand turn when closing (both turn right -> pass left side to left side)
        closing = -(d[0] * rel_v[0] + d[1] * rel_v[1]) / max(dist, 1e-3)
        if closing > 0.5:
            hx, hy = own_vel[0], own_vel[1]
            hn = math.hypot(hx, hy)
            if hn > 0.5:
                v = add(v, scale((hy / hn, -hx / hn, 0.0), 0.5 * strength))
    return v, active


@dataclass
class SeparationMonitor:
    """Pairwise separation bookkeeping (edge-triggered violation/collision counting)."""
    min_safe: float
    collision_dist: float
    min_separation: float = math.inf
    min_pair: tuple = ()
    violations: int = 0
    collisions: int = 0
    _in_violation: set = field(default_factory=set)
    _in_collision: set = field(default_factory=set)

    def update(self, positions: dict[str, tuple]) -> list[dict]:
        """positions: airborne UAVs only. Returns new events."""
        events = []
        ids = sorted(positions)
        for i, a in enumerate(ids):
            for b in ids[i + 1:]:
                d = math.dist(positions[a], positions[b])
                pair = (a, b)
                if d < self.min_separation:
                    self.min_separation, self.min_pair = d, pair
                if d < self.min_safe:
                    if pair not in self._in_violation:
                        self._in_violation.add(pair)
                        self.violations += 1
                        events.append({"type": "SEPARATION_VIOLATION", "pair": pair, "distance": round(d, 2)})
                elif d > self.min_safe + 1.0:
                    self._in_violation.discard(pair)
                if d < self.collision_dist:
                    if pair not in self._in_collision:
                        self._in_collision.add(pair)
                        self.collisions += 1
                        events.append({"type": "COLLISION", "pair": pair, "distance": round(d, 2)})
                elif d > self.collision_dist + 1.0:
                    self._in_collision.discard(pair)
        return events
