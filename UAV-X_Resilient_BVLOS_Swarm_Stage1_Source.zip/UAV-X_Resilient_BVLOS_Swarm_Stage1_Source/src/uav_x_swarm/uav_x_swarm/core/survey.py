"""Survey pattern generation: one orbit around the PoI, starting at the point
nearest to the approaching UAV (so no time is wasted flying across the PoI)."""
from __future__ import annotations

import math


def orbit_waypoints(center_xy, radius: float, alt: float, n_points: int, approach_from=None) -> list[tuple]:
    cx, cy = center_xy[0], center_xy[1]
    if approach_from is not None and math.hypot(approach_from[0] - cx, approach_from[1] - cy) > 1e-3:
        a0 = math.atan2(approach_from[1] - cy, approach_from[0] - cx)
    else:
        a0 = 0.0
    n = max(4, int(n_points))
    return [(cx + radius * math.cos(a0 + 2 * math.pi * k / n),
             cy + radius * math.sin(a0 + 2 * math.pi * k / n), alt) for k in range(n + 1)]


def survey_distance(radius: float) -> float:
    return 2 * math.pi * radius


def approach_point(center_xy, radius: float, alt: float, from_xy) -> tuple:
    return orbit_waypoints(center_xy, radius, alt, 4, from_xy)[0]
