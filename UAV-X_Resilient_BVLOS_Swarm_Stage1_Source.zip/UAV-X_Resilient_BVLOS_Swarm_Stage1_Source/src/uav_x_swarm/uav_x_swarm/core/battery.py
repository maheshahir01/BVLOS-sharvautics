"""Deterministic, configurable battery model and battery policy.

Drain (percent) per control step dt:
    hover_drain_pct_s * dt                (airborne baseline)
  + distance_drain_pct_per_m * |v| * dt   (movement)
  + relay_extra_pct_s * dt                (when acting as relay: radio TX power)
  + survey_extra_pct_s * dt               (when surveying: payload power)
all multiplied by a degradation factor (1.0 nominal; scenario events can raise it
to model a failing cell). No drain on the ground.

The policy computes the energy needed to fly a distance and triggers
return-to-home at max(rth_pct, 1.25 * energy_to_home + critical + reserve), so a
UAV reaches home above its critical level regardless of distance or drain rate.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BatteryParams:
    hover: float
    per_m: float
    relay_extra: float
    survey_extra: float
    warning: float
    rth: float
    critical: float
    reserve: float

    @classmethod
    def from_cfg(cls, b: dict) -> "BatteryParams":
        return cls(float(b["hover_drain_pct_s"]), float(b["distance_drain_pct_per_m"]),
                   float(b.get("relay_extra_pct_s", 0.0)), float(b.get("survey_extra_pct_s", 0.0)),
                   float(b["warning_pct"]), float(b["rth_pct"]), float(b["critical_pct"]),
                   float(b.get("reserve_pct", 10.0)))


class BatteryModel:
    def __init__(self, params: BatteryParams, initial_pct: float = 100.0):
        self.p = params
        self.pct = float(initial_pct)
        self.multiplier = 1.0
        self.consumed = 0.0

    def update(self, dt: float, airborne: bool, speed: float, relay: bool = False, surveying: bool = False) -> float:
        if not airborne or dt <= 0:
            return self.pct
        drain = self.p.hover * dt + self.p.per_m * speed * dt
        if relay:
            drain += self.p.relay_extra * dt
        if surveying:
            drain += self.p.survey_extra * dt
        drain *= self.multiplier
        self.pct = max(0.0, self.pct - drain)
        self.consumed += drain
        return self.pct

    def degrade(self, multiplier: float | None = None, drop_pct: float | None = None,
                set_pct: float | None = None) -> None:
        if multiplier is not None:
            self.multiplier = float(multiplier)
        if drop_pct is not None:
            self.pct = max(0.0, self.pct - float(drop_pct))
        if set_pct is not None:
            self.pct = min(self.pct, float(set_pct))


class BatteryPolicy:
    def __init__(self, params: BatteryParams, cruise_speed: float):
        self.p = params
        self.cruise = max(0.5, cruise_speed)

    def energy_for_distance(self, distance_m: float, multiplier: float = 1.0) -> float:
        t = distance_m / self.cruise
        return (self.p.hover * t + self.p.per_m * distance_m) * multiplier

    def energy_for_hover(self, seconds: float, extra: float = 0.0, multiplier: float = 1.0) -> float:
        return (self.p.hover + extra) * seconds * multiplier

    SAFETY_FACTOR = 1.25     # margin on the energy model (wind, detours, avoidance)

    def rth_threshold(self, distance_home_m: float, multiplier: float = 1.0) -> float:
        """Battery level at which the UAV must start returning home: it arrives with at
        least critical + reserve even if the trip costs 25 % more than modelled."""
        need = self.SAFETY_FACTOR * self.energy_for_distance(distance_home_m, multiplier)
        return max(self.p.rth, need + self.p.critical + self.p.reserve)

    def status(self, pct: float) -> str:
        if pct <= self.p.critical:
            return "CRITICAL"
        if pct <= self.p.rth:
            return "RTH"
        if pct <= self.p.warning:
            return "WARNING"
        return "OK"


class DrainEstimator:
    """GCS-side estimate of a UAV's actual drain rate from its telemetry.

    The GCS cannot see a failing cell directly; it compares the observed battery
    decrease with what the model predicts for the reported speed/role and derives a
    drain factor (1.0 = nominal). Step drops (> step_pct between consecutive
    samples) are reported as anomalies and excluded from the rate estimate.
    """

    def __init__(self, params: BatteryParams, window_s: float = 15.0, step_pct: float = 3.0):
        self.p = params
        self.window = window_s
        self.step = step_pct
        self.samples: dict[str, list] = {}
        self.factor: dict[str, float] = {}

    def update(self, uid: str, t: float, battery: float, speed: float, airborne: bool,
               relay: bool, surveying: bool) -> float | None:
        """Add a sample; returns the size of a detected step drop (percent) or None."""
        buf = self.samples.setdefault(uid, [])
        step = None
        if buf and buf[-1][1] - battery > self.step and t - buf[-1][0] < 3.0:
            step = buf[-1][1] - battery
            buf.clear()
        if not airborne:
            buf.clear()
            return step
        expected = self.p.hover + self.p.per_m * speed + (self.p.relay_extra if relay else 0.0) \
            + (self.p.survey_extra if surveying else 0.0)
        buf.append((t, battery, expected))
        while buf and t - buf[0][0] > self.window:
            buf.pop(0)
        if len(buf) >= 8 and buf[-1][0] - buf[0][0] >= 0.6 * self.window:
            dt = buf[-1][0] - buf[0][0]
            observed = (buf[0][1] - buf[-1][1]) / dt
            exp_mean = sum(x[2] for x in buf) / len(buf)
            f = max(1.0, min(6.0, observed / max(1e-6, exp_mean)))
            prev = self.factor.get(uid, 1.0)
            self.factor[uid] = 0.7 * prev + 0.3 * f
        return step

    def get(self, uid: str) -> float:
        return self.factor.get(uid, 1.0)

