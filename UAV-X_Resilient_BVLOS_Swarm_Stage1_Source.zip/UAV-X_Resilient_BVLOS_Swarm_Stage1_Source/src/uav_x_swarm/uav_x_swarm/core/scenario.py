"""Scenario files: declarative failure injection (no source edits needed).

Example (scenarios/stage1_demo.yaml):

    name: stage1_demo
    overrides: {communication: {seed: 7}}       # optional config overrides
    events:
      - id: relay_failure
        type: UAV_FAILURE
        target: RELAY                              # resolved at trigger time
        trigger: {condition: {completed_pois_gte: 2}, min_time: 60}
      - id: new_poi
        type: NEW_PRIORITY_POI
        poi: POI7                                  # from config/mission_pois.yaml
        trigger: {after_event: relay_failure, delay: 40}

Triggers (all given keys must hold):
    time: T                   mission time >= T seconds (since MISSION_START)
    min_time: T               same as time, used together with a condition
    condition: {...}          completed_pois_gte, phase_in, surveys_started_gte
    after_event: ID, delay: D fires D seconds after event ID fired
Targets: uavN, RELAY (current relay), SURVEY (the busiest survey UAV), ALL.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import yaml

EVENT_TYPES = {
    "UAV_FAILURE", "COMM_DEGRADATION", "COMM_OUTAGE", "COMM_RESTORE", "LATENCY", "PACKET_LOSS",
    "BATTERY_DEGRADATION", "NEW_PRIORITY_POI", "RETURN_HOME", "GOTO",
}


@dataclass
class ScenarioEvent:
    id: str
    type: str
    target: str | None
    params: dict
    trigger: dict
    fired: bool = False
    fired_at: float | None = None
    resolved_target: str | None = None


@dataclass
class Scenario:
    name: str
    description: str
    events: list[ScenarioEvent] = field(default_factory=list)
    timeout_s: float | None = None
    raw: dict = field(default_factory=dict)

    @classmethod
    def load(cls, path: str) -> "Scenario":
        with open(path) as f:
            raw = yaml.safe_load(f) or {}
        evs = []
        for i, e in enumerate(raw.get("events") or []):
            etype = str(e["type"]).upper()
            if etype not in EVENT_TYPES:
                raise ValueError(f"{path}: unknown event type {etype}")
            trig = e.get("trigger")
            if trig is None and "time" in e:
                trig = {"time": e["time"]}
            if not trig:
                raise ValueError(f"{path}: event {e} has no trigger")
            params = {k: v for k, v in e.items() if k not in ("id", "type", "target", "trigger", "time")}
            evs.append(ScenarioEvent(str(e.get("id", f"ev{i + 1}")), etype, e.get("target"), params, trig))
        ids = [e.id for e in evs]
        if len(ids) != len(set(ids)):
            raise ValueError(f"{path}: duplicate event ids")
        for e in evs:
            ref = e.trigger.get("after_event")
            if ref and ref not in ids:
                raise ValueError(f"{path}: event {e.id} references unknown event {ref}")
        return cls(raw.get("name", path), raw.get("description", ""), evs,
                   (raw.get("mission") or {}).get("timeout_s"), raw)

    def _cond_ok(self, cond: dict, status: dict) -> bool:
        if "completed_pois_gte" in cond and status.get("completed_pois", 0) < cond["completed_pois_gte"]:
            return False
        if "surveys_started_gte" in cond and status.get("surveys_started", 0) < cond["surveys_started_gte"]:
            return False
        if "phase_in" in cond and status.get("phase") not in cond["phase_in"]:
            return False
        return True

    def due(self, mission_time: float, status: dict) -> list[ScenarioEvent]:
        out = []
        by_id = {e.id: e for e in self.events}
        for e in self.events:
            if e.fired:
                continue
            tr = e.trigger
            t_min = max(float(tr.get("time", 0.0)), float(tr.get("min_time", 0.0)))
            if mission_time < t_min:
                continue
            if "condition" in tr and not self._cond_ok(tr["condition"], status):
                continue
            if "after_event" in tr:
                ref = by_id[tr["after_event"]]
                if not ref.fired or mission_time < ref.fired_at + float(tr.get("delay", 0.0)):
                    continue
            out.append(e)
        return out

    @staticmethod
    def resolve_target(target: str | None, status: dict) -> list[str]:
        uavs = status.get("uavs", {})
        if target is None:
            return []
        t = str(target)
        if t.upper() == "RELAY":
            return [status["relay"]] if status.get("relay") else []
        if t.upper() == "ALL":
            return sorted(uavs)
        if t.upper() == "SURVEY":
            workers = [(len(u.get("task_queue", [])), uid) for uid, u in uavs.items()
                       if u.get("role") in ("SURVEY", "SURVEY_RELAY") and u.get("health") in ("OK", "WARNING")]
            return [sorted(workers, key=lambda x: (-x[0], x[1]))[0][1]] if workers else []
        return [t.lower()]
