"""Autonomous task allocation (greedy, priority-first insertion auction).

For each pending PoI, highest priority first:
  * candidate UAVs: healthy, reachable, not RELAY / RETURN_HOME / FAILED, queue not full;
  * for each candidate, the cheapest insertion position in its queue is found
    (positions after a task that is already being surveyed are fixed, unless the new
    PoI may pre-empt it: HIGH/CRITICAL over lower priority);
  * energy feasibility: after flying the new route up to and including the PoI's
    survey orbit, the UAV must still be above its RTH threshold at that point
    (max(rth_pct, energy_to_home + reserve));
  * priority order inside a queue is a hard constraint (never behind a lower-priority task);
  * HIGH/CRITICAL PoIs take the earliest allowed slot and cost = distance until served
    (+ pre-emption penalty), i.e. minimum response time;
  * other PoIs take the cheapest slot and cost = total route length after insertion (the
    time at which that UAV finishes its queue) + queue_penalty * queue length, which spreads
    work over the swarm and shortens mission completion time;
  * the PoI goes to the feasible UAV with minimum cost (ties -> lowest UAV id).
Tasks held by UAVs that failed, were lost for too long, or returned home are
released back to PENDING and re-auctioned (task reallocation).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .battery import BatteryPolicy
from .priority import PriorityManager
from .survey import survey_distance
from .types import FlightState, Health, LinkStatus, PoI, Role, TaskStatus, UAVView

_WORKING_STATES = {FlightState.READY, FlightState.ARMING, FlightState.TAKEOFF, FlightState.HOLD,
                   FlightState.TRANSIT, FlightState.SURVEY}


@dataclass
class AllocationEvent:
    type: str
    poi_id: str
    uav_id: str | None
    details: str


class TaskAllocator:
    def __init__(self, cfg, battery_policy: BatteryPolicy, priority: PriorityManager):
        self.max_queue = int(cfg["mission.allocation.max_queue"])
        self.queue_penalty = 40.0
        self.preempt_penalty = 60.0
        self.survey_radius = float(cfg["flight.survey_radius_m"])
        self.survey_speed = float(cfg["flight.survey_speed_mps"])
        self.survey_extra = float(cfg["battery.survey_extra_pct_s"])
        self.bp = battery_policy
        self.prio = priority

    # ------------------------------------------------------------------ helpers
    def is_candidate(self, u: UAVView) -> tuple[bool, str]:
        if u.health not in (Health.OK, Health.WARNING):
            return False, u.health.value
        if u.role in (Role.RELAY, Role.RETURN_HOME, Role.FAILED, Role.EMERGENCY):
            return False, u.role.value
        if u.flight_state not in _WORKING_STATES:
            return False, u.flight_state.value
        if u.link_status in (LinkStatus.DISCONNECTED, LinkStatus.FAILED):
            return False, "UNREACHABLE"
        if u.battery <= self.bp.p.warning - 5.0:
            return False, "BATTERY_LOW"
        return True, "OK"

    def _survey_energy(self) -> float:
        t = survey_distance(self.survey_radius) / max(0.5, self.survey_speed)
        return self.bp.energy_for_hover(t, self.survey_extra) + self.bp.p.per_m * survey_distance(self.survey_radius)

    def route_energy_ok(self, u: UAVView, route: list[tuple], idx_of_new: int) -> bool:
        """Energy check along `route` (PoI centres) up to and including route[idx_of_new]."""
        pos = u.position[:2]
        energy = 0.0
        f = max(1.0, getattr(u, "drain_factor", 1.0))
        for k, p in enumerate(route[: idx_of_new + 1]):
            energy += (self.bp.energy_for_distance(math.dist(pos, p)) + self._survey_energy()) * f
            pos = p
        remaining = u.battery - energy
        return remaining >= self.bp.rth_threshold(math.dist(pos, u.home), f)

    @staticmethod
    def path_len(start, pts: list[tuple]) -> float:
        total, cur = 0.0, start
        for p in pts:
            total += math.dist(cur, p)
            cur = p
        return total

    # ------------------------------------------------------------------ main
    def plan(self, pois: dict[str, PoI], uavs: dict[str, UAVView], queues: dict[str, list[str]],
             in_progress: dict[str, str | None]) -> tuple[dict[str, list[str]], list[AllocationEvent]]:
        """Return (new queues, events). `in_progress[uav]` is the PoI being surveyed right now."""
        events: list[AllocationEvent] = []
        new_q = {uid: [t for t in queues.get(uid, []) if pois.get(t) and
                       pois[t].status not in (TaskStatus.COMPLETED, TaskStatus.SURVEYED, TaskStatus.REJECTED)]
                 for uid in uavs}

        # 1. release tasks of UAVs that can no longer work on them. A LOST (possibly just
        #    partitioned) or temporarily unreachable UAV keeps its queue: it continues
        #    autonomously and delivers reports by store-and-forward.
        for uid, q in new_q.items():
            u = uavs[uid]
            reason = None
            if u.health == Health.FAILED:
                reason = "FAILED"
            elif u.role in (Role.RETURN_HOME, Role.FAILED, Role.RELAY, Role.EMERGENCY):
                reason = u.role.value
            elif u.flight_state in (FlightState.LANDING, FlightState.LANDED, FlightState.FAILED,
                                    FlightState.RETURN_HOME):
                reason = u.flight_state.value
            if reason and q:
                for t in q:
                    pois[t].status = TaskStatus.PENDING
                    pois[t].assigned_to = None
                    events.append(AllocationEvent("TASK_RELEASED", t, uid, f"{uid} unavailable ({reason})"))
                new_q[uid] = []

        # 2. auction pending tasks (highest priority first)
        pending = sorted([p for p in pois.values() if p.status == TaskStatus.PENDING], key=self.prio.sort_key)
        for poi in pending:
            w_new = self.prio.weight(poi.priority)
            urgent = poi.priority.upper() in self.prio.preempt_for
            best = None
            for uid, u in sorted(uavs.items()):
                ok, _ = self.is_candidate(u)
                if not ok or len(new_q[uid]) >= self.max_queue:
                    continue
                q = new_q[uid]
                cur = in_progress.get(uid)
                locked = 1 if (cur and q and q[0] == cur) else 0
                preempt_ok = locked == 1 and self.prio.can_preempt(poi.priority, pois[cur].priority)
                start = 0 if preempt_ok else locked
                # Priority order is a hard constraint: the new task never waits behind a
                # lower-priority task (queues are kept priority-sorted after the locked head).
                p_min = start
                for j in range(start, len(q)):
                    if self.prio.weight(pois[q[j]].priority) >= w_new:
                        p_min = j + 1
                    else:
                        break
                # urgent (HIGH/CRITICAL) tasks go to the earliest allowed slot: minimise response time
                positions = [p_min] if urgent else list(range(p_min, len(q) + 1))
                for pos in positions:
                    trial = q[:pos] + [poi.id] + q[pos:]
                    pts = [tuple(pois[t].position) for t in trial]
                    if not self.route_energy_ok(u, pts, pos):
                        continue
                    if urgent:
                        cost = self.path_len(u.position[:2], pts[:pos + 1])       # distance until served
                    else:
                        # total route length after insertion = when this UAV finishes its queue
                        # (minimising it balances load across UAVs, i.e. mission completion time)
                        cost = self.path_len(u.position[:2], pts) + self.queue_penalty * len(q)
                    if pos == 0 and locked:
                        cost += self.preempt_penalty
                    if best is None or cost < best[0] - 1e-6 or (abs(cost - best[0]) < 1e-6 and uid < best[1]):
                        best = (cost, uid, pos, trial)
            if best is None:
                events.append(AllocationEvent("TASK_UNASSIGNABLE", poi.id, None,
                                              "no UAV can serve it (availability/energy)"))
                continue
            cost, uid, pos, trial = best
            preempted = in_progress.get(uid) if (pos == 0 and new_q[uid] and in_progress.get(uid) == new_q[uid][0]) else None
            new_q[uid] = trial
            poi.status = TaskStatus.ASSIGNED
            poi.assigned_to = uid
            poi.attempts += 1
            detail = f"cost {cost:.0f} m, queue position {pos + 1}/{len(trial)}"
            if preempted:
                detail += f", pre-empts {preempted}"
                events.append(AllocationEvent("TASK_PREEMPTED", preempted, uid,
                                              f"{poi.id} ({poi.priority}) takes precedence"))
            events.append(AllocationEvent("TASK_ASSIGNED", poi.id, uid, detail))
        return new_q, events
