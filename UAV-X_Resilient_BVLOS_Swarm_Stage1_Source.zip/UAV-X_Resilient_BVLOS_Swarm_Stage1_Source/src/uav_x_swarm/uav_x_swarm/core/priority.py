"""Priority handling for PoIs (weights, ordering, pre-emption, validation, score)."""
from __future__ import annotations

from .geofence import Geofence
from .types import PoI, TaskStatus


class PriorityManager:
    def __init__(self, weights: dict, preempt_for: list[str]):
        self.weights = {k.upper(): float(v) for k, v in weights.items()}
        self.preempt_for = {p.upper() for p in preempt_for}

    def weight(self, priority: str) -> float:
        return self.weights.get(priority.upper(), 1.0)

    def sort_key(self, poi: PoI):
        return (-self.weight(poi.priority), poi.announced_at or 0.0, poi.id)

    def can_preempt(self, new_priority: str, current_priority: str | None) -> bool:
        if new_priority.upper() not in self.preempt_for:
            return False
        return current_priority is None or self.weight(new_priority) > self.weight(current_priority)

    @staticmethod
    def validate(poi: PoI, fence: Geofence, margin: float) -> tuple[bool, str]:
        p = (poi.position[0], poi.position[1], 0.0)
        if not fence.contains(p, margin):
            return False, f"outside geofence (margin {margin:.0f} m)"
        return True, "ok"

    def weighted_score(self, pois: list[PoI]) -> float:
        total = sum(self.weight(p.priority) for p in pois if p.status != TaskStatus.REJECTED)
        done = sum(self.weight(p.priority) for p in pois if p.status == TaskStatus.COMPLETED)
        return done / total if total > 0 else 0.0
