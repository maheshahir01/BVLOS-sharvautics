"""Onboard lost-link procedure with distributed (peer) relay election.

When a UAV has not received anything from the GCS for `lost_link_timeout_s`,
it cannot be commanded. Instead of all UAVs flying home, the UAVs that can
still hear each other (one-hop beacons) elect a *bridge* among themselves. Every
UAV evaluates the same deterministic rule on the same beacon data, so they agree
without an extra negotiation round:

    candidates = {me} + {beacon neighbours heard recently that also lack GCS contact
                          and are eligible (not returning home, battery >= min)}
    election score = 0.6 * position + 0.4 * battery
        position = 1 - dist(candidate, relay_point) / (2 * gcs_range)
        battery  = (battery - rth) / (100 - rth)
    winner = highest score, ties -> lowest UAV index

Actions:
    BRIDGE    : I won and at least one peer needs a bridge -> fly to the relay point and
                hold (become relay)
    CONTINUE  : keep working my task queue; reports wait in the store-and-forward outbox
    CONTINUE_CURRENT : isolated (no peers): finish the survey in progress, then RECONNECT
    RECONNECT : queue empty -> fly toward the relay point until the GCS link returns
    RETURN    : lost link has lasted `lost_link_rth_s` -> return home (last resort)
A relay that loses the GCS flies toward the GCS (RECONNECT) because its only job
is to connect.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class PeerInfo:
    uav_id: str
    index: int
    position: tuple
    battery: float
    gcs_ok: bool
    eligible: bool
    age: float


def election_score(pos, battery: float, relay_point, gcs_range: float, rth_pct: float) -> float:
    d = math.dist(pos[:2], relay_point[:2])
    p = max(0.0, 1.0 - d / max(1.0, 2.0 * gcs_range))
    b = max(0.0, min(1.0, (battery - rth_pct) / max(1.0, 100.0 - rth_pct)))
    return 0.6 * p + 0.4 * b


def elect_bridge(me: PeerInfo, peers: list[PeerInfo], relay_point, gcs_range: float, rth_pct: float,
                 beacon_timeout: float = 3.0) -> str:
    cands = [me] + [p for p in peers if p.age <= beacon_timeout and not p.gcs_ok and p.eligible]
    if not me.eligible:
        cands = [p for p in cands if p.uav_id != me.uav_id] or [me]
    scored = sorted(cands, key=lambda p: (-round(election_score(p.position, p.battery, relay_point,
                                                                 gcs_range, rth_pct), 6), p.index))
    return scored[0].uav_id


def lost_link_action(*, is_relay: bool, me: PeerInfo, peers: list[PeerInfo], relay_point, gcs_range: float,
                     rth_pct: float, lost_for: float, rth_after: float, has_tasks: bool,
                     has_current: bool | None = None) -> tuple[str, str]:
    """Returns (action, explanation)."""
    if lost_for >= rth_after:
        return "RETURN", f"GCS link lost for {lost_for:.0f}s"
    if is_relay:
        return "RECONNECT", "relay lost GCS link: moving toward GCS"
    if any(p.gcs_ok and p.age <= 3.0 for p in peers):
        # a neighbour still reaches the GCS: routing should recover through it
        return ("CONTINUE", "neighbour has GCS contact") if has_tasks else ("RECONNECT", "moving toward connected neighbour")
    group = [p for p in peers if p.age <= 3.0]
    if not group:
        # alone: nobody to bridge for. Finish the tasks (reports wait in the outbox),
        # otherwise fly back into coverage.
        # alone and out of contact: finish only the survey in progress (its data goes into the
        # store-and-forward outbox), then fly back into coverage for new orders
        if has_current if has_current is not None else has_tasks:
            return "CONTINUE_CURRENT", "isolated: finishing the current survey, then reconnecting"
        return "RECONNECT", "isolated: moving back into coverage"
    winner = elect_bridge(me, peers, relay_point, gcs_range, rth_pct)
    if winner == me.uav_id and me.eligible:
        return "BRIDGE", f"elected as bridge among {1 + sum(1 for p in peers if p.age <= 3.0)} UAVs"
    if has_tasks:
        return "CONTINUE", f"{winner} is bridging; continuing tasks (store-and-forward)"
    return "RECONNECT", f"{winner} is bridging; moving toward relay point"
