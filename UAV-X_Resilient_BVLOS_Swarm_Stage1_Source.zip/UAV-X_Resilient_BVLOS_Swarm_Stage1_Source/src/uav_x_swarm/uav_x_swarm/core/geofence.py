"""Operational-area geofence (axis-aligned box in world ENU).

Three layers of protection:
1. Planning: PoIs / relay positions outside the fence are rejected or clamped.
2. Onboard: every setpoint is clamped `clamp_margin_m` inside the fence, so the
   controller can never command a position outside it.
3. Monitoring: the GCS reports WARNING when a UAV is within `warning_margin_m`
   of the boundary and BREACH (a violation) if it is ever outside; a breach
   triggers return-to-home.
The ground (z_min) is not treated as a fence face; only x, y and z_max are.
"""
from __future__ import annotations

from dataclasses import dataclass

INSIDE, WARNING, BREACH = "INSIDE", "WARNING", "BREACH"


@dataclass
class Geofence:
    x: tuple[float, float]
    y: tuple[float, float]
    z: tuple[float, float]
    warning_margin: float = 15.0
    clamp_margin: float = 5.0

    @classmethod
    def from_cfg(cls, gf: dict) -> "Geofence":
        return cls(tuple(gf["x"]), tuple(gf["y"]), tuple(gf["z"]),
                   float(gf.get("warning_margin_m", 15.0)), float(gf.get("clamp_margin_m", 5.0)))

    def margin(self, p) -> float:
        """Signed distance to the nearest fence face (negative = outside)."""
        dx = min(p[0] - self.x[0], self.x[1] - p[0])
        dy = min(p[1] - self.y[0], self.y[1] - p[1])
        dz = self.z[1] - (p[2] if len(p) > 2 else 0.0)
        return min(dx, dy, dz)

    def contains(self, p, margin: float = 0.0) -> bool:
        return self.margin(p) >= margin

    def status(self, p) -> str:
        m = self.margin(p)
        if m < 0:
            return BREACH
        if m < self.warning_margin:
            return WARNING
        return INSIDE

    def clamp(self, p, margin: float | None = None):
        m = self.clamp_margin if margin is None else margin
        x = min(max(p[0], self.x[0] + m), self.x[1] - m)
        y = min(max(p[1], self.y[0] + m), self.y[1] - m)
        if len(p) > 2:
            z = min(p[2], self.z[1] - m)
            return (x, y, z)
        return (x, y)
