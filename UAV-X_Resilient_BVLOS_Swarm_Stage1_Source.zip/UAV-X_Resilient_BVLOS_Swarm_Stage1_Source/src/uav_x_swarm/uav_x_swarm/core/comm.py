"""Link-quality estimation and end-to-end communication health monitoring.

* :class:`LinkEstimator` models the routing layer's view of each link: every
  hello interval one hello is "sent" and succeeds with the *true* per-hop
  delivery probability; the estimate is an EWMA of successes (0..1). A link
  that goes out of range or is jammed therefore degrades in the routing table
  only as fast as hellos are lost, just like a real mesh protocol.
* :class:`PdrMonitor` runs at the GCS. It counts telemetry packets actually
  received from each UAV in a sliding window and compares with the known send
  rate, giving a measured end-to-end packet delivery ratio (PDR) and latency.
* :func:`classify_link` maps PDR/latency to GOOD / WARNING / DEGRADED / FAILED.
"""
from __future__ import annotations

import random
from collections import deque

from .types import LinkStatus


_SEVERITY = {LinkStatus.GOOD: 0, LinkStatus.WARNING: 1, LinkStatus.DEGRADED: 2,
             LinkStatus.FAILED: 3, LinkStatus.DISCONNECTED: 4}


def severity(status: LinkStatus) -> int:
    return _SEVERITY[status]


class LinkEstimator:
    def __init__(self, alpha: float = 0.12, rng: random.Random | None = None):
        self.alpha = alpha
        self.rng = rng or random.Random(0)
        self.est: dict[tuple[str, str], float] = {}

    def update(self, key: tuple[str, str], true_quality: float, available: bool) -> float:
        success = 1.0 if (available and self.rng.random() < true_quality) else 0.0
        prev = self.est.get(key, 0.0)
        val = (1.0 - self.alpha) * prev + self.alpha * success
        self.est[key] = val
        return val

    def get(self, key: tuple[str, str]) -> float:
        return self.est.get(key, 0.0)


def classify_link(pdr: float, latency_ms: float, th: dict, received_any: bool = True,
                  previous: LinkStatus | None = None) -> LinkStatus:
    """Classify an end-to-end link. With `previous` given, an improvement is only
    accepted if PDR clears the better class's threshold by `recovery_margin` (hysteresis)."""
    raw = _classify(pdr, latency_ms, th, received_any)
    if previous is None or not received_any or severity(raw) >= severity(previous):
        return raw
    margin = float(th.get("recovery_margin", 0.0))
    boosted = _classify(max(0.0, pdr - margin), latency_ms, th, received_any)
    return boosted if severity(boosted) < severity(previous) else previous


def _classify(pdr: float, latency_ms: float, th: dict, received_any: bool) -> LinkStatus:
    if not received_any:
        return LinkStatus.DISCONNECTED
    if pdr < th["failed_pdr"]:
        return LinkStatus.FAILED
    if pdr < th["degraded_pdr"] or latency_ms > th["degraded_latency_ms"]:
        return LinkStatus.DEGRADED
    if pdr < th["warning_pdr"] or latency_ms > th["warning_latency_ms"]:
        return LinkStatus.WARNING
    return LinkStatus.GOOD


class PdrMonitor:
    """Sliding-window end-to-end PDR/latency per source, measured at the receiver."""

    def __init__(self, window_s: float, expected_rate_hz: float):
        self.window = window_s
        self.rate = expected_rate_hz
        self.rx: dict[str, deque] = {}
        self.started: dict[str, float] = {}

    def record(self, src: str, t_rx: float, latency_ms: float) -> None:
        q = self.rx.setdefault(src, deque())
        q.append((t_rx, latency_ms))
        self.started.setdefault(src, t_rx)

    def reset(self, src: str, now: float) -> None:
        """Forget history (e.g. after a reconnection): the outage must not be counted
        against the freshly restored link."""
        self.rx[src] = deque()
        self.started[src] = now

    def stats(self, src: str, now: float) -> tuple[float, float, int]:
        """Returns (pdr, mean_latency_ms, received_count) over the window."""
        q = self.rx.get(src)
        if q is None:
            return 0.0, 0.0, 0
        while q and q[0][0] < now - self.window:
            q.popleft()
        n = len(q)
        # Do not over-penalise a source we have only just started hearing from.
        span = min(self.window, max(1e-6, now - self.started.get(src, now)))
        expected = max(1.0, self.rate * span)
        pdr = min(1.0, n / expected)
        lat = sum(l for _, l in q) / n if n else 0.0
        return pdr, lat, n
