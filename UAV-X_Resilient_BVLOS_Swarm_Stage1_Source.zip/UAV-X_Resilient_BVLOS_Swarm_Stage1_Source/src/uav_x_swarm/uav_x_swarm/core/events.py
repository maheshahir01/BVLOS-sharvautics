"""Structured event records and their human-readable console format."""
from __future__ import annotations

import json

CATEGORY = {
    "MISSION": "MISSION", "PHASE": "MISSION", "TASK": "MISSION", "SURVEY": "MISSION", "POI": "MISSION",
    "NEW_PRIORITY_POI": "MISSION", "REPORT": "MISSION",
    "NETWORK": "NETWORK", "ROUTE": "NETWORK", "LINK": "NETWORK", "PARTITION": "NETWORK",
    "HEARTBEAT": "FAILURE", "UAV_FAILED": "FAILURE", "FAILURE": "FAILURE", "RECONNECTED": "FAILURE",
    "RELAY": "SWARM", "ROLE": "SWARM", "SWARM": "SWARM", "RECONFIG": "SWARM",
    "BATTERY": "BATTERY", "RTH": "BATTERY",
    "SEPARATION": "SAFETY", "COLLISION": "SAFETY", "AVOIDANCE": "SAFETY",
    "GEOFENCE": "GEOFENCE",
    "SCENARIO": "SCENARIO", "INJECT": "SCENARIO",
    "LOST_LINK": "NETWORK", "PEER": "SWARM", "LANDED": "MISSION", "LANDING": "MISSION", "TAKEOFF": "MISSION",
    "SOFTWARE_ERROR": "ERROR", "ALL_POIS": "MISSION", "AIRBORNE": "UAV", "UAV_READY": "UAV", "PARTITION": "NETWORK",
}

COLORS = {"MISSION": "\033[1;32m", "NETWORK": "\033[1;36m", "FAILURE": "\033[1;31m",
          "SWARM": "\033[1;35m", "BATTERY": "\033[1;33m", "SAFETY": "\033[1;91m",
          "GEOFENCE": "\033[1;93m", "ERROR": "\033[1;41m", "SCENARIO": "\033[1;34m", "UAV": "\033[0;37m"}
RESET = "\033[0m"


def category(event_type: str) -> str:
    for prefix, cat in CATEGORY.items():
        if event_type.startswith(prefix):
            return cat
    return "UAV"


def make_event(t: float, event_type: str, message: str, uav_id: str | None = None,
               source: str = "", mission_time: float | None = None, details: dict | None = None) -> dict:
    details = dict(details or {})
    return {"t": round(t, 3), "mission_time": None if mission_time is None else round(mission_time, 2),
            "event_type": event_type, "category": category(event_type), "uav_id": uav_id,
            "message": message, "source": source, "details": details}


def to_json(ev: dict) -> str:
    return json.dumps(ev, default=str)


def format_event(ev: dict, color: bool = True) -> str:
    cat = ev.get("category") or category(ev.get("event_type", ""))
    mt = ev.get("mission_time")
    ts = f"{mt:7.1f}s" if isinstance(mt, (int, float)) else "   --   "
    tag = f"[{cat}]"
    if color:
        tag = f"{COLORS.get(cat, '')}{tag}{RESET}"
    return f"[{ts}] {tag} {ev.get('message', '')}"
