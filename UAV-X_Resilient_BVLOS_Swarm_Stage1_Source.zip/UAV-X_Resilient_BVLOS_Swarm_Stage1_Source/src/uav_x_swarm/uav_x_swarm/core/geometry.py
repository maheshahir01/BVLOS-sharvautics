"""Small vector helpers (tuples, no numpy needed)."""
from __future__ import annotations

import math

Vec3 = tuple[float, float, float]


def dist(a, b) -> float:
    return math.dist(a, b)


def dist2d(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def sub(a, b) -> Vec3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def add(a, b) -> Vec3:
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def scale(a, k: float) -> Vec3:
    return (a[0] * k, a[1] * k, a[2] * k)


def norm(a) -> float:
    return math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])


def unit(a) -> Vec3:
    n = norm(a)
    return (0.0, 0.0, 0.0) if n < 1e-9 else (a[0] / n, a[1] / n, a[2] / n)


def clamp_norm(a, max_norm: float) -> Vec3:
    n = norm(a)
    return a if n <= max_norm or n < 1e-9 else scale(a, max_norm / n)


def clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else hi if v > hi else v


def lerp(a, b, t: float) -> Vec3:
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)
