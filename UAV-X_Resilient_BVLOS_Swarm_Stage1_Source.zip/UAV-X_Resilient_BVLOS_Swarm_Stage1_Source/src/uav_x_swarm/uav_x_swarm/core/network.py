"""Communication link model and network graph with multi-hop routing.

Link model (per hop, documented in docs/ARCHITECTURE.md):

* A link exists only if both radios are up and the 3-D distance d <= R, where
  R = gcs_range_m for GCS<->UAV links and uav_range_m for UAV<->UAV links.
* Per-hop packet loss grows with distance:
      loss(d) = base + edge * ramp(d),
      ramp(d) = 0                          if d <= g*R
              = ((d - g*R) / (R - g*R))^2   otherwise
  where g = good_range_fraction. Injected impairments (scenario events) combine
  as independent loss processes: 1 - (1-loss)(1-inj_a)(1-inj_b).
* Per-hop latency = base_latency + processing + injected latency (+ jitter,
  drawn per packet by the emulator).
* Link quality q = 1 - loss = per-hop delivery probability.

Routing uses the ETX metric (expected transmission count, 1/q) on *estimated*
link qualities, like a proactive link-state mesh protocol (OLSR/Babel). Packets
then experience the *true* per-hop loss, so estimator lag has real consequences.
"""
from __future__ import annotations

import heapq
import math
from dataclasses import asdict, dataclass

GCS = "gcs"


@dataclass
class LinkState:
    a: str
    b: str
    kind: str                 # "GCS" or "UAV"
    distance: float
    range_m: float
    available: bool           # physically usable right now
    loss: float               # true per-hop loss probability
    latency_ms: float         # mean per-hop latency
    quality: float            # true delivery probability (0 if unavailable)
    est_quality: float = 0.0  # routing-layer estimate (EWMA of hello receptions)

    def to_dict(self) -> dict:
        d = asdict(self)
        for k in ("distance", "loss", "latency_ms", "quality", "est_quality"):
            d[k] = round(d[k], 4)
        return d


def link_key(a: str, b: str) -> tuple[str, str]:
    return (a, b) if a < b else (b, a)


class LinkModel:
    def __init__(self, comm_cfg: dict):
        self.gcs_range = float(comm_cfg["gcs_range_m"])
        self.uav_range = float(comm_cfg["uav_range_m"])
        self.good_frac = float(comm_cfg.get("good_range_fraction", 0.55))
        self.base_loss = float(comm_cfg.get("base_packet_loss", 0.01))
        self.edge_loss = float(comm_cfg.get("edge_packet_loss", 0.30))
        self.base_latency = float(comm_cfg.get("base_latency_ms", 6.0))
        self.proc_latency = float(comm_cfg.get("per_hop_processing_ms", 4.0))

    def range_for(self, a: str, b: str) -> float:
        return self.gcs_range if GCS in (a, b) else self.uav_range

    def distance_loss(self, d: float, rng: float) -> float:
        g = self.good_frac * rng
        if d <= g:
            ramp = 0.0
        else:
            ramp = min(1.0, (d - g) / max(1e-6, rng - g)) ** 2
        return min(1.0, self.base_loss + self.edge_loss * ramp)

    def evaluate(self, a: str, b: str, pa, pb, *, radio_a: bool = True, radio_b: bool = True,
                 inj_loss_a: float = 0.0, inj_loss_b: float = 0.0,
                 inj_lat_a: float = 0.0, inj_lat_b: float = 0.0) -> LinkState:
        d = math.dist(pa, pb)
        rng = self.range_for(a, b)
        kind = "GCS" if GCS in (a, b) else "UAV"
        latency = self.base_latency + self.proc_latency + inj_lat_a + inj_lat_b
        if not (radio_a and radio_b) or d > rng:
            return LinkState(a, b, kind, d, rng, False, 1.0, latency, 0.0)
        loss = 1.0 - (1.0 - self.distance_loss(d, rng)) * (1.0 - inj_loss_a) * (1.0 - inj_loss_b)
        loss = min(1.0, max(0.0, loss))
        available = loss < 1.0
        return LinkState(a, b, kind, d, rng, available, loss, latency, 1.0 - loss if available else 0.0)


class NetworkGraph:
    """Undirected graph of links. Nodes: 'gcs' and UAV ids."""

    def __init__(self, nodes: list[str] | None = None):
        self.nodes: list[str] = list(nodes or [])
        self.links: dict[tuple[str, str], LinkState] = {}

    def set_link(self, link: LinkState) -> None:
        self.links[link_key(link.a, link.b)] = link
        for n in (link.a, link.b):
            if n not in self.nodes:
                self.nodes.append(n)

    def link(self, a: str, b: str) -> LinkState | None:
        return self.links.get(link_key(a, b))

    def _q(self, l: LinkState, use_estimate: bool) -> float:
        return l.est_quality if use_estimate else (l.quality if l.available else 0.0)

    def neighbors(self, n: str, *, use_estimate: bool = True, min_quality: float = 0.25,
                  exclude: set | None = None) -> list[tuple[str, LinkState]]:
        out = []
        for (a, b), l in self.links.items():
            if n not in (a, b):
                continue
            other = b if a == n else a
            if exclude and other in exclude:
                continue
            if self._q(l, use_estimate) >= min_quality:
                out.append((other, l))
        return out

    def shortest_path(self, src: str, dst: str, *, use_estimate: bool = True, min_quality: float = 0.25,
                      exclude: set | None = None) -> tuple[list[str], float] | tuple[None, float]:
        """Dijkstra with ETX cost (1/q per hop). Returns (path, total_etx) or (None, inf)."""
        if src == dst:
            return [src], 0.0
        dist = {src: 0.0}
        prev: dict[str, str] = {}
        heap = [(0.0, src)]
        done = set()
        while heap:
            c, u = heapq.heappop(heap)
            if u in done:
                continue
            done.add(u)
            if u == dst:
                break
            for v, l in self.neighbors(u, use_estimate=use_estimate, min_quality=min_quality, exclude=exclude):
                if v in done:
                    continue
                # Only the GCS and UAVs may forward; the destination may be anything.
                nc = c + 1.0 / max(self._q(l, use_estimate), 1e-6)
                if nc < dist.get(v, math.inf):
                    dist[v] = nc
                    prev[v] = u
                    heapq.heappush(heap, (nc, v))
        if dst not in dist:
            return None, math.inf
        path = [dst]
        while path[-1] != src:
            path.append(prev[path[-1]])
        return list(reversed(path)), dist[dst]

    def path_quality(self, path: list[str], *, use_estimate: bool = False) -> float:
        q = 1.0
        for a, b in zip(path, path[1:]):
            l = self.link(a, b)
            if l is None:
                return 0.0
            q *= self._q(l, use_estimate)
        return q

    def path_latency(self, path: list[str]) -> float:
        total = 0.0
        for a, b in zip(path, path[1:]):
            l = self.link(a, b)
            total += l.latency_ms if l else math.inf
        return total

    def reachable_from(self, src: str, *, use_estimate: bool = True, min_quality: float = 0.25,
                       exclude: set | None = None) -> set[str]:
        seen, stack = {src}, [src]
        while stack:
            u = stack.pop()
            for v, _ in self.neighbors(u, use_estimate=use_estimate, min_quality=min_quality, exclude=exclude):
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        return seen

    def cut_vertices_for(self, root: str = GCS, *, use_estimate: bool = True,
                         min_quality: float = 0.25) -> dict[str, list[str]]:
        """For each node X (not root): the nodes that lose connectivity to `root` if X disappears.

        Used to identify relay UAVs (non-empty list = X is a relay for those UAVs)."""
        base = self.reachable_from(root, use_estimate=use_estimate, min_quality=min_quality)
        out = {}
        for x in self.nodes:
            if x == root or x not in base:
                continue
            after = self.reachable_from(root, use_estimate=use_estimate, min_quality=min_quality, exclude={x})
            lost = sorted(base - after - {x})
            if lost:
                out[x] = lost
        return out

    def to_dict(self) -> dict:
        return {"nodes": list(self.nodes), "links": [l.to_dict() for l in self.links.values()]}
