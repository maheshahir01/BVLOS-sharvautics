"""Dynamic relay selection and relay placement.

Relay suitability score (all inputs normalised to [0, 1], weights in config):

    score =  w_lq * link_quality      (measured end-to-end route quality to the GCS)
           + w_b  * battery           ((battery - rth) / (100 - rth))
           + w_c  * connectivity      (UAV neighbours currently heard / (N - 1))
           + w_p  * position          (1 - distance_to_relay_point / normaliser)
           - w_l  * latency           (mean latency / degraded-latency threshold)
           - w_m  * mission_load      (queued + active survey tasks / max_queue)

Eligibility: not FAILED/LOST, reachable (link not FAILED/DISCONNECTED), battery
>= relay.min_battery_pct, not returning home or landing.

Hysteresis: a healthy, eligible current relay is replaced only if another UAV beats
it by `switch_margin`. An ineligible relay is replaced immediately, and the
decision records the reason (FAILED, LOST, LOW_BATTERY, LINK_DEGRADED, RTH, ...).

Placement: grid search over positions within `gcs_range_margin * gcs_range` of
the GCS (and inside the geofence). Candidates are ranked lexicographically by
(1) survey positions (current positions + current targets) covered directly by
the relay or the GCS, (2) survey positions connected through any multi-hop path,
(3) lowest total ETX, (4) distance to the current relay position (stability).
All four use the link model with planning margins.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from .comm import severity
from .geofence import Geofence
from .network import GCS, LinkModel, NetworkGraph
from .types import FlightState, Health, LinkStatus, Role, UAVView

_NOT_ELIGIBLE_STATES = {FlightState.RETURN_HOME, FlightState.LANDING, FlightState.LANDED,
                        FlightState.FAILED, FlightState.BOOT}


@dataclass
class RelayDecision:
    old_relay: str | None
    new_relay: str | None
    reason: str
    scores: dict = field(default_factory=dict)
    changed: bool = False


class RelayManager:
    def __init__(self, cfg, link_model: LinkModel, geofence: Geofence):
        self.w = dict(cfg["relay.weights"])
        self.margin = float(cfg["relay.switch_margin"])
        self.min_batt = float(cfg["relay.min_battery_pct"])
        self.rth_pct = float(cfg["battery.rth_pct"])
        pl = cfg["relay.placement"]
        self.grid = float(pl["grid_step_m"])
        self.gcs_margin = float(pl["gcs_range_margin"])
        self.uav_margin = float(pl["uav_range_margin"])
        self.repos_thresh = float(pl["reposition_threshold_m"])
        self.required_beyond = float(cfg["relay.required_when_beyond_m"])
        self.max_queue = int(cfg["mission.allocation.max_queue"])
        self.lat_norm = float(cfg["communication.thresholds.degraded_latency_ms"])
        self.lm = link_model
        self.fence = geofence
        self.n_uavs = cfg.num_uavs

    # ----------------------------------------------------------- eligibility / score
    def eligibility(self, u: UAVView) -> tuple[bool, str]:
        if u.health in (Health.FAILED, Health.LOST):
            return False, u.health.value
        if u.role == Role.RETURN_HOME or u.flight_state == FlightState.RETURN_HOME:
            return False, "RTH"
        if u.flight_state in _NOT_ELIGIBLE_STATES:
            return False, u.flight_state.value
        # Degraded measured links do not disqualify a candidate (every UAV routed through
        # a failing relay measures poor PDR); the score penalises them instead. Only a UAV
        # we cannot hear at all is excluded.
        if u.link_status == LinkStatus.DISCONNECTED:
            return False, "LINK_DISCONNECTED"
        if u.battery < self.min_batt:
            return False, "LOW_BATTERY"
        return True, "OK"

    def score(self, u: UAVView, relay_point, gcs_pos) -> tuple[float, dict]:
        lq = max(0.0, min(1.0, u.link_quality))
        batt = max(0.0, min(1.0, (u.battery - self.rth_pct) / max(1.0, 100.0 - self.rth_pct)))
        conn = min(1.0, len(u.neighbors) / max(1, self.n_uavs - 1))
        normaliser = max(50.0, 2.0 * self.lm.gcs_range)
        d = math.dist(u.position[:2], relay_point[:2])
        pos = max(0.0, 1.0 - d / normaliser)
        lat = max(0.0, min(1.0, u.latency_ms / self.lat_norm))
        load_n = len(u.task_queue) + (1 if u.current_task else 0)
        load = max(0.0, min(1.0, load_n / max(1, self.max_queue)))
        w = self.w
        s = (w["link_quality"] * lq + w["battery"] * batt + w["connectivity"] * conn
             + w["position"] * pos - w["latency"] * lat - w["mission_load"] * load)
        return s, {"link_quality": round(lq, 3), "battery": round(batt, 3), "connectivity": round(conn, 3),
                   "position": round(pos, 3), "latency": round(lat, 3), "mission_load": round(load, 3),
                   "score": round(s, 4)}

    # ----------------------------------------------------------- need / placement
    def relay_needed(self, targets: list[tuple], gcs_pos) -> bool:
        return any(math.dist(t[:2], gcs_pos[:2]) > self.required_beyond for t in targets)

    def _planning_model(self) -> LinkModel:
        return LinkModel({"gcs_range_m": self.lm.gcs_range * self.gcs_margin,
                          "uav_range_m": self.lm.uav_range * self.uav_margin,
                          "good_range_fraction": self.lm.good_frac,
                          "base_packet_loss": self.lm.base_loss, "edge_packet_loss": self.lm.edge_loss})

    def objective(self, c, gcs_pos, pts: list, planning: LinkModel | None = None) -> tuple:
        """Objective key for a relay at c (lower is better): (-direct, -connected, total ETX)."""
        planning = planning or self._planning_model()
        g = NetworkGraph()
        nodes = [(GCS, tuple(gcs_pos)), ("relay", tuple(c))] + pts
        for a in range(len(nodes)):
            for b in range(a + 1, len(nodes)):
                na, pa = nodes[a]
                nb, pb = nodes[b]
                l = planning.evaluate(na, nb, pa, pb)
                l.est_quality = l.quality
                g.set_link(l)
        reach = g.reachable_from(GCS, use_estimate=True, min_quality=0.05)
        connected = sum(1 for n, _ in pts if n in reach)
        direct = sum(1 for n, _ in pts if (g.link("relay", n) and g.link("relay", n).available)
                     or (g.link(GCS, n) and g.link(GCS, n).available))
        etx = 0.0
        for n, _ in pts:
            if n in reach:
                _, cost = g.shortest_path(n, GCS, use_estimate=True, min_quality=0.05)
                etx += cost
        # direct (one-hop) coverage first: it does not depend on other UAVs being in place
        return (-direct, -connected, round(etx, 2))

    def _points(self, survey_points: list, altitude: float) -> list:
        return [(f"s{i}", (p[0], p[1], p[2] if len(p) > 2 else altitude)) for i, p in enumerate(survey_points)]

    def placement(self, gcs_pos, survey_points: list[tuple], altitude: float, current=None) -> tuple[float, float, float]:
        """Grid-search the relay position that best connects the survey points to the GCS."""
        rmax = self.lm.gcs_range * self.gcs_margin
        if not survey_points:
            return (gcs_pos[0] + 0.5 * rmax, gcs_pos[1], altitude)
        planning = self._planning_model()
        pts = self._points(survey_points, altitude)
        best, best_key = None, None
        steps = int(rmax // self.grid)
        gx, gy = gcs_pos[0], gcs_pos[1]
        for i in range(-steps, steps + 1):
            for j in range(-steps, steps + 1):
                cx, cy = gx + i * self.grid, gy + j * self.grid
                if math.hypot(cx - gx, cy - gy) > rmax or not self.fence.contains((cx, cy, altitude), 10.0):
                    continue
                stab = math.dist((cx, cy), current[:2]) if current else 0.0
                key = self.objective((cx, cy, altitude), gcs_pos, pts, planning) + (stab,)
                if best_key is None or key < best_key:
                    best_key, best = key, (cx, cy, altitude)
        return best

    def should_reposition(self, current, proposed, gcs_pos=None, survey_points=None, altitude: float = 25.0) -> bool:
        """Move the relay only if the new position is far enough away AND clearly better:
        more UAVs covered directly or through multi-hop, or >= 25 % lower total ETX."""
        if current is None:
            return True
        if math.dist(current[:2], proposed[:2]) < self.repos_thresh:
            return False
        if gcs_pos is None or not survey_points:
            return True
        pts = self._points(survey_points, altitude)
        kc = self.objective(current, gcs_pos, pts)
        kp = self.objective(proposed, gcs_pos, pts)
        if kp[:2] != kc[:2]:
            return kp[:2] < kc[:2]
        return kp[2] < 0.75 * kc[2]

    # ----------------------------------------------------------- selection
    def select(self, uavs: dict[str, UAVView], current: str | None, relay_point, gcs_pos,
               force_reason: str | None = None, link_grace: bool = False) -> RelayDecision:
        """`link_grace`: the current relay was assigned moments ago; its measured link
        quality is not yet meaningful, so it is not invalidated for a degraded link."""
        scores, eligible = {}, {}
        for uid, u in uavs.items():
            ok, why = self.eligibility(u)
            s, comp = self.score(u, relay_point, gcs_pos)
            comp["eligible"] = ok
            comp["why"] = why
            scores[uid] = comp
            if ok:
                eligible[uid] = s
        cur_ok = current is not None and current in eligible and force_reason is None
        cur_reason = None
        if current is not None and not cur_ok:
            cur_reason = force_reason or scores.get(current, {}).get("why", "UNAVAILABLE")
        if current is not None and cur_ok and not link_grace:
            u = uavs[current]
            if severity(u.link_status) >= severity(LinkStatus.DEGRADED):
                cur_ok, cur_reason = False, "LINK_" + u.link_status.value
        if not cur_ok and current in eligible and len(eligible) > 1:
            eligible.pop(current)          # an invalidated relay cannot replace itself
        if not eligible:
            return RelayDecision(current, None if not cur_ok else current,
                                 "NO_ELIGIBLE_UAV" if not cur_ok else "KEEP", scores,
                                 changed=not cur_ok and current is not None)
        # deterministic: highest score, then lowest id
        best = sorted(eligible.items(), key=lambda kv: (-round(kv[1], 6), kv[0]))[0][0]
        if cur_ok:
            if link_grace:
                return RelayDecision(current, current, "KEEP (new relay grace period)", scores, changed=False)
            if best != current and eligible[best] > eligible[current] + self.margin:
                return RelayDecision(current, best, f"BETTER_CANDIDATE(+{eligible[best] - eligible[current]:.2f})",
                                     scores, changed=True)
            return RelayDecision(current, current, "KEEP", scores, changed=False)
        reason = cur_reason or "INITIAL_SELECTION"
        return RelayDecision(current, best, reason, scores, changed=(best != current))
