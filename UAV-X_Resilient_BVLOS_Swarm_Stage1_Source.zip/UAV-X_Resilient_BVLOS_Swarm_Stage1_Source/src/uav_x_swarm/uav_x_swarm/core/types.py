"""Shared enumerations and data records used across the swarm software."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum


class Role(str, Enum):
    IDLE = "IDLE"
    SURVEY = "SURVEY"
    RELAY = "RELAY"
    SURVEY_RELAY = "SURVEY_RELAY"   # surveying while forwarding traffic for other UAVs
    RETURN_HOME = "RETURN_HOME"
    EMERGENCY = "EMERGENCY"
    FAILED = "FAILED"


class Health(str, Enum):
    OK = "OK"
    WARNING = "WARNING"            # e.g. battery warning, degraded link
    LOST = "LOST"                  # heartbeat missing, failure suspected
    FAILED = "FAILED"              # confirmed failure


class LinkStatus(str, Enum):
    GOOD = "GOOD"
    WARNING = "WARNING"
    DEGRADED = "DEGRADED"
    FAILED = "FAILED"
    DISCONNECTED = "DISCONNECTED"


class FlightState(str, Enum):
    """Onboard (UAV agent) flight state machine."""
    BOOT = "BOOT"
    READY = "READY"                # on ground, armed-able
    ARMING = "ARMING"
    TAKEOFF = "TAKEOFF"
    HOLD = "HOLD"                  # airborne, no goal
    TRANSIT = "TRANSIT"            # flying to a goal
    SURVEY = "SURVEY"              # flying the survey pattern around a PoI
    RELAY_STATION = "RELAY_STATION"  # holding the relay position
    RETURN_HOME = "RETURN_HOME"
    LANDING = "LANDING"
    LANDED = "LANDED"
    FAILED = "FAILED"


class TaskStatus(str, Enum):
    PENDING = "PENDING"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    SURVEYED = "SURVEYED"          # data collected onboard, report not yet at GCS
    COMPLETED = "COMPLETED"        # report received by GCS
    REJECTED = "REJECTED"          # e.g. outside geofence


class MissionPhase(str, Enum):
    INITIALIZING = "INITIALIZING"
    TAKEOFF = "TAKEOFF"
    FORMATION = "FORMATION"
    DEPLOY = "DEPLOY"
    SURVEY = "SURVEY"
    RECONFIGURING = "RECONFIGURING"
    EMERGENCY = "EMERGENCY"
    RETURN_HOME = "RETURN_HOME"
    LAND = "LAND"
    MISSION_COMPLETE = "MISSION_COMPLETE"
    MISSION_FAILED = "MISSION_FAILED"


PRIORITY_ORDER = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]


@dataclass
class PoI:
    id: str
    name: str
    position: tuple[float, float]
    priority: str = "MEDIUM"
    initial: bool = True
    status: TaskStatus = TaskStatus.PENDING
    assigned_to: str | None = None
    announced_at: float | None = None
    completed_at: float | None = None
    completed_by: str | None = None
    attempts: int = 0

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "PoI":
        d = dict(d)
        d["position"] = tuple(d["position"][:2])
        d["status"] = TaskStatus(d.get("status", "PENDING"))
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


@dataclass
class UAVView:
    """What the GCS-side swarm manager believes about one UAV (from received telemetry)."""
    uav_id: str
    home: tuple[float, float]
    position: tuple[float, float, float] = (0.0, 0.0, 0.0)
    velocity: tuple[float, float, float] = (0.0, 0.0, 0.0)
    battery: float = 100.0
    role: Role = Role.IDLE
    flight_state: FlightState = FlightState.BOOT
    health: Health = Health.OK
    link_status: LinkStatus = LinkStatus.DISCONNECTED
    link_quality: float = 0.0          # estimated end-to-end route delivery probability
    packet_loss: float = 1.0           # measured over the PDR window
    latency_ms: float = 0.0
    hops: int = 0
    route: list = field(default_factory=list)
    last_heartbeat: float | None = None
    first_seen: float | None = None
    current_task: str | None = None
    task_queue: list = field(default_factory=list)
    geofence_status: str = "INSIDE"
    airborne: bool = False
    rth_reason: str | None = None
    neighbors: dict = field(default_factory=dict)
    lost_since: float | None = None
    telemetry_seq: int = -1
    drain_factor: float = 1.0          # GCS estimate of actual / modelled battery drain
    coverage_margin: float = 1.0       # 1 - (distance to best link partner / its range); < 0.2 = at the edge

    def to_dict(self) -> dict:
        d = asdict(self)
        for k in ("role", "flight_state", "health", "link_status"):
            d[k] = getattr(self, k).value
        return d
