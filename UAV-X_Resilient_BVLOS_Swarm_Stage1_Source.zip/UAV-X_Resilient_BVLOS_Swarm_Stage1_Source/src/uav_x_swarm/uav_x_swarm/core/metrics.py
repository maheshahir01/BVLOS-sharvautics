"""Performance metrics (rulebook categories) computed from recorded simulation data.

Every number comes from recorded state: emulator packet counters, routing tables,
onboard vehicle states, and the event stream. See docs/METRICS.md for definitions.
"""
from __future__ import annotations

import math
from collections import defaultdict

from .collision import SeparationMonitor
from .geofence import BREACH, WARNING, Geofence

UNICAST_TYPES = ("TELEMETRY", "REPORT", "ACK", "CMD", "GCS_HB")


class MetricsAccumulator:
    def __init__(self, cfg, uav_ids: list[str], geofence: Geofence, priority_weights: dict):
        self.uav_ids = uav_ids
        self.fence = geofence
        self.weights = {k.upper(): float(v) for k, v in priority_weights.items()}
        self.sep = SeparationMonitor(float(cfg["safety.minimum_safe_distance_m"]),
                                     float(cfg["safety.collision_distance_m"]))
        self.events: list[dict] = []
        self.truth: dict[str, dict] = {}
        self.net: dict = {}
        self.status: dict = {}
        self.t_first = None
        self.t_last_sample = None
        self.mission_start = None
        self.mission_end = None
        self.all_pois_done_at = None
        self.final_phase = None
        # connectivity integration
        self.active_time = defaultdict(float)
        self.connected_time = defaultdict(float)
        self.outage_time = defaultdict(float)
        self._outage_start: dict[str, float | None] = {}
        self.longest_outage = defaultdict(float)
        # safety / battery
        self.geofence_state: dict[str, str] = {}
        self.geofence_warnings = 0
        self.geofence_violations = 0
        self.min_battery: dict[str, float] = {}
        self.depleted: set[str] = set()
        self.avoidance_events = 0
        # episodes
        self.injections: list[dict] = []

    # ------------------------------------------------------------------ inputs
    def on_event(self, ev: dict) -> None:
        self.events.append(ev)
        et = ev.get("event_type", "")
        t = ev.get("t", 0.0)
        if et == "MISSION_START":
            self.mission_start = t
        elif et in ("MISSION_COMPLETE", "MISSION_FAILED"):
            self.mission_end = t
            self.final_phase = et
        elif et == "ALL_POIS_COMPLETED" and self.all_pois_done_at is None:
            self.all_pois_done_at = t
        elif et == "AVOIDANCE_ACTIVE":
            self.avoidance_events += 1
        elif et == "SCENARIO_INJECT":
            d = ev.get("details", {})
            self.injections.append({"id": d.get("event_id"), "type": d.get("inject_type"),
                                    "targets": d.get("targets", []), "t": t, "mission_time": ev.get("mission_time")})

    def on_uav_state(self, uid: str, state: dict) -> None:
        self.truth[uid] = state
        b = state.get("battery")
        if b is not None:
            self.min_battery[uid] = min(self.min_battery.get(uid, 100.0), float(b))
            if float(b) <= 0.0:
                self.depleted.add(uid)

    def on_network(self, net: dict) -> None:
        self.net = net

    def on_status(self, status: dict) -> None:
        self.status = status

    def sample(self, t: float) -> dict:
        """Called periodically; integrates availability and checks separation/geofence."""
        if self.t_first is None:
            self.t_first = t
        dt = 0.0 if self.t_last_sample is None else max(0.0, t - self.t_last_sample)
        self.t_last_sample = t
        routes = (self.net or {}).get("routes", {})
        airborne = {}
        conn_row = {}
        for uid in self.uav_ids:
            s = self.truth.get(uid)
            if not s:
                continue
            active = bool(s.get("airborne")) and s.get("flight_state") != "FAILED" and self.mission_start is not None
            connected = bool(routes.get(uid, {}).get("connected"))
            conn_row[uid] = (active, connected)
            if s.get("airborne") and s.get("flight_state") != "FAILED":
                airborne[uid] = tuple(s["position"])
            if active:
                self.active_time[uid] += dt
                if connected:
                    self.connected_time[uid] += dt
                    if self._outage_start.get(uid) is not None:
                        self.longest_outage[uid] = max(self.longest_outage[uid], t - self._outage_start[uid])
                        self._outage_start[uid] = None
                else:
                    self.outage_time[uid] += dt
                    if self._outage_start.get(uid) is None:
                        self._outage_start[uid] = t
            elif self._outage_start.get(uid) is not None:
                self.longest_outage[uid] = max(self.longest_outage[uid], t - self._outage_start[uid])
                self._outage_start[uid] = None
            # geofence (all airborne UAVs, including failed ones still in the air)
            if s.get("airborne"):
                st = self.fence.status(tuple(s["position"]))
                prev = self.geofence_state.get(uid, "INSIDE")
                if st != prev:
                    if st == WARNING and prev == "INSIDE":
                        self.geofence_warnings += 1
                    if st == BREACH:
                        self.geofence_violations += 1
                self.geofence_state[uid] = st
        sep_events = self.sep.update(airborne)
        return {"airborne": airborne, "connectivity": conn_row, "sep_events": sep_events}

    # ------------------------------------------------------------------ outputs
    def _events(self, *types) -> list[dict]:
        return [e for e in self.events if e.get("event_type") in types]

    def comm_summary(self) -> dict:
        counters = (self.net or {}).get("counters", {})
        sent = delivered = 0
        lat_sum = lat_cnt = 0.0
        lat_max = 0.0
        hist: dict[int, int] = defaultdict(int)
        per_type = {}
        for ptype, c in counters.items():
            per_type[ptype] = {"sent": c.get("sent", 0), "delivered": c.get("delivered", 0),
                               "pdr": round(c["delivered"] / c["sent"], 4) if c.get("sent") else None}
            if ptype in UNICAST_TYPES:
                sent += c.get("sent", 0)
                delivered += c.get("delivered", 0)
                lat_sum += c.get("lat_sum", 0.0)
                lat_cnt += c.get("lat_count", 0)
                lat_max = max(lat_max, c.get("lat_max", 0.0))
                for k, v in (c.get("lat_hist") or {}).items():
                    hist[int(k)] += v
        p95 = None
        if hist:
            total = sum(hist.values())
            acc = 0
            for k in sorted(hist):
                acc += hist[k]
                if acc >= 0.95 * total:
                    p95 = (k + 1) * 5.0
                    break
        act = sum(self.active_time.values())
        con = sum(self.connected_time.values())
        return {
            "packet_delivery_ratio": round(delivered / sent, 4) if sent else None,
            "packets_sent": sent, "packets_delivered": delivered,
            "average_latency_ms": round(lat_sum / lat_cnt, 2) if lat_cnt else None,
            "max_latency_ms": round(lat_max, 2),
            "p95_latency_ms": p95,
            "connectivity_availability": round(con / act, 4) if act > 0 else None,
            "communication_downtime_s": round(sum(self.outage_time.values()), 2),
            "downtime_per_uav_s": {u: round(v, 2) for u, v in sorted(self.outage_time.items())},
            "longest_outage_s": {u: round(v, 2) for u, v in sorted(self.longest_outage.items())},
            "per_type": per_type,
        }

    def episodes(self) -> list[dict]:
        """Match each injected fault with its first detection and its recovery.

        Detection: the first event after the injection that concerns the target and shows
        the system noticed (heartbeat loss, link degradation, relay invalidation, battery
        anomaly / RTH, lost-link procedure).
        Recovery: UAV failure / communication faults -> the first RECONFIG_COMPLETE after
        detection; battery faults -> the target's tasks re-assigned to other UAVs after its
        return-to-home (or the RTH itself if it had no tasks left).
        """
        out = []
        detect_types = ("HEARTBEAT_LOST", "LINK_WARNING", "LINK_DEGRADED", "LINK_FAILED", "RELAY_INVALID",
                        "BATTERY_ANOMALY", "BATTERY_DRAIN_ANOMALY", "BATTERY_RTH", "UAV_FAILED", "LOST_LINK",
                        "PARTITION")
        for inj in self.injections:
            typ = inj["type"]
            if typ not in ("UAV_FAILURE", "COMM_DEGRADATION", "COMM_OUTAGE", "BATTERY_DEGRADATION"):
                continue
            t0 = inj["t"]
            tgts = set(inj["targets"])
            det = next((e for e in self.events if e.get("t", 0) >= t0 and e.get("event_type") in detect_types
                        and (e.get("uav_id") in tgts or not tgts)), None)
            rec = None
            if typ == "BATTERY_DEGRADATION":
                rth = next((e for e in self.events if e.get("t", 0) >= t0 and e.get("uav_id") in tgts
                            and e.get("event_type") in ("RTH_STARTED", "RTH_ACKNOWLEDGED", "BATTERY_RTH")
                            # the normal end-of-mission return is not a response to the battery fault
                            and not str((e.get("details") or {}).get("reason", "")).startswith("MISSION_COMPLETE")), None)
                if rth:
                    released = [e for e in self.events if e.get("event_type") == "TASK_RELEASED"
                                and e.get("uav_id") in tgts and e.get("t", 0) >= rth["t"] - 1.0]
                    if released:
                        ids = {e.get("details", {}).get("poi_id") for e in released}
                        rec = next((e for e in self.events if e.get("event_type") == "TASK_ASSIGNED"
                                    and e.get("t", 0) >= rth["t"] - 1.0
                                    and e.get("details", {}).get("poi_id") in ids
                                    and e.get("uav_id") not in tgts), None)
                    else:
                        rec = rth
            else:
                t_from = det["t"] if det else t0
                rec = next((e for e in self.events if e.get("t", 0) >= t_from
                            and e.get("event_type") == "RECONFIG_COMPLETE"), None)
            out.append({
                "id": inj["id"], "type": typ, "targets": sorted(tgts),
                "t_injected": t0, "mission_time_injected": inj["mission_time"],
                "detected_by": det.get("event_type") if det else None,
                "detection_delay_s": round(det["t"] - t0, 2) if det else None,
                "recovered": rec is not None,
                "recovered_by": rec.get("event_type") if rec else None,
                "recovery_time_s": round(rec["t"] - t0, 2) if rec else None,
                "recovery_after_detection_s": round(rec["t"] - det["t"], 2) if (rec and det) else None,
            })
        return out

    def summary(self) -> dict:
        pois = (self.status or {}).get("pois", [])
        valid = [p for p in pois if p.get("status") != "REJECTED"]
        done = [p for p in valid if p.get("status") == "COMPLETED"]
        w = lambda p: self.weights.get(str(p.get("priority", "MEDIUM")).upper(), 1.0)  # noqa: E731
        tot_w = sum(w(p) for p in valid)
        first_inj = min((i["t"] for i in self.injections if i["type"] in ("UAV_FAILURE", "COMM_DEGRADATION",
                                                                          "COMM_OUTAGE")), default=None)
        before = after = None
        if first_inj is not None and valid:
            done_before = [p for p in done if p.get("completed_at") is not None and p["completed_at"] <= first_inj]
            known_before = [p for p in valid if (p.get("announced_at") or 0) <= first_inj]
            remaining = [p for p in valid if p not in done_before]
            done_after = [p for p in done if p not in done_before]
            before = round(len(done_before) / len(known_before), 4) if known_before else None
            after = round(len(done_after) / len(remaining), 4) if remaining else None
        eps = self.episodes()
        relay_changes = [e for e in self._events("RELAY_CHANGED") if e.get("details", {}).get("old")]
        mission = {
            "result": self.final_phase or f"INCOMPLETE ({(self.status or {}).get('phase')})",
            "pois_total": len(valid), "pois_completed": len(done),
            "completion_rate": round(len(done) / len(valid), 4) if valid else None,
            "completion_time_s": round(self.all_pois_done_at - self.mission_start, 2)
            if (self.all_pois_done_at and self.mission_start) else None,
            "mission_duration_s": round(self.mission_end - self.mission_start, 2)
            if (self.mission_end and self.mission_start) else None,
            "priority_weighted_score": round(sum(w(p) for p in done) / tot_w, 4) if tot_w else None,
            "rejected_pois": [p["id"] for p in pois if p.get("status") == "REJECTED"],
        }
        autonomy = {
            "relay_reallocation_count": len(relay_changes),
            "task_reallocation_count": len(self._events("TASK_RELEASED", "TASK_PREEMPTED")),
            "reconfiguration_count": len(self._events("RECONFIG_COMPLETE")),
            "recovery_time_s": [e["recovery_time_s"] for e in eps if e["recovery_time_s"] is not None],
            "mean_recovery_time_s": round(sum(e["recovery_time_s"] for e in eps if e["recovery_time_s"])
                                          / max(1, sum(1 for e in eps if e["recovery_time_s"])), 2)
            if any(e["recovery_time_s"] for e in eps) else None,
        }
        safety = {
            "collision_count": self.sep.collisions,
            "minimum_inter_uav_distance_m": round(self.sep.min_separation, 3) if self.sep.min_separation < math.inf else None,
            "closest_pair": list(self.sep.min_pair),
            "separation_violations": self.sep.violations,
            "avoidance_activations": self.avoidance_events,
            "geofence_violations": self.geofence_violations,
            "geofence_warnings": self.geofence_warnings,
        }
        battery = {
            "lowest_battery_pct": {u: round(v, 1) for u, v in sorted(self.min_battery.items())},
            "rth_events": len(self._events("BATTERY_RTH")),
            "battery_warnings": len(self._events("BATTERY_WARNING")),
            "depleted_uavs": sorted(self.depleted),
        }
        robustness = {
            "mission_success_before_failure": before,
            "mission_success_after_failure": after,
            "communication_recovery_success": round(sum(1 for e in eps if e["recovered"]) / len(eps), 4) if eps else None,
            "episodes": eps,
        }
        software = {"software_errors": len(self._events("SOFTWARE_ERROR")),
                    "errors": [e.get("message") for e in self._events("SOFTWARE_ERROR")][:20]}
        return {"mission": mission, "communication": self.comm_summary(), "autonomy": autonomy,
                "safety": safety, "battery": battery, "robustness": robustness, "software": software}


def render_report(summary: dict, meta: dict) -> str:
    m, c, a, s, b, r = (summary[k] for k in ("mission", "communication", "autonomy", "safety", "battery", "robustness"))

    def f(v, unit=""):
        if v is None:
            return "n/a"
        if isinstance(v, float):
            return f"{v:.3f}{unit}" if abs(v) < 10 else f"{v:.1f}{unit}"
        return f"{v}{unit}"

    lines = [f"# Run report: {meta.get('scenario', '')}", "",
             f"* Run id: `{meta.get('run_id', '')}`",
             f"* Started (wall clock): {meta.get('started', '')}",
             f"* UAVs: {meta.get('num_uavs', '')}; world: {meta.get('world', '')}",
             f"* **Mission result: {m['result']}**", "",
             "## Mission", "| Metric | Value |", "|---|---|",
             f"| PoIs completed | {m['pois_completed']} / {m['pois_total']} |",
             f"| Completion rate | {f(m['completion_rate'])} |",
             f"| Completion time (all PoIs reported) | {f(m['completion_time_s'], ' s')} |",
             f"| Mission duration (start to all landed) | {f(m['mission_duration_s'], ' s')} |",
             f"| Priority-weighted score | {f(m['priority_weighted_score'])} |", "",
             "## Communication", "| Metric | Value |", "|---|---|",
             f"| Packet delivery ratio (end-to-end unicast) | {f(c['packet_delivery_ratio'])} ({c['packets_delivered']}/{c['packets_sent']}) |",
             f"| Average latency | {f(c['average_latency_ms'], ' ms')} |",
             f"| p95 latency | {f(c['p95_latency_ms'], ' ms')} |",
             f"| Maximum latency | {f(c['max_latency_ms'], ' ms')} |",
             f"| Connectivity availability | {f(c['connectivity_availability'])} |",
             f"| Communication downtime (UAV-seconds) | {f(c['communication_downtime_s'], ' s')} |",
             f"| Downtime per UAV | {c['downtime_per_uav_s']} |", "",
             "## Autonomous relay & role management / fault recovery", "| Metric | Value |", "|---|---|",
             f"| Relay reallocations | {a['relay_reallocation_count']} |",
             f"| Task reallocations | {a['task_reallocation_count']} |",
             f"| Network reconfigurations | {a['reconfiguration_count']} |",
             f"| Recovery times | {a['recovery_time_s']} s |",
             f"| Mean recovery time | {f(a['mean_recovery_time_s'], ' s')} |", "",
             "## Safety", "| Metric | Value |", "|---|---|",
             f"| Collisions | {s['collision_count']} |",
             f"| Minimum inter-UAV distance | {f(s['minimum_inter_uav_distance_m'], ' m')} {tuple(s['closest_pair'])} |",
             f"| Separation violations (< min safe distance) | {s['separation_violations']} |",
             f"| Collision-avoidance activations | {s['avoidance_activations']} |",
             f"| Geofence violations | {s['geofence_violations']} |",
             f"| Geofence warnings | {s['geofence_warnings']} |", "",
             "## Battery", "| Metric | Value |", "|---|---|",
             f"| Lowest battery per UAV | {b['lowest_battery_pct']} |",
             f"| Low-battery RTH events | {b['rth_events']} |",
             f"| Depleted UAVs | {b['depleted_uavs'] or 'none'} |", "",
             "## Robustness", "| Metric | Value |", "|---|---|",
             f"| Mission success before first failure | {f(r['mission_success_before_failure'])} |",
             f"| Mission success after first failure | {f(r['mission_success_after_failure'])} |",
             f"| Communication recovery success | {f(r['communication_recovery_success'])} |", "",
             "## Software health", "| Metric | Value |", "|---|---|",
             f"| Software errors (caught exceptions) | {summary.get('software', {}).get('software_errors', 0)} |", ""]
    if r["episodes"]:
        lines += ["### Injected faults", "| Fault | Target | Injected (mission s) | Detected by | Detection delay | Recovered | Recovery time |",
                  "|---|---|---|---|---|---|---|"]
        for e in r["episodes"]:
            lines.append(f"| {e['type']} ({e['id']}) | {', '.join(e['targets'])} | {f(e['mission_time_injected'])} | "
                         f"{e['detected_by'] or 'n/a'} | {f(e['detection_delay_s'], ' s')} | {e['recovered']} | "
                         f"{f(e['recovery_time_s'], ' s')} |")
    return "\n".join(lines) + "\n"
