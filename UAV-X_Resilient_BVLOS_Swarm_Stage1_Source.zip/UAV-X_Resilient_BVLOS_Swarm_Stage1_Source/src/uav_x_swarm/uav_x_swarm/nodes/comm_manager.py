"""Communication manager: the radio-network emulator between the GCS and all UAVs.

Every application packet is published on /net/tx and delivered, if it survives,
on /net/rx/<dst>. Each 10 Hz step the emulator:
  1. evaluates every link (GCS-UAV and UAV-UAV) from current positions with the
     distance-based link model plus injected impairments (loss, latency, outage);
  2. updates the routing layer's estimate of each link from simulated hellos (EWMA);
  3. recomputes routes with ETX shortest paths over the *estimated* graph.
Unicast packets follow the current route. Each hop is a Bernoulli trial with the
*true* loss, and latency = sum over hops of (mean latency + uniform jitter).
Broadcast beacons (dst "*") reach one-hop neighbours only.

All counters (sent / delivered / dropped by cause, latency) are published on
/network/state, together with the true and estimated link tables and routes.
"""
from __future__ import annotations

import heapq
import random

import rclpy
from geometry_msgs.msg import PointStamped
from rclpy.node import Node
from std_msgs.msg import String

from ..core.comm import LinkEstimator
from ..core.network import GCS, LinkModel, NetworkGraph, link_key
from .common import GuardedNode, QOS_LATCHED, QOS_STATE, QOS_STREAM, Clock, EventPublisher, from_msg, load_config, to_msg


class CommManager(GuardedNode):
    def __init__(self):
        super().__init__("comm_manager")
        self.cfg = cfg = load_config(self)
        cm = cfg["communication"]
        self.clock = Clock(self)
        self.ev = EventPublisher(self, "comm_manager")
        self.model = LinkModel(cm)
        seed = int(cm.get("seed", 42))
        self.rng = random.Random(seed)
        self.est = LinkEstimator(float(cm["link_estimation"]["ewma_alpha"]), random.Random(seed + 1))
        self.min_q = float(cm["link_estimation"]["min_usable_quality"])
        self.hello_period = 1.0 / float(cm["link_estimation"]["hello_rate_hz"])
        self.jitter = float(cm.get("jitter_ms", 0.0))
        self.uavs = cfg.uav_ids()
        self.nodes = [GCS] + self.uavs
        self.pos = {GCS: cfg.gcs_position()}
        self.radio = {n: True for n in self.nodes}
        self.inj_loss = {n: 0.0 for n in self.nodes}
        self.inj_lat = {n: 0.0 for n in self.nodes}
        self.inj_until: dict[str, float] = {}
        self.global_loss = 0.0
        self.graph = NetworkGraph(self.nodes)
        self.routes: dict[tuple[str, str], list[str] | None] = {}
        self.queue: list = []
        self.qseq = 0
        self.last_hello = 0.0
        self.counters: dict[str, dict] = {}
        self.forwarded = {n: 0 for n in self.nodes}
        self.prev_connected: dict[str, bool] = {}
        self.prev_route: dict[str, list] = {}
        self.usable: set = set()

        self.pub_rx = {n: self.create_publisher(String, f"/net/rx/{n}", QOS_STREAM) for n in self.nodes}
        self.pub_state = self.create_publisher(String, "/network/state", QOS_STATE)
        self.pub_comm = {u: self.create_publisher(String, f"/{u}/communication", QOS_STATE) for u in self.uavs}
        self.create_subscription(String, "/net/tx", self.on_tx, QOS_STREAM)
        self.create_subscription(String, "/network/inject", self.on_inject, QOS_STREAM)
        self.create_subscription(String, "/mission/start", self.on_start, QOS_LATCHED)
        for u in self.uavs:
            self.create_subscription(PointStamped, f"/{u}/position", lambda m, u=u: self.on_pos(u, m), QOS_STATE)
            self.create_subscription(String, f"/{u}/radio", lambda m, u=u: self.on_radio(u, m), QOS_LATCHED)
        self.create_timer(0.1, self.step)
        self.create_timer(0.01, self.deliver_due)
        self.create_timer(0.5, self.publish_state)
        self.get_logger().info(f"network emulator: {len(self.uavs)} UAVs, GCS range {self.model.gcs_range} m, "
                               f"UAV range {self.model.uav_range} m, seed {seed}")

    # ------------------------------------------------------------------ inputs
    def now(self) -> float:
        return self.clock.now()

    def on_start(self, msg):
        d = from_msg(msg) or {}
        if d.get("t0") is not None:
            self.ev.mission_t0 = float(d["t0"])

    def on_pos(self, uid: str, msg: PointStamped) -> None:
        self.pos[uid] = (msg.point.x, msg.point.y, msg.point.z)

    def on_radio(self, uid: str, msg: String) -> None:
        up = from_msg(msg) == "UP"
        if self.radio.get(uid) != up:
            self.radio[uid] = up
            self.ev.emit(self.now(), "LINK_RADIO", f"{uid.upper()} radio {'UP' if up else 'DOWN'}", uid, radio=up)

    def on_inject(self, msg: String) -> None:
        d = from_msg(msg) or {}
        typ = d.get("type")
        targets = d.get("targets") or []
        now = self.now()
        for t in targets:
            if t not in self.inj_loss:
                continue
            if typ in ("COMM_DEGRADATION", "PACKET_LOSS"):
                if "packet_loss" in d:
                    self.inj_loss[t] = float(d["packet_loss"])
                if "latency_ms" in d:
                    self.inj_lat[t] = float(d["latency_ms"])
            elif typ == "LATENCY":
                self.inj_lat[t] = float(d.get("latency_ms", 0.0))
            elif typ == "COMM_OUTAGE":
                self.inj_loss[t] = 1.0
                if d.get("duration"):
                    self.inj_until[t] = now + float(d["duration"])
            elif typ == "COMM_RESTORE":
                self.inj_loss[t], self.inj_lat[t] = 0.0, 0.0
                self.inj_until.pop(t, None)
        if typ in ("PACKET_LOSS",) and not targets:
            self.global_loss = float(d.get("packet_loss", 0.0))
        self.get_logger().info(f"impairment {typ} {targets or 'ALL'}: loss={ {t: self.inj_loss.get(t) for t in targets} } "
                               f"global={self.global_loss}")

    # ------------------------------------------------------------------ link / routing update
    def step(self) -> None:
        now = self.now()
        for t, until in list(self.inj_until.items()):
            if now >= until:
                self.inj_loss[t] = 0.0
                del self.inj_until[t]
                self.ev.emit(now, "LINK_OUTAGE_END", f"{t.upper()} communication outage ended", t)
        hello = now - self.last_hello >= self.hello_period
        if hello:
            self.last_hello = now
        g = NetworkGraph(self.nodes)
        for i, a in enumerate(self.nodes):
            for b in self.nodes[i + 1:]:
                if a not in self.pos or b not in self.pos:
                    continue
                la = self.inj_loss[a] + (self.global_loss if a != GCS else 0.0) * (1 - self.inj_loss[a])
                lb = self.inj_loss[b] + (self.global_loss if b != GCS else 0.0) * (1 - self.inj_loss[b])
                link = self.model.evaluate(a, b, self.pos[a], self.pos[b], radio_a=self.radio[a], radio_b=self.radio[b],
                                           inj_loss_a=min(1.0, la), inj_loss_b=min(1.0, lb),
                                           inj_lat_a=self.inj_lat[a], inj_lat_b=self.inj_lat[b])
                key = link_key(a, b)
                if hello:
                    link.est_quality = self.est.update(key, link.quality, link.available)
                else:
                    link.est_quality = self.est.get(key)
                # usability hysteresis: a link leaves the routing table below min_q and
                # re-enters only above min_q + 0.10 (prevents route flapping at the margin)
                if key in self.usable:
                    if link.est_quality < self.min_q:
                        self.usable.discard(key)
                elif link.est_quality >= self.min_q + 0.10:
                    self.usable.add(key)
                if key not in self.usable:
                    link.est_quality = min(link.est_quality, self.min_q * 0.99)
                g.set_link(link)
        self.graph = g
        prev = self.routes
        self.routes = {}
        for src in self.nodes:
            for dst in self.nodes:
                if src != dst:
                    path, cost = g.shortest_path(src, dst, use_estimate=True, min_quality=self.min_q)
                    old = prev.get((src, dst))
                    if path and old and old != path and self.route_cost(g, old) <= 1.15 * cost:
                        path = old     # route hysteresis: keep a still-valid route unless clearly worse
                    self.routes[(src, dst)] = path
        self.check_route_changes(now)

    def route_cost(self, g: NetworkGraph, path: list[str]) -> float:
        cost = 0.0
        for a, b in zip(path, path[1:]):
            l = g.link(a, b)
            if l is None or l.est_quality < self.min_q:
                return float("inf")
            cost += 1.0 / l.est_quality
        return cost

    def check_route_changes(self, now: float) -> None:
        for u in self.uavs:
            path = self.routes.get((u, GCS))
            conn = path is not None
            if u in self.prev_connected and conn != self.prev_connected[u]:
                if conn:
                    self.ev.emit(now, "ROUTE_RESTORED", f"{u.upper()} route to GCS restored: "
                                 f"{' -> '.join(n.upper() for n in path)}", u, route=path)
                else:
                    self.ev.emit(now, "ROUTE_LOST", f"{u.upper()} has no route to GCS", u)
            elif conn and path != self.prev_route.get(u) and len(path) > 2:
                self.ev.emit(now, "ROUTE_CHANGED", f"[route] {' -> '.join(n.upper() for n in path)}", u, route=path)
            self.prev_connected[u] = conn
            self.prev_route[u] = path

    # ------------------------------------------------------------------ packets
    def count(self, ptype: str, key: str, inc: int = 1) -> dict:
        c = self.counters.setdefault(ptype, {"sent": 0, "delivered": 0, "dropped_no_route": 0, "dropped_loss": 0,
                                             "dropped_radio_down": 0, "lat_sum": 0.0, "lat_count": 0,
                                             "lat_max": 0.0, "lat_hist": {}})
        c[key] = c.get(key, 0) + inc
        return c

    def on_tx(self, msg: String) -> None:
        pkt = from_msg(msg)
        if not pkt:
            return
        now = self.now()
        src, dst, ptype = pkt.get("src"), pkt.get("dst"), pkt.get("type", "DATA")
        if src not in self.radio:
            return
        if dst == "*":
            self.broadcast(pkt, now)
            return
        c = self.count(ptype, "sent")
        if not self.radio.get(src, False):
            c["dropped_radio_down"] += 1
            return
        path = self.routes.get((src, dst))
        if not path:
            c["dropped_no_route"] += 1
            return
        latency = 0.0
        for a, b in zip(path, path[1:]):
            l = self.graph.link(a, b)
            if l is None or not l.available or self.rng.random() >= l.quality:
                c["dropped_loss"] += 1
                return
            latency += l.latency_ms + self.rng.uniform(0.0, self.jitter)
        for relay in path[1:-1]:
            self.forwarded[relay] += 1
        pkt["hops"] = len(path) - 1
        pkt["route"] = path
        pkt["latency_ms"] = round(latency, 3)
        self.schedule(now + latency / 1000.0, dst, pkt)

    def broadcast(self, pkt: dict, now: float) -> None:
        src = pkt["src"]
        c = self.count("BEACON", "sent")
        if not self.radio.get(src, False):
            c["dropped_radio_down"] += 1
            return
        for n in self.nodes:
            if n == src:
                continue
            l = self.graph.link(src, n)
            if l is None or not l.available:
                continue
            if self.rng.random() < l.quality:
                lat = l.latency_ms + self.rng.uniform(0.0, self.jitter)
                p = dict(pkt, hops=1, route=[src, n], latency_ms=round(lat, 3))
                self.schedule(now + lat / 1000.0, n, p, beacon=True)

    def schedule(self, t_deliver: float, dst: str, pkt: dict, beacon: bool = False) -> None:
        self.qseq += 1
        heapq.heappush(self.queue, (t_deliver, self.qseq, dst, pkt, beacon))

    def deliver_due(self) -> None:
        now = self.now()
        while self.queue and self.queue[0][0] <= now:
            _, _, dst, pkt, beacon = heapq.heappop(self.queue)
            if not self.radio.get(dst, False):
                if not beacon:
                    self.count(pkt.get("type", "DATA"), "dropped_radio_down")
                continue
            pkt["t_rx"] = now
            self.pub_rx[dst].publish(to_msg(pkt))
            ptype = "BEACON" if beacon else pkt.get("type", "DATA")
            c = self.count(ptype, "delivered")
            lat = pkt.get("latency_ms", 0.0)
            c["lat_sum"] += lat
            c["lat_count"] += 1
            c["lat_max"] = max(c["lat_max"], lat)
            b = str(int(lat // 5))
            c["lat_hist"][b] = c["lat_hist"].get(b, 0) + 1

    # ------------------------------------------------------------------ state publication
    def publish_state(self) -> None:
        now = self.now()
        routes = {}
        cut = self.graph.cut_vertices_for(GCS, use_estimate=True, min_quality=self.min_q)
        for u in self.uavs:
            path = self.routes.get((u, GCS))
            q = self.graph.path_quality(path, use_estimate=False) if path else 0.0
            lat = self.graph.path_latency(path) if path else None
            routes[u] = {"connected": path is not None, "route": path, "hops": (len(path) - 1) if path else None,
                         "route_quality": round(q, 4), "route_latency_ms": round(lat, 2) if lat is not None else None,
                         "relays_for": cut.get(u, []), "forwarded": self.forwarded[u], "radio": self.radio[u],
                         "injected_loss": self.inj_loss[u], "injected_latency_ms": self.inj_lat[u]}
            neigh = {n: round(l.est_quality, 3) for n, l in self.graph.neighbors(u, use_estimate=True, min_quality=self.min_q)}
            self.pub_comm[u].publish(to_msg({"uav_id": u, "t": now, **routes[u], "neighbors": neigh}))
        state = {"t": now, "nodes": self.nodes, "positions": {k: [round(x, 2) for x in v] for k, v in self.pos.items()},
                 "links": [l.to_dict() for l in self.graph.links.values()], "routes": routes,
                 "counters": self.counters, "global_loss": self.global_loss}
        self.pub_state.publish(to_msg(state))


def main():
    rclpy.init()
    node = CommManager()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
