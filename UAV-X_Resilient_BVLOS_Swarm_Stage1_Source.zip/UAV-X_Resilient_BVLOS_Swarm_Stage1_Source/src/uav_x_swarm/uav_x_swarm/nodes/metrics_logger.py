"""Metrics logger ("black-box recorder") and demo event console.

Records everything to <run_dir>/:
  events.json / events.jsonl  every structured event (timestamp, type, uav_id, message, details)
  mission.csv                 1 Hz: phase, PoIs completed, relay, active UAVs, connectivity
  communication.csv           2 Hz per UAV: route, hops, route quality, connected, GCS-measured PDR/latency/status
  battery.csv                 1 Hz per UAV: battery, role, flight state
  safety.csv                  2 Hz: minimum pairwise separation, closest pair, geofence status per UAV
  failures.csv                injected faults, detection delay, recovery time
  relay_changes.csv           old relay, new relay, reason, detection time, change time
  summary.json / report.md    final metrics (rulebook categories)
Positions for the safety metrics come from the onboard vehicle states (PX4 EKF, i.e.
the simulated vehicles), not from the GCS's possibly stale view.
"""
from __future__ import annotations

import csv
import datetime
import json
import math
import os
import sys

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from ..core.events import format_event
from ..core.geofence import Geofence
from ..core.metrics import MetricsAccumulator, render_report
from .common import GuardedNode, QOS_LATCHED, QOS_STATE, QOS_STREAM, Clock, from_msg, load_config, to_msg


class MetricsLogger(GuardedNode):
    def __init__(self):
        super().__init__("metrics_logger")
        self.cfg = cfg = load_config(self)
        self.clock = Clock(self)
        run_dir = self.declare_parameter("run_dir", "").value
        if not run_dir:
            run_dir = os.path.join(cfg.root, "results", "runs",
                                   datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
        self.run_dir = run_dir
        os.makedirs(run_dir, exist_ok=True)
        self.print_events = bool(self.declare_parameter("print_events", True).value)
        scen = self.get_parameter("scenario").value or "none"
        if os.path.isabs(scen) and scen.startswith(cfg.root + os.sep):
            scen = os.path.relpath(scen, cfg.root)       # repository-relative in run records
        self.scenario = scen
        self.uids = cfg.uav_ids()
        self.acc = MetricsAccumulator(cfg, self.uids, Geofence.from_cfg(cfg["safety.geofence"]),
                                      cfg["mission.priority_weights"])
        self.t0 = None
        self.finalized = False
        self.end_seen_at = None
        self.started_wall = datetime.datetime.now().isoformat(timespec="seconds")
        self.status: dict = {}
        self.net: dict = {}
        self.relay_rows: list[dict] = []

        self.f_events = open(os.path.join(run_dir, "events.jsonl"), "w")
        self.f_console = open(os.path.join(run_dir, "console.txt"), "w")
        self.w = {}
        self.files = {}
        self._csv("mission", ["t", "mission_time", "phase", "pois_completed", "pois_total", "relay", "relay_point",
                              "active_uavs", "connected_uavs", "reconfiguring"])
        self._csv("communication", ["t", "mission_time", "uav_id", "connected", "hops", "route", "route_quality",
                                    "route_latency_ms", "gcs_pdr", "gcs_latency_ms", "link_status", "injected_loss",
                                    "cum_pdr"])
        self._csv("battery", ["t", "mission_time", "uav_id", "battery_pct", "role", "flight_state", "airborne",
                              "drain_multiplier"])
        self._csv("safety", ["t", "mission_time", "min_separation_m", "closest_pair", "airborne_uavs",
                             "geofence_status", "avoidance_active"])

        self.pub_live = self.create_publisher(String, "/metrics/live", QOS_STATE)
        self.create_subscription(String, "/events", self.on_event, QOS_STREAM)
        self.create_subscription(String, "/swarm/status", self.on_status, QOS_STATE)
        self.create_subscription(String, "/network/state", self.on_net, QOS_STATE)
        self.create_subscription(String, "/mission/start", self.on_start, QOS_LATCHED)
        for u in self.uids:
            self.create_subscription(String, f"/{u}/state", lambda m, u=u: self.on_uav(u, m), QOS_STATE)
        self.create_timer(0.5, self.fast)
        self.create_timer(1.0, self.slow)
        with open(os.path.join(run_dir, "meta.json"), "w") as f:
            json.dump({"run_id": os.path.basename(run_dir), "scenario": self.scenario, "started": self.started_wall,
                       "num_uavs": len(self.uids), "world": cfg["sim.world_name"], "config": cfg.data}, f, indent=2)
        self.console(f"\033[1m[RUN] results -> {run_dir}\033[0m")

    # ------------------------------------------------------------------ io helpers
    def _csv(self, name: str, header: list[str]) -> None:
        f = open(os.path.join(self.run_dir, f"{name}.csv"), "w", newline="")
        w = csv.writer(f)
        w.writerow(header)
        self.files[name], self.w[name] = f, w

    def console(self, line: str) -> None:
        self.f_console.write(line + "\n")
        self.f_console.flush()
        if self.print_events:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()

    def now(self) -> float:
        return self.clock.now()

    def mt(self, t: float) -> float | str:
        return round(t - self.t0, 2) if self.t0 is not None else ""

    # ------------------------------------------------------------------ callbacks
    def on_start(self, msg):
        d = from_msg(msg) or {}
        if d.get("t0") is not None:
            self.t0 = float(d["t0"])

    def on_event(self, msg: String) -> None:
        ev = from_msg(msg)
        if not ev:
            return
        self.acc.on_event(ev)
        self.f_events.write(json.dumps(ev) + "\n")
        self.f_events.flush()
        et = ev.get("event_type", "")
        self.console(format_event(ev))
        if et == "RELAY_CHANGED":
            d = ev.get("details", {})
            self.relay_rows.append({"t": ev["t"], "mission_time": ev.get("mission_time"), "old_relay": d.get("old"),
                                    "new_relay": d.get("new"), "reason": d.get("reason"),
                                    "detection_time": d.get("detection_time"),
                                    "detection_to_change_s": round(ev["t"] - d["detection_time"], 2)
                                    if d.get("detection_time") else None})
        if et in ("MISSION_COMPLETE", "MISSION_FAILED") and self.end_seen_at is None:
            self.end_seen_at = self.now()

    def on_status(self, msg):
        self.status = from_msg(msg) or {}
        self.acc.on_status(self.status)

    def on_net(self, msg):
        self.net = from_msg(msg) or {}
        self.acc.on_network(self.net)

    def on_uav(self, uid: str, msg):
        d = from_msg(msg)
        if d:
            self.acc.on_uav_state(uid, d)

    # ------------------------------------------------------------------ periodic
    def fast(self) -> None:
        t = self.now()
        res = self.acc.sample(t)
        mt = self.mt(t)
        airborne = res["airborne"]
        mins, pair = None, ""
        ids = sorted(airborne)
        for i, a in enumerate(ids):
            for b in ids[i + 1:]:
                d = math.dist(airborne[a], airborne[b])
                if mins is None or d < mins:
                    mins, pair = d, f"{a}-{b}"
        gf = {u: self.acc.geofence_state.get(u, "INSIDE") for u in ids}
        av = {u: self.acc.truth[u].get("avoidance", []) for u in ids if self.acc.truth.get(u, {}).get("avoidance")}
        self.w["safety"].writerow([round(t, 2), mt, round(mins, 3) if mins is not None else "", pair, len(ids),
                                   json.dumps(gf), json.dumps(av)])
        routes = (self.net or {}).get("routes", {})
        suav = (self.status or {}).get("uavs", {})
        counters = (self.net or {}).get("counters", {})
        tel = counters.get("TELEMETRY", {})
        cum = round(tel["delivered"] / tel["sent"], 4) if tel.get("sent") else ""
        for u in self.uids:
            r = routes.get(u, {})
            s = suav.get(u, {})
            self.w["communication"].writerow([
                round(t, 2), mt, u, int(bool(r.get("connected"))), r.get("hops", ""),
                "->".join(r.get("route") or []), r.get("route_quality", ""), r.get("route_latency_ms", ""),
                round(s.get("link_quality", 0.0), 3) if s else "", round(s.get("latency_ms", 0.0), 1) if s else "",
                s.get("link_status", ""), r.get("injected_loss", ""), cum])

    def slow(self) -> None:
        t = self.now()
        mt = self.mt(t)
        st = self.status or {}
        routes = (self.net or {}).get("routes", {})
        active = [u for u, s in self.acc.truth.items() if s.get("airborne") and not s.get("failed")]
        conn = [u for u in active if routes.get(u, {}).get("connected")]
        self.w["mission"].writerow([round(t, 2), mt, st.get("phase", ""), st.get("completed_pois", ""),
                                    st.get("total_pois", ""), st.get("relay", ""), json.dumps(st.get("relay_point")),
                                    len(active), len(conn), int(bool(st.get("reconfig")))])
        for u in self.uids:
            s = self.acc.truth.get(u)
            if s:
                self.w["battery"].writerow([round(t, 2), mt, u, s.get("battery"), s.get("role"), s.get("flight_state"),
                                            int(bool(s.get("airborne"))), s.get("battery_multiplier", 1.0)])
        for f in self.files.values():
            f.flush()
        live = self.acc.summary()
        self.pub_live.publish(to_msg(live))
        if self.end_seen_at is not None and not self.finalized and t - self.end_seen_at >= 2.0:
            self.finalize()

    # ------------------------------------------------------------------ final report
    def finalize(self) -> None:
        if self.finalized:
            return
        self.finalized = True
        summary = self.acc.summary()
        meta = {"run_id": os.path.basename(self.run_dir), "scenario": self.scenario, "started": self.started_wall,
                "num_uavs": len(self.uids), "world": self.cfg["sim.world_name"]}
        with open(os.path.join(self.run_dir, "summary.json"), "w") as f:
            json.dump({"meta": meta, **summary}, f, indent=2, default=str)
        with open(os.path.join(self.run_dir, "report.md"), "w") as f:
            f.write(render_report(summary, meta))
        with open(os.path.join(self.run_dir, "events.json"), "w") as f:
            json.dump(self.acc.events, f, indent=1, default=str)
        with open(os.path.join(self.run_dir, "failures.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["id", "type", "targets", "t_injected", "mission_time_injected", "detected_by",
                        "detection_delay_s", "recovered", "recovery_time_s", "recovery_after_detection_s"])
            for e in summary["robustness"]["episodes"]:
                w.writerow([e["id"], e["type"], ";".join(e["targets"]), e["t_injected"], e["mission_time_injected"],
                            e["detected_by"], e["detection_delay_s"], e["recovered"], e["recovery_time_s"],
                            e["recovery_after_detection_s"]])
        with open(os.path.join(self.run_dir, "relay_changes.csv"), "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["t", "mission_time", "old_relay", "new_relay", "reason",
                                              "detection_time", "detection_to_change_s"])
            w.writeheader()
            for r in self.relay_rows:
                w.writerow(r)
        for fh in self.files.values():
            fh.flush()
        m, c, s = summary["mission"], summary["communication"], summary["safety"]
        self.console("\033[1m" + "=" * 78)
        self.console(f"[RESULT] {m['result']}: {m['pois_completed']}/{m['pois_total']} PoIs, completion time "
                     f"{m['completion_time_s']} s, priority score {m['priority_weighted_score']}")
        self.console(f"[RESULT] PDR {c['packet_delivery_ratio']}, mean latency {c['average_latency_ms']} ms, "
                     f"connectivity {c['connectivity_availability']}, downtime {c['communication_downtime_s']} s")
        self.console(f"[RESULT] relay changes {summary['autonomy']['relay_reallocation_count']}, task reallocations "
                     f"{summary['autonomy']['task_reallocation_count']}, recovery {summary['autonomy']['recovery_time_s']} s")
        self.console(f"[RESULT] collisions {s['collision_count']}, min separation {s['minimum_inter_uav_distance_m']} m, "
                     f"geofence violations {s['geofence_violations']}")
        self.console(f"[RESULT] report: {os.path.join(self.run_dir, 'report.md')}")
        self.console("=" * 78 + "\033[0m")
        with open(os.path.join(self.run_dir, "DONE"), "w") as f:
            f.write(m["result"] or "")

    def close(self) -> None:
        if not self.finalized and self.acc.events:
            self.finalize()
        self.f_events.close()
        self.f_console.close()
        for f in self.files.values():
            f.close()


def main():
    rclpy.init()
    node = MetricsLogger()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.close()
        finally:
            node.destroy_node()
            rclpy.try_shutdown()
