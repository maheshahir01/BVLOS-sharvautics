"""Swarm manager: centralised decision-making at the GCS.

It only knows what arrives over the emulated radio network (telemetry, events,
command ACKs), so communication degradation genuinely affects its knowledge and
its ability to command UAVs. Components (all in core/):

    mission_manager   -> MissionStateMachine (explicit phase transitions)
    task_allocator    -> TaskAllocator (priority-first, energy-feasible, pre-emption)
    relay_manager     -> RelayManager (suitability score, placement, hysteresis)
    communication     -> PdrMonitor + classify_link (measured end-to-end PDR/latency)
    failure_detector  -> FailureDetector (heartbeat timeout + partition inference)
    battery_manager   -> BatteryPolicy (warning / RTH commands, allocation feasibility)
    collision_manager -> SeparationMonitor (GCS-side monitoring; avoidance runs onboard)
    geofence_manager  -> Geofence (warning / breach -> RTH)
    priority_manager  -> PriorityManager (weights, pre-emption rules)

Commands are sent reliably: each has a cmd_id and is retransmitted until the UAV
ACKs it, or until a newer plan supersedes it.
"""
from __future__ import annotations

import math

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from ..core.allocation import TaskAllocator
from ..core.battery import BatteryParams, BatteryPolicy, DrainEstimator
from ..core.collision import SeparationMonitor
from ..core.comm import PdrMonitor, classify_link, severity
from ..core.failure import FailureDetector
from ..core.geofence import BREACH, WARNING, Geofence
from ..core.mission import MissionStateMachine
from ..core.network import LinkModel
from ..core.priority import PriorityManager
from ..core.relay import RelayManager
from ..core.types import FlightState as FS
from ..core.types import Health, LinkStatus, MissionPhase as P, PoI, Role, TaskStatus, UAVView
from .common import (GuardedNode, QOS_LATCHED, QOS_STATE, QOS_STREAM, Clock, EventPublisher, PacketFactory, from_msg,
                     load_config, to_msg)

ACTIVE_STATES = {FS.READY, FS.ARMING, FS.TAKEOFF, FS.HOLD, FS.TRANSIT, FS.SURVEY, FS.RELAY_STATION, FS.RETURN_HOME}
AIR_STATES = {FS.TAKEOFF, FS.HOLD, FS.TRANSIT, FS.SURVEY, FS.RELAY_STATION, FS.RETURN_HOME}


class SwarmManager(GuardedNode):
    def __init__(self):
        super().__init__("swarm_manager")
        self.cfg = cfg = load_config(self)
        self.clock = Clock(self)
        self.ev = EventPublisher(self, "swarm_manager")
        self.pf = PacketFactory("gcs")
        self.uids = cfg.uav_ids()
        homes = cfg.home_positions()
        self.views = {u: UAVView(u, homes[u]) for u in self.uids}
        self.gcs = cfg.gcs_position()
        self.fence = Geofence.from_cfg(cfg["safety.geofence"])
        self.lm = LinkModel(cfg["communication"])
        self.bparams = BatteryParams.from_cfg(cfg["battery"])
        self.bpolicy = BatteryPolicy(self.bparams, float(cfg["flight.cruise_speed_mps"]))
        self.drain = DrainEstimator(self.bparams)
        self.prio = PriorityManager(cfg["mission.priority_weights"], cfg["mission.allocation.preempt_for"])
        self.alloc = TaskAllocator(cfg, self.bpolicy, self.prio)
        self.relay_mgr = RelayManager(cfg, self.lm, self.fence)
        fd = cfg["failure_detection"]
        self.fdet = FailureDetector(float(fd["heartbeat_timeout_s"]), float(fd["failure_confirm_s"]))
        self.hb_timeout = float(fd["heartbeat_timeout_s"])
        cm = cfg["communication"]
        self.th = cm["thresholds"]
        self.pdr = PdrMonitor(float(cm["pdr_window_s"]), float(cm["telemetry_rate_hz"]))
        self.sep = SeparationMonitor(float(cfg["safety.minimum_safe_distance_m"]),
                                     float(cfg["safety.collision_distance_m"]))
        self.sm = MissionStateMachine()
        self.timeout = float(cfg["mission.timeout_s"])
        self.start_timeout = float(cfg.get("mission.start_timeout_s", 180.0))
        self.start_delay = float(cfg.get("mission.start_delay_s", 3.0))

        self.pois: dict[str, PoI] = {}
        self.queues: dict[str, list[str]] = {u: [] for u in self.uids}
        self.assigned_role: dict[str, Role] = {u: Role.IDLE for u in self.uids}
        self.plan_version = {u: 0 for u in self.uids}
        self.sent_plan: dict[str, tuple] = {}
        self.pending: dict[str, dict] = {}
        self.cmd_seq = 0
        self.relay: str | None = None
        self.relay_point = None
        self.relay_needed = False
        self.last_placement = -1e9
        self.t0: float | None = None
        self.t_all_ready: float | None = None
        self.t_boot = self.now()
        self.surveys_started = 0
        self.reconfig: dict | None = None
        self.counters = {"relay_changes": 0, "task_reallocations": 0, "reconfigurations": 0}
        self.batt_flags: dict[str, set] = {u: set() for u in self.uids}
        self.fence_flags: dict[str, str] = {u: "INSIDE" for u in self.uids}
        self.link_state_prev: dict[str, LinkStatus] = {}
        self.link_candidate: dict[str, tuple] = {}
        self.all_done_announced = False
        self.relay_search_announced = False
        self.last_relay_change = -1e9
        self.relay_min_hold = float(cfg.get("relay.min_hold_s", 45.0))
        self.relay_link_grace = float(cfg.get("relay.link_grace_s", 15.0))
        self.reposition_period = float(cfg.get("relay.placement.reposition_period_s", 10.0))
        self.announced_unassignable: set[str] = set()
        self.self_elected: dict[str, bool] = {}
        self.relay_hold_until = 0.0
        self.reconfig_ok_since: float | None = None

        self.pub_tx = self.create_publisher(String, "/net/tx", QOS_STREAM)
        self.pub_status = self.create_publisher(String, "/swarm/status", QOS_STATE)
        self.pub_start = self.create_publisher(String, "/mission/start", QOS_LATCHED)
        self.create_subscription(String, "/net/rx/gcs", self.on_packet, QOS_STREAM)
        self.create_subscription(String, "/gcs/mission", self.on_mission, QOS_LATCHED)
        self.create_timer(1.0 / float(cfg["control.swarm_manager_rate_hz"]), self.loop)
        self.get_logger().info(f"swarm manager: {len(self.uids)} UAVs {self.uids}")

    # ================================================================= utilities
    def now(self) -> float:
        return self.clock.now()

    def mt(self) -> float:
        return 0.0 if self.t0 is None else self.now() - self.t0

    def emit(self, etype: str, message: str, uav: str | None = None, **details) -> None:
        self.ev.emit(self.now(), etype, message, uav, **details)

    def send_cmd(self, uid: str, cmd: str, **payload) -> None:
        self.cmd_seq += 1
        cid = f"c{self.cmd_seq}"
        body = {"cmd_id": cid, "cmd": cmd, **payload}
        # a newer ASSIGN supersedes older, unacknowledged ones for the same UAV
        if cmd == "ASSIGN":
            for k in [k for k, v in self.pending.items() if v["uid"] == uid and v["body"]["cmd"] == "ASSIGN"]:
                del self.pending[k]
        self.pending[cid] = {"uid": uid, "body": body, "t": self.now(), "tries": 1}
        self.pub_tx.publish(to_msg(self.pf.make(uid, "CMD", body, self.now())))

    def retry_cmds(self) -> None:
        now = self.now()
        for cid, p in list(self.pending.items()):
            if self.views[p["uid"]].health == Health.FAILED or p["tries"] > 60:
                del self.pending[cid]
                continue
            if now - p["t"] >= 1.5:
                p["t"], p["tries"] = now, p["tries"] + 1
                self.pub_tx.publish(to_msg(self.pf.make(p["uid"], "CMD", p["body"], now)))

    def send_plan(self, uid: str, force: bool = False) -> None:
        role = self.assigned_role[uid]
        if role in (Role.RETURN_HOME, Role.FAILED, Role.EMERGENCY):
            return          # these UAVs are commanded with RTH / not at all
        tasks = [{"poi_id": t, "position": list(self.pois[t].position), "priority": self.pois[t].priority}
                 for t in self.queues[uid] if t in self.pois]
        rp = list(self.relay_point) if self.relay_point else None
        key = (role.value, tuple(t["poi_id"] for t in tasks), tuple(round(v, 0) for v in rp) if rp else None)
        if not force and self.sent_plan.get(uid) == key:
            return
        self.sent_plan[uid] = key
        self.plan_version[uid] += 1
        self.send_cmd(uid, "ASSIGN", version=self.plan_version[uid], role=role.value, tasks=tasks, relay_point=rp)

    def active(self, v: UAVView) -> bool:
        return v.health not in (Health.FAILED,) and v.flight_state in ACTIVE_STATES and v.first_seen is not None

    # ================================================================= inputs
    def on_mission(self, msg: String) -> None:
        d = from_msg(msg) or {}
        for pd in d.get("pois", []):
            pid = pd["id"]
            if pid not in self.pois:
                p = PoI.from_dict(pd)
                if p.status not in (TaskStatus.REJECTED, TaskStatus.COMPLETED):
                    p.status = TaskStatus.PENDING
                self.pois[pid] = p
                if not p.initial and p.status != TaskStatus.REJECTED and self.t0 is not None:
                    self.on_new_poi(p)
            else:
                p = self.pois[pid]
                if pd.get("status") == "COMPLETED" and p.status != TaskStatus.COMPLETED:
                    p.status = TaskStatus.COMPLETED
                    p.completed_at = pd.get("completed_at")
                    p.completed_by = pd.get("completed_by")
                if pd.get("announced_at") is not None:
                    p.announced_at = pd["announced_at"]

    def on_new_poi(self, p: PoI) -> None:
        if self.sm.phase in (P.SURVEY, P.DEPLOY, P.RECONFIGURING) and self.sm.can(P.EMERGENCY):
            self.sm.transition(P.EMERGENCY, self.now(), f"new {p.priority} PoI {p.id}")
            self.emit("PHASE_CHANGED", f"Mission phase -> EMERGENCY (new {p.priority} PoI {p.id})", phase="EMERGENCY")
        elif self.sm.phase in (P.RETURN_HOME,) and self.sm.can(P.RECONFIGURING):
            self.sm.transition(P.RECONFIGURING, self.now(), f"new PoI {p.id} during return")
            self.emit("PHASE_CHANGED", "Mission phase -> RECONFIGURING (new PoI during return)", phase="RECONFIGURING")
            self.all_done_announced = False

    def on_packet(self, msg: String) -> None:
        pkt = from_msg(msg)
        if not pkt:
            return
        src, ptype, pl = pkt.get("src"), pkt.get("type"), pkt.get("payload", {})
        v = self.views.get(src)
        if v is None:
            return
        now = self.now()
        # passive liveness: a UAV that forwards other UAVs' packets is evidently alive
        for hop in (pkt.get("route") or [])[1:-1]:
            hv = self.views.get(hop)
            if hv is not None and hv.first_seen is not None and hv.health != Health.FAILED:
                hv.last_heartbeat = max(hv.last_heartbeat or 0.0, now)
        if ptype == "TELEMETRY":
            self.self_elected[src] = bool(pl.get("self_elected_relay"))
            if v.first_seen is None:
                v.first_seen = now
            v.last_heartbeat = now
            v.position = tuple(pl["position"])
            v.velocity = tuple(pl["velocity"])
            v.battery = float(pl["battery"])
            v.flight_state = FS(pl["flight_state"])
            v.airborne = bool(pl["airborne"])
            v.current_task = pl.get("current_task")
            v.task_queue = list(pl.get("task_queue", []))
            v.neighbors = pl.get("neighbors", {})
            v.geofence_status = pl.get("geofence_status", "INSIDE")
            v.rth_reason = pl.get("rth_reason")
            v.route = pkt.get("route") or []
            v.hops = pkt.get("hops", 0)
            step = self.drain.update(src, now, v.battery, math.hypot(*v.velocity), v.airborne,
                                     pl.get("role") == "RELAY", v.flight_state == FS.SURVEY)
            if step:
                self.emit("BATTERY_ANOMALY", f"{src.upper()} sudden battery drop of {step:.1f}% detected "
                          f"(now {v.battery:.1f}%)", src, drop=round(step, 2), battery=v.battery)
            f = self.drain.get(src)
            if f >= 1.5 and v.drain_factor < 1.5:
                self.emit("BATTERY_DRAIN_ANOMALY", f"{src.upper()} battery draining {f:.1f}x faster than "
                          f"modelled: energy plans and RTH threshold adjusted", src, factor=round(f, 2))
            v.drain_factor = f
            v.coverage_margin = self.coverage_margin(src)
            self.pdr.record(src, now, float(pkt.get("latency_ms", 0.0)))
            self.reconcile(v, pl)
        elif ptype == "ACK":
            self.pending.pop(pl.get("cmd_id"), None)
        elif ptype == "EVENT" and pl.get("event") == "SURVEY_STARTED":
            p = self.pois.get(pl.get("poi_id"))
            if p and p.status in (TaskStatus.ASSIGNED, TaskStatus.PENDING):
                p.status = TaskStatus.IN_PROGRESS
            self.surveys_started += 1

    def reconcile(self, v: UAVView, pl: dict) -> None:
        """Align the GCS view with what the UAV reports it is doing onboard."""
        reported = Role(pl.get("role", "IDLE"))
        uid = v.uav_id
        for pid in pl.get("completed", []):
            p = self.pois.get(pid)
            if p and p.status not in (TaskStatus.COMPLETED,):
                p.status = TaskStatus.SURVEYED
        if v.current_task and v.current_task in self.pois and self.pois[v.current_task].status == TaskStatus.ASSIGNED:
            self.pois[v.current_task].status = TaskStatus.IN_PROGRESS
        # onboard autonomous return home (low battery / lost link / manual)
        if reported == Role.RETURN_HOME and self.assigned_role[uid] != Role.RETURN_HOME:
            was = self.assigned_role[uid]
            self.assigned_role[uid] = Role.RETURN_HOME
            v.role = Role.RETURN_HOME
            self.emit("RTH_ACKNOWLEDGED", f"{uid.upper()} returning home ({v.rth_reason}); was {was.value}: "
                      f"releasing its role and tasks", uid, reason=v.rth_reason, was=was.value)
            if was == Role.RELAY:
                self.relay_invalid(f"relay {uid.upper()} returning home ({v.rth_reason})")
        elif reported == Role.EMERGENCY:
            self.assigned_role[uid] = Role.EMERGENCY
            v.role = Role.EMERGENCY
        # peer-elected bridge relay (after a partition)
        if pl.get("self_elected_relay") and self.relay != uid and \
                self.assigned_role[uid] in (Role.SURVEY, Role.SURVEY_RELAY, Role.IDLE) and \
                self.sm.phase not in (P.RETURN_HOME, P.LAND, P.MISSION_COMPLETE, P.MISSION_FAILED):
            cur = self.views.get(self.relay) if self.relay else None
            if cur is None or cur.health in (Health.LOST, Health.FAILED) or self.assigned_role.get(self.relay) != Role.RELAY:
                self.adopt_relay(uid, "PEER_ELECTED (UAV elected itself as bridge while partitioned)")
            else:
                self.send_plan(uid, force=True)      # a valid relay exists: resume survey role
        if self.assigned_role[uid] != Role.RETURN_HOME:
            v.role = self.derived_role(uid)

    def coverage_margin(self, uid: str) -> float:
        """How far inside radio coverage a UAV is: 1 - d/R to its best link partner (GCS or a
        UAV the GCS currently hears). Near 0 = at the edge, negative = beyond range."""
        v = self.views[uid]
        best = 1.0 - math.dist(v.position, self.gcs) / self.lm.gcs_range
        now = self.now()
        for o, ov in self.views.items():
            if o == uid or ov.last_heartbeat is None or now - ov.last_heartbeat > 2.0:
                continue
            best = max(best, 1.0 - math.dist(v.position, ov.position) / self.lm.uav_range)
        return best

    def derived_role(self, uid: str) -> Role:
        r = self.assigned_role[uid]
        if r == Role.SURVEY and self.views[uid].route is not None:
            # a survey UAV that forwards other UAVs' traffic is a SURVEY_RELAY
            for other, ov in self.views.items():
                if other != uid and ov.route and uid in ov.route[1:-1] and ov.health == Health.OK:
                    return Role.SURVEY_RELAY
        return r

    # ================================================================= relay handling
    def relay_invalid(self, reason: str) -> None:
        self.emit("RELAY_INVALID", f"Relay {self.relay.upper() if self.relay else '-'} unavailable: {reason}",
                  self.relay, reason=reason)
        self.start_reconfig(reason)

    def adopt_relay(self, uid: str, reason: str) -> None:
        old = self.relay
        self.relay = uid
        self.assigned_role[uid] = Role.RELAY
        for t in self.queues[uid]:
            if t in self.pois and self.pois[t].status in (TaskStatus.ASSIGNED, TaskStatus.IN_PROGRESS):
                self.pois[t].status = TaskStatus.PENDING
                self.pois[t].assigned_to = None
                self.counters["task_reallocations"] += 1
                self.emit("TASK_RELEASED", f"{t} released by {uid.upper()} (now relay); will be reassigned", uid, poi_id=t)
        self.queues[uid] = []
        if old and old != uid:
            self.counters["relay_changes"] += 1
            if self.assigned_role.get(old) == Role.RELAY:
                ov = self.views[old]
                # a radio fault is specific to the old relay only if other UAVs still have usable links
                others_ok = any(v.link_status in (LinkStatus.GOOD, LinkStatus.WARNING) for k, v in self.views.items()
                                if k not in (old, uid) and v.health in (Health.OK, Health.WARNING))
                radio_fault = ov.health in (Health.OK, Health.WARNING) and others_ok and \
                    severity(ov.link_status) >= severity(LinkStatus.DEGRADED)
                if radio_fault:
                    self.assigned_role[old] = Role.RETURN_HOME
                elif ov.health in (Health.OK, Health.WARNING):
                    self.assigned_role[old] = Role.SURVEY
                else:
                    self.assigned_role[old] = Role.FAILED
                if self.assigned_role[old] == Role.RETURN_HOME:
                    self.send_cmd(old, "RTH", reason="RADIO_DEGRADED")
                    self.emit("RTH_COMMANDED", f"{old.upper()} released from relay duty with degraded radio: "
                              f"returning home", old)
                elif self.assigned_role[old] == Role.SURVEY:
                    self.send_plan(old, force=True)
        self.relay_search_announced = False
        self.last_relay_change = self.now()
        v = self.views[uid]
        self.emit("RELAY_CHANGED", f"{uid.upper()} selected as new relay"
                  + (f" (replacing {old.upper()})" if old and old != uid else "") + f": {reason}", uid,
                  old=old, new=uid, reason=reason, battery=v.battery, position=v.position,
                  detection_time=self.reconfig["t"] if self.reconfig else None)
        self.send_plan(uid, force=True)

    def manage_relay(self) -> None:
        now = self.now()
        # placement points: where the survey UAVs are and where they are going next
        place_pts = []
        for u, v in self.views.items():
            # LOST (possibly out-of-range) survey UAVs count with their last known position,
            # so the relay moves toward them and restores their link
            if self.assigned_role[u] in (Role.SURVEY, Role.IDLE) and self.active(v) and \
                    v.health in (Health.OK, Health.WARNING, Health.LOST):
                place_pts.append(v.position)
                nxt = [v.current_task] if v.current_task else self.queues[u][:1]
                for t in nxt:
                    if t in self.pois:
                        place_pts.append((*self.pois[t].position, v.position[2]))
        targets = list(place_pts) + [(*p.position, 25.0) for p in self.pois.values()
                                     if p.status in (TaskStatus.PENDING, TaskStatus.ASSIGNED, TaskStatus.IN_PROGRESS)]
        needed = self.relay_mgr.relay_needed(targets, self.gcs)
        if needed != self.relay_needed:
            self.relay_needed = needed
            self.emit("RELAY_REQUIREMENT", f"Relay {'required' if needed else 'not required'}: "
                      f"{'tasks beyond' if needed else 'all tasks within'} {self.relay_mgr.required_beyond:.0f} m of GCS",
                      needed=needed)
        if not needed:
            if self.relay and self.assigned_role.get(self.relay) == Role.RELAY and self.sm.phase not in (P.RETURN_HOME, P.LAND):
                old = self.relay
                self.assigned_role[old] = Role.SURVEY
                self.relay = None
                self.emit("ROLE_CHANGED", f"{old.upper()} role RELAY -> SURVEY (relay no longer required)", old)
                self.send_plan(old, force=True)
            return
        # relay position
        alt = self.cfg.cruise_altitude(self.relay) if self.relay else float(self.cfg["flight.cruise_altitude_m"])
        if now - self.last_placement > self.reposition_period or self.relay_point is None:
            self.last_placement = now
            survey_pts = place_pts or targets
            prop = self.relay_mgr.placement(self.gcs, survey_pts, alt, self.relay_point)
            if prop and self.relay_mgr.should_reposition(self.relay_point, prop, self.gcs, survey_pts, alt):
                old = self.relay_point
                self.relay_point = prop
                self.emit("RELAY_POSITION", f"Relay position -> ({prop[0]:.0f}, {prop[1]:.0f}) "
                          f"to cover {len(survey_pts)} survey positions", self.relay, position=prop,
                          previous=old)
                if self.relay:
                    self.send_plan(self.relay, force=True)
        # relay selection
        cur = self.views.get(self.relay) if self.relay else None
        relay_down = cur is None or cur.health in (Health.LOST, Health.FAILED) or \
            self.assigned_role.get(self.relay) != Role.RELAY
        if relay_down:
            bridges = [u for u, v in self.views.items() if self.self_elected.get(u) and u != self.relay
                       and self.assigned_role[u] in (Role.SURVEY, Role.SURVEY_RELAY, Role.IDLE)
                       and v.health in (Health.OK, Health.WARNING) and self.relay_mgr.eligibility(v)[0]]
            if bridges:
                best = min(bridges, key=lambda u: (math.dist(self.views[u].position[:2], self.relay_point[:2]), u))
                if not self.reconfig:
                    self.start_reconfig(f"relay {self.relay.upper() if self.relay else '-'} unavailable")
                self.adopt_relay(best, "PEER_ELECTED (UAV elected itself as bridge while partitioned)")
                return
            if now < self.relay_hold_until:
                return
        cands = {u: v for u, v in self.views.items() if v.first_seen is not None}
        force = None
        if self.relay and self.assigned_role.get(self.relay) != Role.RELAY:
            force = self.assigned_role.get(self.relay).value
        grace = self.now() - self.last_relay_change < self.relay_link_grace
        dec = self.relay_mgr.select(cands, self.relay, self.relay_point, self.gcs, force, link_grace=grace)
        if dec.changed and dec.reason.startswith("BETTER_CANDIDATE") and \
                self.now() - self.last_relay_change < self.relay_min_hold:
            return      # planned hand-overs are rate-limited; failures are handled immediately
        if dec.changed and dec.new_relay:
            if self.relay:
                if not self.reconfig:
                    self.start_reconfig(f"relay {self.relay.upper()} {dec.reason}")
                self.emit("RELAY_SEARCH", f"Searching for replacement relay (reason: {dec.reason})", self.relay,
                          scores=dec.scores)
            self.adopt_relay(dec.new_relay, dec.reason + f" (score {dec.scores[dec.new_relay]['score']:.2f})")
            self.emit("RELAY_SCORES", "Relay scores: " + ", ".join(
                f"{u.upper()}={s['score']:.2f}{'' if s['eligible'] else '(' + s['why'] + ')'}"
                for u, s in sorted(dec.scores.items())), dec.new_relay, scores=dec.scores)
        elif dec.changed and dec.new_relay is None:
            if not self.relay_search_announced:
                self.relay_search_announced = True
                if not self.reconfig:
                    self.start_reconfig(f"relay {self.relay.upper() if self.relay else '-'} {dec.reason}")
                self.emit("RELAY_SEARCH", f"Searching for replacement relay for "
                          f"{self.relay.upper() if self.relay else '-'}: no eligible UAV reachable from the GCS; "
                          f"waiting for reconnection / peer election", self.relay, scores=dec.scores)

    # ================================================================= reconfiguration episodes
    def start_reconfig(self, reason: str) -> None:
        if self.reconfig is None:
            self.reconfig = {"t": self.now(), "reason": reason}
            self.emit("RECONFIG_START", f"Network reconfiguration started: {reason}", reason=reason)
        if self.sm.phase in (P.SURVEY, P.DEPLOY, P.EMERGENCY) and self.sm.can(P.RECONFIGURING):
            self.sm.transition(P.RECONFIGURING, self.now(), reason)
            self.emit("PHASE_CHANGED", "Mission phase -> RECONFIGURING", phase="RECONFIGURING")

    def check_reconfig_done(self) -> None:
        if self.reconfig is None:
            return
        alive = [u for u, v in self.views.items()
                 if v.health in (Health.OK, Health.WARNING) and self.active(v) and v.airborne]
        if not alive:
            return
        now = self.now()
        fresh = all(now - (self.views[u].last_heartbeat or 0.0) < 1.5 for u in alive)
        ok_links = fresh and all(v.link_status in (LinkStatus.GOOD, LinkStatus.WARNING)
                                 for u, v in self.views.items() if u in alive)
        relay_ok = (not self.relay_needed) or (
            self.relay is not None and self.views[self.relay].health in (Health.OK, Health.WARNING)
            and self.views[self.relay].link_status in (LinkStatus.GOOD, LinkStatus.WARNING))
        relay_fresh = (not self.relay_needed) or (self.relay is not None and
                                                  now - (self.views[self.relay].last_heartbeat or 0.0) < 1.5)
        if not (ok_links and relay_ok and relay_fresh):
            self.reconfig_ok_since = None
            return
        if self.reconfig_ok_since is None:
            self.reconfig_ok_since = now
        if now - self.reconfig_ok_since >= 2.0:
            self.reconfig_ok_since = None
            dur = self.now() - self.reconfig["t"]
            self.counters["reconfigurations"] += 1
            routes = {u: " -> ".join(n.upper() for n in (self.views[u].route or [])) for u in alive}
            self.emit("RECONFIG_COMPLETE", f"Network reconfigured in {dur:.1f} s: relay "
                      f"{self.relay.upper() if self.relay else 'none'}, {len(alive)} UAVs connected "
                      f"[{'; '.join(routes.values())}]", self.relay, duration=round(dur, 2),
                      reason=self.reconfig["reason"], routes=routes)
            self.reconfig = None
            if self.sm.phase == P.RECONFIGURING:
                nxt = P.SURVEY if not self.all_pois_done() else P.RETURN_HOME
                self.sm.transition(nxt, self.now(), "reconfiguration complete")
                self.emit("PHASE_CHANGED", f"Mission phase -> {nxt.value}", phase=nxt.value)

    # ================================================================= main loop
    def loop(self) -> None:
        now = self.now()
        self.update_comm(now)
        for e in self.fdet.update(self.views, now):
            self.on_failure_event(e)
        self.phase_logic(now)
        if self.t0 is not None and not self.sm.terminal:
            if self.sm.phase not in (P.INITIALIZING, P.TAKEOFF, P.FORMATION, P.RETURN_HOME, P.LAND):
                self.manage_relay()
            if self.sm.phase not in (P.INITIALIZING, P.TAKEOFF, P.FORMATION):
                self.allocate()
            self.battery_manager()
            self.geofence_manager()
            self.collision_monitor()
            self.check_reconfig_done()
        self.retry_cmds()
        self.publish_status()

    def update_comm(self, now: float) -> None:
        for u, v in self.views.items():
            if v.first_seen is None:
                continue
            pdr, lat, n = self.pdr.stats(u, now)
            age = now - v.last_heartbeat if v.last_heartbeat else math.inf
            status = classify_link(pdr, lat, self.th, received_any=age <= self.hb_timeout,
                                   previous=self.link_state_prev.get(u))
            v.link_quality, v.packet_loss, v.latency_ms = pdr, 1.0 - pdr, lat
            prev = self.link_state_prev.get(u, LinkStatus.GOOD)
            # debounce: a new status must persist for three cycles (1.5 s) before it is reported
            cand, cnt = self.link_candidate.get(u, (status, 0))
            cnt = cnt + 1 if cand == status else 1
            self.link_candidate[u] = (status, cnt)
            if status != prev and cnt >= 3:
                self.link_state_prev[u] = status
                v.link_status = status
                if v.health == Health.FAILED:
                    continue
                if severity(status) > severity(prev):
                    et = {LinkStatus.WARNING: "LINK_WARNING", LinkStatus.DEGRADED: "LINK_DEGRADED",
                          LinkStatus.FAILED: "LINK_FAILED", LinkStatus.DISCONNECTED: "LINK_DISCONNECTED"}[status]
                else:
                    et = "LINK_RECOVERED"
                self.emit(et, f"{u.upper()} link {prev.value} -> {status.value} (PDR {pdr:.2f}, latency {lat:.0f} ms, "
                          f"route {' -> '.join(n.upper() for n in (v.route or []))})", u, pdr=round(pdr, 3),
                          latency_ms=round(lat, 1), status=status.value, previous=prev.value)
                if u == self.relay and severity(status) >= severity(LinkStatus.DEGRADED) and \
                        status != LinkStatus.DISCONNECTED and self.t0 is not None and \
                        self.now() - self.last_relay_change >= self.relay_link_grace:
                    self.relay_invalid(f"relay link {status.value} (PDR {pdr:.2f})")
            elif status == prev:
                v.link_status = status

    def on_failure_event(self, e: dict) -> None:
        u = e["uav_id"]
        t = e["type"]
        if t == "HEARTBEAT_LOST":
            behind = e.get("partitioned_behind")
            if behind:
                self.emit("PARTITION", f"{u.upper()} unreachable: partitioned behind {behind.upper()} "
                          f"(last route {' -> '.join(n.upper() for n in e['last_route'])})", u,
                          behind=behind, last_route=e["last_route"])
            else:
                why = " after its link faded (likely out of range / interference)" if e.get("fade") else ""
                self.emit("HEARTBEAT_LOST", f"{u.upper()} heartbeat lost ({e['age']:.1f} s without telemetry{why})", u,
                          age=e["age"], last_route=e["last_route"], fade=e.get("fade"))
            if u == self.relay and not behind:
                self.relay_invalid(f"relay {u.upper()} heartbeat lost")
            elif self.t0 is not None and not self.sm.terminal:
                self.start_reconfig(f"{u.upper()} lost")
        elif t == "UAV_FAILED":
            self.assigned_role[u] = Role.FAILED
            self.views[u].role = Role.FAILED
            self.emit("UAV_FAILED", f"{u.upper()} declared FAILED (no telemetry for {e['lost_for']:.0f} s)", u,
                      lost_for=e["lost_for"])
        elif t == "RECONNECTED":
            now = self.now()
            self.pdr.reset(u, now)
            self.pdr.record(u, now, 0.0)
            self.views[u].link_status = LinkStatus.WARNING
            self.link_state_prev[u] = LinkStatus.WARNING
            self.link_candidate[u] = (LinkStatus.WARNING, 0)
            self.emit("RECONNECTED", f"{u.upper()} reconnected after {e['down_time']:.1f} s "
                      f"({'was partitioned behind ' + e['partitioned_behind'].upper() if e.get('partitioned_behind') else 'was ' + e['was']})",
                      u, down_time=e["down_time"], was=e["was"])
            if self.assigned_role[u] == Role.FAILED:
                self.assigned_role[u] = Role.SURVEY
            rv = self.views.get(self.relay) if self.relay else None
            if rv is None or rv.health in (Health.LOST, Health.FAILED):
                # wait for the (possibly peer-elected) bridge's own telemetry before choosing
                self.relay_hold_until = max(self.relay_hold_until, now + 2.0)
            self.send_plan(u, force=True)

    def phase_logic(self, now: float) -> None:
        ph = self.sm.phase
        if ph == P.INITIALIZING:
            ready = [u for u, v in self.views.items() if v.flight_state == FS.READY and v.first_seen is not None
                     and now - (v.last_heartbeat or 0) < self.hb_timeout]
            if len(ready) == len(self.uids):
                if self.t_all_ready is None:
                    self.t_all_ready = now
                    self.emit("SWARM_READY", f"All {len(ready)} UAVs ready and connected to GCS")
                if now - self.t_all_ready >= self.start_delay:
                    self.start_mission(ready)
            elif now - self.t_boot > self.start_timeout and len(ready) >= 2:
                self.emit("SWARM_READY", f"Start timeout: starting with {len(ready)}/{len(self.uids)} UAVs")
                self.start_mission(ready)
            return
        if self.sm.terminal:
            return
        if now - self.t0 > self.timeout:
            self.finish(False, f"mission timeout ({self.timeout:.0f} s)")
            return
        alive = [u for u, v in self.views.items() if v.health != Health.FAILED and self.assigned_role[u] != Role.FAILED]
        if ph == P.TAKEOFF:
            up = [u for u in alive if self.views[u].flight_state in AIR_STATES - {FS.TAKEOFF}]
            if len(up) == len(alive):
                self.transition(P.FORMATION, "all UAVs at their altitude layers")
            elif now - self.sm.entered_at > 90.0 and up:
                for u in alive:
                    if u not in up:
                        self.assigned_role[u] = Role.FAILED
                        self.views[u].health = Health.FAILED
                        self.emit("UAV_FAILED", f"{u.upper()} failed to take off within 90 s", u)
                self.transition(P.FORMATION, f"{len(up)} UAVs airborne (takeoff timeout)")
            return
        if ph == P.FORMATION:
            self.transition(P.DEPLOY, "deploying to relay position and PoIs")
            for u in alive:
                self.send_plan(u, force=True)
            return
        if ph == P.DEPLOY and self.surveys_started > 0:
            self.transition(P.SURVEY, "first PoI survey started")
        if ph == P.EMERGENCY:
            if not any(p.status == TaskStatus.PENDING and p.priority in ("HIGH", "CRITICAL") for p in self.pois.values()):
                self.transition(P.RECONFIGURING if self.reconfig else P.SURVEY, "priority task assigned")
        if ph in (P.SURVEY, P.RECONFIGURING, P.EMERGENCY, P.DEPLOY) and self.all_pois_done():
            if not self.all_done_announced:
                self.all_done_announced = True
                self.emit("ALL_POIS_COMPLETED", f"All {len(self.valid_pois())} PoIs completed "
                          f"(reports received at GCS) at mission time {self.mt():.1f} s")
            if self.sm.can(P.RETURN_HOME):
                self.transition(P.RETURN_HOME, "all PoIs completed")
        if self.sm.phase == P.RETURN_HOME:
            for u in alive:
                if self.assigned_role[u] not in (Role.RELAY, Role.RETURN_HOME, Role.EMERGENCY):
                    self.command_rth(u, "MISSION_COMPLETE")
            if self.relay and self.assigned_role.get(self.relay) == Role.RELAY:
                others = [u for u in alive if u != self.relay]
                if all(self.views[u].flight_state in (FS.LANDING, FS.LANDED) or
                       math.dist(self.views[u].position[:2], self.gcs[:2]) < 0.8 * self.lm.gcs_range for u in others):
                    self.command_rth(self.relay, "MISSION_COMPLETE (relay returns last)")
            if all(self.views[u].flight_state in (FS.LANDING, FS.LANDED) for u in alive):
                self.transition(P.LAND, "all UAVs landing")
        if self.sm.phase == P.LAND:
            if all(self.views[u].flight_state == FS.LANDED for u in alive):
                self.finish(self.all_pois_done(), "all UAVs landed")

    def transition(self, to: P, reason: str) -> None:
        if self.sm.transition(to, self.now(), reason):
            self.emit("PHASE_CHANGED", f"Mission phase -> {to.value} ({reason})", phase=to.value, reason=reason)

    def start_mission(self, ready: list[str]) -> None:
        self.t0 = self.now()
        self.ev.mission_t0 = self.t0
        self.pub_start.publish(to_msg({"t0": self.t0}))
        for p in self.pois.values():
            if p.announced_at is None:
                p.announced_at = self.t0
        self.emit("MISSION_START", f"Mission started: {len(ready)} UAVs, {len(self.valid_pois())} PoIs",
                  uavs=ready, pois=[p.id for p in self.valid_pois()])
        for u in self.uids:
            if u not in ready:
                self.assigned_role[u] = Role.FAILED
                self.views[u].health = Health.FAILED
        # initial roles: relay by score, everybody else surveys
        targets = [(*p.position, 25.0) for p in self.valid_pois()]
        self.relay_needed = self.relay_mgr.relay_needed(targets, self.gcs)
        if self.relay_needed:
            self.relay_point = self.relay_mgr.placement(self.gcs, targets, float(self.cfg["flight.cruise_altitude_m"]))
            self.last_placement = self.now()
            dec = self.relay_mgr.select({u: self.views[u] for u in ready}, None, self.relay_point, self.gcs)
            self.relay = dec.new_relay
            self.emit("RELAY_SCORES", "Initial relay scores: " + ", ".join(
                f"{u.upper()}={s['score']:.2f}" for u, s in sorted(dec.scores.items())), self.relay, scores=dec.scores)
        for u in ready:
            self.assigned_role[u] = Role.RELAY if u == self.relay else Role.SURVEY
            self.emit("ROLE_ASSIGNED", f"{u.upper()} role = {self.assigned_role[u].value}", u,
                      role=self.assigned_role[u].value)
        if self.relay:
            self.emit("RELAY_CHANGED", f"{self.relay.upper()} selected as initial relay at "
                      f"({self.relay_point[0]:.0f}, {self.relay_point[1]:.0f})", self.relay, old=None, new=self.relay,
                      reason="INITIAL_SELECTION", position=self.relay_point)
        self.allocate(send=False)
        self.transition(P.TAKEOFF, "mission start")
        for u in ready:
            self.send_cmd(u, "TAKEOFF")

    def valid_pois(self) -> list[PoI]:
        return [p for p in self.pois.values() if p.status != TaskStatus.REJECTED]

    def all_pois_done(self) -> bool:
        v = self.valid_pois()
        return bool(v) and all(p.status == TaskStatus.COMPLETED for p in v)

    def finish(self, success: bool, reason: str) -> None:
        to = P.MISSION_COMPLETE if success else P.MISSION_FAILED
        if not self.sm.can(to):
            self.sm.phase = to     # terminal from any phase on timeout
            self.sm.history.append((self.now(), "-", to.value, reason))
        else:
            self.sm.transition(to, self.now(), reason)
        done = sum(1 for p in self.valid_pois() if p.status == TaskStatus.COMPLETED)
        self.emit("MISSION_COMPLETE" if success else "MISSION_FAILED",
                  f"{'MISSION COMPLETE' if success else 'MISSION FAILED'}: {done}/{len(self.valid_pois())} PoIs, "
                  f"mission time {self.mt():.1f} s ({reason})", completed=done, total=len(self.valid_pois()),
                  mission_time=round(self.mt(), 2), reason=reason)
        if not success:
            for u, v in self.views.items():
                if v.health != Health.FAILED and v.airborne:
                    self.command_rth(u, "MISSION_FAILED")

    def command_rth(self, uid: str, reason: str) -> None:
        if self.assigned_role[uid] in (Role.RETURN_HOME, Role.FAILED, Role.EMERGENCY):
            return
        v = self.views[uid]
        if v.flight_state in (FS.LANDING, FS.LANDED, FS.READY):
            self.assigned_role[uid] = Role.RETURN_HOME
            return
        was = self.assigned_role[uid]
        self.assigned_role[uid] = Role.RETURN_HOME
        self.send_cmd(uid, "RTH", reason=reason)
        self.emit("RTH_COMMANDED", f"{uid.upper()} returning home ({reason})", uid, reason=reason, was=was.value)
        if was == Role.RELAY and self.sm.phase not in (P.RETURN_HOME, P.LAND):
            self.relay_invalid(f"relay {uid.upper()} returning home ({reason})")

    # ================================================================= task allocation
    def allocate(self, send: bool = True) -> None:
        in_prog = {u: v.current_task for u, v in self.views.items()}
        # the allocator sees the role the GCS assigned (a derived SURVEY_RELAY still surveys)
        views = {}
        for u, v in self.views.items():
            vv = UAVView(**{**v.__dict__})
            vv.role = self.assigned_role[u] if self.assigned_role[u] != Role.SURVEY_RELAY else Role.SURVEY
            views[u] = vv
        before = {u: list(q) for u, q in self.queues.items()}
        new_q, events = self.alloc.plan(self.pois, views, self.queues, in_prog)
        self.queues = new_q
        for e in events:
            if e.type == "TASK_ASSIGNED":
                self.announced_unassignable.discard(e.poi_id)
                p = self.pois[e.poi_id]
                reassign = p.attempts > 1
                self.emit("TASK_ASSIGNED", f"{e.poi_id} ({p.priority}) {'re' if reassign else ''}assigned to "
                          f"{e.uav_id.upper()} [{e.details}]", e.uav_id, poi_id=e.poi_id, priority=p.priority,
                          reassigned=reassign)
            elif e.type in ("TASK_RELEASED", "TASK_PREEMPTED"):
                self.counters["task_reallocations"] += 1
                self.emit(e.type, f"{e.poi_id}: {e.details}" if e.type == "TASK_RELEASED" else
                          f"{e.uav_id.upper()} pre-empts {e.poi_id}: {e.details}", e.uav_id, poi_id=e.poi_id)
            elif e.type == "TASK_UNASSIGNABLE":
                if e.poi_id not in self.announced_unassignable:
                    self.announced_unassignable.add(e.poi_id)
                    self.emit("TASK_UNASSIGNABLE", f"{e.poi_id} waiting: {e.details}", None, poi_id=e.poi_id)
        if send:
            for u in self.uids:
                if self.assigned_role[u] in (Role.RETURN_HOME, Role.FAILED, Role.EMERGENCY):
                    continue
                if self.queues[u] != before.get(u) or self.assigned_role[u] == Role.RELAY:
                    if self.views[u].health != Health.FAILED and self.views[u].first_seen is not None:
                        self.send_plan(u)

    # ================================================================= battery / geofence / collision
    def battery_manager(self) -> None:
        for u, v in self.views.items():
            if v.first_seen is None or v.health == Health.FAILED or not v.airborne:
                continue
            flags = self.batt_flags[u]
            if v.battery <= self.bparams.warning and "warn" not in flags:
                flags.add("warn")
                if v.health == Health.OK:
                    v.health = Health.WARNING
                self.emit("BATTERY_WARNING", f"{u.upper()} battery {v.battery:.1f}% below warning threshold "
                          f"{self.bparams.warning:.0f}%: no new long tasks, not eligible as relay below "
                          f"{self.relay_mgr.min_batt:.0f}%", u, battery=v.battery)
            thr = self.bpolicy.rth_threshold(math.dist(v.position[:2], v.home), v.drain_factor)
            if v.battery <= thr and self.assigned_role[u] not in (Role.RETURN_HOME, Role.EMERGENCY):
                self.emit("BATTERY_RTH", f"{u.upper()} battery {v.battery:.1f}% below RTH threshold {thr:.1f}%", u,
                          battery=v.battery, threshold=thr)
                self.command_rth(u, "LOW_BATTERY")

    def geofence_manager(self) -> None:
        for u, v in self.views.items():
            if v.first_seen is None or not v.airborne or v.health == Health.FAILED:
                continue
            st = self.fence.status(v.position)
            prev = self.fence_flags[u]
            if st != prev:
                self.fence_flags[u] = st
                if st == WARNING:
                    self.emit("GEOFENCE_WARNING", f"{u.upper()} within {self.fence.warning_margin:.0f} m of the "
                              f"geofence at ({v.position[0]:.0f}, {v.position[1]:.0f}, {v.position[2]:.0f})", u,
                              position=v.position, margin=round(self.fence.margin(v.position), 2))
                elif st == BREACH:
                    self.emit("GEOFENCE_BREACH", f"{u.upper()} OUTSIDE geofence: commanding return", u,
                              position=v.position)
                    self.command_rth(u, "GEOFENCE_BREACH")

    def collision_monitor(self) -> None:
        pos = {u: v.position for u, v in self.views.items()
               if v.airborne and v.health in (Health.OK, Health.WARNING)}
        for e in self.sep.update(pos):
            a, b = e["pair"]
            self.emit("SEPARATION_" + ("COLLISION" if e["type"] == "COLLISION" else "VIOLATION"),
                      f"GCS view: {a.upper()}-{b.upper()} separation {e['distance']:.1f} m", a, pair=e["pair"],
                      distance=e["distance"])

    # ================================================================= status
    def publish_status(self) -> None:
        now = self.now()
        uavs = {}
        for u, v in self.views.items():
            d = v.to_dict()
            d["assigned_role"] = self.assigned_role[u].value
            d["task_queue"] = list(self.queues[u])
            d["heartbeat_age"] = round(now - v.last_heartbeat, 2) if v.last_heartbeat else None
            d["plan_version"] = self.plan_version[u]
            uavs[u] = d
        done = sum(1 for p in self.valid_pois() if p.status == TaskStatus.COMPLETED)
        self.pub_status.publish(to_msg({
            "t": now, "t0": self.t0, "mission_time": round(self.mt(), 2) if self.t0 else None,
            "phase": self.sm.phase.value, "relay": self.relay,
            "relay_point": [round(x, 1) for x in self.relay_point] if self.relay_point else None,
            "relay_needed": self.relay_needed, "completed_pois": done, "total_pois": len(self.valid_pois()),
            "surveys_started": self.surveys_started, "uavs": uavs,
            "pois": [p.to_dict() for p in self.pois.values()],
            "reconfig": self.reconfig, "counters": self.counters,
            "pending_commands": len(self.pending), "phase_history": self.sm.history[-20:],
        }))


def main():
    rclpy.init()
    node = SwarmManager()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
