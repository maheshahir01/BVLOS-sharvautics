"""Ground Control Station node (operator interface, outside the disaster zone).

* owns the mission definition (PoIs) and publishes it on /gcs/mission (latched);
* receives survey reports over the radio network, acknowledges them end-to-end
  (ACK packet back to the UAV), and marks a PoI COMPLETED only when its report has
  actually arrived at the GCS;
* sends a GCS beacon (GCS_HB) to every UAV at 1 Hz through the network; UAVs
  use it to detect loss of the GCS link;
* accepts new high-priority PoIs at runtime (/gcs/inject), validates them against
  the geofence, adds them to the mission and spawns a marker in Gazebo.
"""
from __future__ import annotations

import os
import subprocess
import threading

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from ..core.geofence import Geofence
from ..core.priority import PriorityManager
from ..core.types import PoI, TaskStatus
from .common import GuardedNode, QOS_LATCHED, QOS_STREAM, Clock, EventPublisher, PacketFactory, from_msg, load_config, to_msg


class GCSNode(GuardedNode):
    def __init__(self):
        super().__init__("gcs")
        self.cfg = cfg = load_config(self)
        self.clock = Clock(self)
        self.ev = EventPublisher(self, "gcs")
        self.pf = PacketFactory("gcs")
        self.fence = Geofence.from_cfg(cfg["safety.geofence"])
        self.prio = PriorityManager(cfg["mission.priority_weights"], cfg["mission.allocation.preempt_for"])
        self.spawn_markers = bool(self.declare_parameter("spawn_markers", True).value)
        self.catalog = {p["id"]: p for p in cfg.pois()}
        self.pois: dict[str, PoI] = {}
        for p in cfg.pois():
            if p.get("initial", True):
                self.pois[p["id"]] = PoI(p["id"], p.get("name", p["id"]), tuple(p["position"][:2]),
                                         p.get("priority", "MEDIUM").upper(), True)
        self.reports: dict[str, dict] = {}
        self.t0 = None
        self.version = 0
        self.uavs = cfg.uav_ids()
        self.pub_tx = self.create_publisher(String, "/net/tx", QOS_STREAM)
        self.pub_mission = self.create_publisher(String, "/gcs/mission", QOS_LATCHED)
        self.create_subscription(String, "/net/rx/gcs", self.on_packet, QOS_STREAM)
        self.create_subscription(String, "/gcs/inject", self.on_inject, QOS_STREAM)
        self.create_subscription(String, "/mission/start", self.on_start, QOS_LATCHED)
        self.create_timer(1.0 / float(cfg["gcs.heartbeat_rate_hz"]), self.heartbeat)
        self.publish_mission()
        self.get_logger().info(f"GCS at {cfg.gcs_position()}, {len(self.pois)} initial PoIs")

    def now(self) -> float:
        return self.clock.now()

    def on_start(self, msg):
        d = from_msg(msg) or {}
        if d.get("t0") is not None and self.t0 is None:
            self.t0 = float(d["t0"])
            self.ev.mission_t0 = self.t0
            for p in self.pois.values():
                p.announced_at = self.t0
            self.publish_mission()

    def publish_mission(self) -> None:
        self.version += 1
        self.pub_mission.publish(to_msg({"version": self.version, "t": self.now(),
                                         "pois": [p.to_dict() for p in self.pois.values()]}))

    def heartbeat(self) -> None:
        for u in self.uavs:
            self.pub_tx.publish(to_msg(self.pf.make(u, "GCS_HB", {"t": self.now()}, self.now())))

    def on_packet(self, msg: String) -> None:
        pkt = from_msg(msg)
        if not pkt or pkt.get("type") != "REPORT":
            return
        rep = pkt.get("payload", {})
        poi_id, uav = rep.get("poi_id"), pkt.get("src")
        # always ACK (the previous ACK may have been lost)
        self.pub_tx.publish(to_msg(self.pf.make(uav, "ACK", {"poi_id": poi_id}, self.now())))
        p = self.pois.get(poi_id)
        if p is None or p.status == TaskStatus.COMPLETED:
            return
        p.status = TaskStatus.COMPLETED
        p.completed_at = self.now()
        p.completed_by = uav
        self.reports[poi_id] = {**rep, "received_at": self.now(), "route": pkt.get("route"),
                                "latency_ms": pkt.get("latency_ms"), "hops": pkt.get("hops")}
        route = " -> ".join(n.upper() for n in (pkt.get("route") or []))
        delay = self.now() - float(rep.get("timestamp", self.now()))
        dc = rep.get("data_collected", {})
        self.ev.emit(self.now(), "REPORT_RECEIVED",
                     f"{poi_id} survey report received from {uav.upper()} via {route} "
                     f"({dc.get('images', '?')} images, {dc.get('data_mb', '?')} MB, "
                     f"{'store-and-forward delay ' + format(delay, '.0f') + ' s' if delay > 2 else 'direct'})",
                     uav, poi_id=poi_id, route=pkt.get("route"), hops=pkt.get("hops"),
                     latency_ms=pkt.get("latency_ms"), report=rep, delivery_delay_s=round(delay, 2))
        done = sum(1 for q in self.pois.values() if q.status == TaskStatus.COMPLETED)
        valid = sum(1 for q in self.pois.values() if q.status != TaskStatus.REJECTED)
        self.ev.emit(self.now(), "POI_COMPLETED", f"{poi_id} COMPLETE ({done}/{valid} PoIs)", uav,
                     poi_id=poi_id, completed=done, total=valid)
        self.publish_mission()

    def on_inject(self, msg: String) -> None:
        d = from_msg(msg) or {}
        if d.get("type") != "NEW_PRIORITY_POI":
            return
        spec = d.get("poi_def") or self.catalog.get(d.get("poi"))
        if spec is None:
            self.get_logger().error(f"unknown PoI in injection: {d}")
            return
        pid = spec["id"]
        if pid in self.pois:
            return
        p = PoI(pid, spec.get("name", pid), tuple(spec["position"][:2]), str(spec.get("priority", "HIGH")).upper(),
                False, announced_at=self.now())
        ok, why = self.prio.validate(p, self.fence, self.fence.clamp_margin + 10.0)
        if not ok:
            p.status = TaskStatus.REJECTED
            self.pois[pid] = p
            self.ev.emit(self.now(), "POI_REJECTED", f"New PoI {pid} REJECTED: {why}", None, poi_id=pid, reason=why)
            self.publish_mission()
            return
        self.pois[pid] = p
        self.ev.emit(self.now(), "NEW_PRIORITY_POI",
                     f"New {p.priority} PRIORITY PoI detected: {pid} '{p.name}' at ({p.position[0]:.0f}, "
                     f"{p.position[1]:.0f}), weight {self.prio.weight(p.priority):g}", None,
                     poi_id=pid, priority=p.priority, position=p.position)
        self.publish_mission()
        if self.spawn_markers:
            threading.Thread(target=self.spawn_marker, args=(pid,), daemon=True).start()

    def spawn_marker(self, pid: str) -> None:
        """Show the new PoI in Gazebo (best effort; the mission does not depend on it)."""
        root = self.cfg.root
        try:
            sdf = subprocess.run(["python3", os.path.join(root, "scripts", "tools", "generate_world.py"),
                                  "--marker", pid], capture_output=True, text=True, timeout=20).stdout.strip()
            if not sdf:
                return
            env = {"PATH": "/usr/bin:/bin", "HOME": os.environ.get("HOME", "/tmp"),
                   "GZ_IP": os.environ.get("GZ_IP", "127.0.0.1"), "GZ_PARTITION": os.environ.get("GZ_PARTITION", "uavx")}
            world = self.cfg["sim.world_name"]
            req = 'sdf: "' + sdf.replace('"', "'") + '"'
            r = subprocess.run(["/usr/bin/gz", "service", "-s", f"/world/{world}/create", "--reqtype",
                                "gz.msgs.EntityFactory", "--reptype", "gz.msgs.Boolean", "--timeout", "5000",
                                "--req", req], env=env, capture_output=True, text=True, timeout=20)
            ok = "data: true" in r.stdout
            self.get_logger().info(f"Gazebo marker for {pid}: {'spawned' if ok else 'not spawned: ' + r.stdout + r.stderr}")
        except Exception as exc:  # the simulator may not be running (unit/integration tests)
            self.get_logger().warning(f"marker spawn for {pid} failed: {exc}")


def main():
    rclpy.init()
    node = GCSNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
