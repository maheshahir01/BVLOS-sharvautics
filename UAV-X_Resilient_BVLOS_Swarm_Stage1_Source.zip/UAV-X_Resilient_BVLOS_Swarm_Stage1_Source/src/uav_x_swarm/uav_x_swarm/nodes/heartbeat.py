"""Minimal per-UAV heartbeat publisher used to verify the ROS 2 setup (Phase 7)."""
import json

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class Heartbeat(Node):
    def __init__(self):
        super().__init__("heartbeat")
        self.uav_id = self.declare_parameter("uav_id", "uav1").value
        self.pub = self.create_publisher(String, "heartbeat", 10)
        self.seq = 0
        self.create_timer(1.0, self.tick)

    def tick(self):
        self.seq += 1
        msg = String()
        msg.data = json.dumps({"uav_id": self.uav_id, "seq": self.seq,
                               "stamp": self.get_clock().now().nanoseconds * 1e-9})
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = Heartbeat()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
