"""Helpers shared by the ROS 2 nodes (JSON-over-String messages, QoS, packets, events)."""
from __future__ import annotations

import json
import os

from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from std_msgs.msg import String

from ..core.config import Config
from ..core.events import make_event

# reliable, keep-last queue for packet and event streams
QOS_STREAM = QoSProfile(depth=200, reliability=ReliabilityPolicy.RELIABLE, history=HistoryPolicy.KEEP_LAST)
# latched: late subscribers receive the last value (mission definition, radio state)
QOS_LATCHED = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE, history=HistoryPolicy.KEEP_LAST,
                         durability=DurabilityPolicy.TRANSIENT_LOCAL)
QOS_STATE = QoSProfile(depth=5, reliability=ReliabilityPolicy.RELIABLE, history=HistoryPolicy.KEEP_LAST)


def to_msg(obj) -> String:
    m = String()
    m.data = json.dumps(obj, default=_json_default, separators=(",", ":"))
    return m


def from_msg(msg: String):
    try:
        return json.loads(msg.data)
    except (json.JSONDecodeError, TypeError):
        return None


def _json_default(o):
    if hasattr(o, "value"):
        return o.value
    if isinstance(o, (set, tuple)):
        return list(o)
    return str(o)


def load_config(node: Node) -> Config:
    cfg_path = node.declare_parameter("config", "").value or None
    scen_path = node.declare_parameter("scenario", "").value or None
    if scen_path and not os.path.isabs(scen_path):
        scen_path = os.path.join(Config.load(cfg_path).root, scen_path)
    return Config.load(cfg_path, scen_path)


class Clock:
    """Seconds (float) from the node clock, so wall time and sim time are interchangeable."""

    def __init__(self, node: Node):
        self.node = node

    def now(self) -> float:
        return self.node.get_clock().now().nanoseconds * 1e-9


class PacketFactory:
    def __init__(self, src: str):
        self.src = src
        self.seq = 0

    def make(self, dst: str, ptype: str, payload: dict, t: float) -> dict:
        self.seq += 1
        return {"id": f"{self.src}-{self.seq}", "src": self.src, "dst": dst, "type": ptype, "seq": self.seq,
                "t_sent": t, "payload": payload}


def guarded(node: Node, fn):
    """Wrap a timer/subscription callback: an exception is logged with its traceback and
    published as a SOFTWARE_ERROR event (visible on the console and counted in the
    report) instead of silently killing the node."""
    import traceback

    seen: set = set()

    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:  # noqa: BLE001
            tb = traceback.format_exc()
            node.get_logger().error(f"exception in {fn.__name__}: {exc}\n{tb}")
            key = (fn.__name__, type(exc).__name__, str(exc)[:80])
            if key not in seen:
                seen.add(key)
                try:
                    ev = getattr(node, "ev", None)
                    if ev is not None:
                        ev.emit(node.get_clock().now().nanoseconds * 1e-9, "SOFTWARE_ERROR",
                                f"{node.get_name()}.{fn.__name__}: {type(exc).__name__}: {exc}", None,
                                traceback=tb[-2000:])
                except Exception:
                    pass
    wrapper.__name__ = getattr(fn, "__name__", "callback")
    return wrapper


class GuardedNode(Node):
    """rclpy Node whose timer and subscription callbacks are all wrapped by `guarded`."""

    def create_timer(self, timer_period_sec, callback, *args, **kwargs):
        return super().create_timer(timer_period_sec, guarded(self, callback), *args, **kwargs)

    def create_subscription(self, msg_type, topic, callback, qos_profile, *args, **kwargs):
        return super().create_subscription(msg_type, topic, guarded(self, callback), qos_profile, *args, **kwargs)


class EventPublisher:
    def __init__(self, node: Node, source: str):
        self.pub = node.create_publisher(String, "/events", QOS_STREAM)
        self.source = source
        self.mission_t0: float | None = None

    def emit(self, t: float, event_type: str, message: str, uav_id: str | None = None, **details) -> dict:
        mt = None if self.mission_t0 is None else t - self.mission_t0
        ev = make_event(t, event_type, message, uav_id, self.source, mt, details=details)
        self.pub.publish(to_msg(ev))
        return ev
