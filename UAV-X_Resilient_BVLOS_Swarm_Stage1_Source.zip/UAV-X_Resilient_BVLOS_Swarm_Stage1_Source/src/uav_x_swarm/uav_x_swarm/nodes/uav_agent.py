"""Onboard UAV agent (one per vehicle, namespace /uavN).

Represents the companion computer of one UAV:
  * flies its own PX4 instance through MAVLink offboard control (px4/link.py),
  * executes tasks received from the GCS over the *emulated radio network*,
  * runs onboard autonomy that must work without the GCS: battery model and
    return-to-home, geofence clamping, collision avoidance, lost-link procedure
    with distributed relay election, store-and-forward survey reports,
  * publishes the onboard topics /uavN/{state,position,velocity,battery,role,mission_status,radio}.

Radio traffic (telemetry, reports, beacons, command ACKs) goes only through
/net/tx -> comm_manager -> /net/rx/<dst>, so link loss, latency and range
limits in the emulator really affect what the GCS knows and can command.
"""
from __future__ import annotations

import math

import rclpy
from geometry_msgs.msg import PointStamped, Vector3Stamped
from rclpy.node import Node
from sensor_msgs.msg import BatteryState
from std_msgs.msg import String

from ..core.battery import BatteryModel, BatteryParams, BatteryPolicy
from ..core.collision import avoidance_velocity
from ..core.geofence import Geofence
from ..core.geometry import add, clamp_norm, dist, dist2d, norm, scale, sub, unit
from ..core.lostlink import PeerInfo, lost_link_action
from ..core.survey import orbit_waypoints
from ..core.types import FlightState as FS
from ..core.types import Role
from ..px4.link import PX4Link, enu_to_ned, ned_to_enu
from .common import (GuardedNode, QOS_LATCHED, QOS_STATE, QOS_STREAM, Clock, EventPublisher, PacketFactory, from_msg,
                     load_config, to_msg)

LANDED_ON_GROUND = 1
LANDED_IN_AIR = 2


class UavAgent(GuardedNode):
    def __init__(self):
        super().__init__("uav_agent")
        self.cfg = cfg = load_config(self)
        self.uid = self.declare_parameter("uav_id", "uav1").value
        self.idx = cfg.uav_index(self.uid)
        self.clock = Clock(self)
        self.ev = EventPublisher(self, self.uid)
        self.pf = PacketFactory(self.uid)

        # ---------------------------------------------------------- vehicle link
        inst = self.idx - 1
        self.port = 14540 + inst
        self.link = PX4Link(self.port, self.idx, logger=self.get_logger())
        hx, hy = cfg.home_positions()[self.uid]
        self.home = (hx, hy, 0.0)
        self.alt = cfg.cruise_altitude(self.uid)

        # ---------------------------------------------------------- parameters
        fl = cfg["flight"]
        self.cruise = float(fl["cruise_speed_mps"])
        self.survey_speed = float(fl["survey_speed_mps"])
        self.arrival = float(fl["arrival_radius_m"])
        self.alt_tol = float(fl["altitude_tolerance_m"])
        self.survey_r = float(fl["survey_radius_m"])
        self.survey_n = int(fl["survey_points"])
        self.max_lead = float(fl["max_lead_m"])
        self.fence = Geofence.from_cfg(cfg["safety.geofence"])
        sf = cfg["safety"]
        self.av_radius = float(sf["avoidance_radius_m"])
        self.min_safe = float(sf["minimum_safe_distance_m"])
        self.av_gain = float(sf["avoidance_gain"])
        cm = cfg["communication"]
        self.lost_timeout = float(cm["lost_link_timeout_s"])
        self.lost_rth_after = float(cm.get("lost_link_rth_s", 90.0))
        self.report_retry = float(cm["report_retry_s"])
        self.gcs_range = float(cm["gcs_range_m"])
        self.bparams = BatteryParams.from_cfg(cfg["battery"])
        self.battery = BatteryModel(self.bparams, cfg.initial_battery(self.uid))
        self.bpolicy = BatteryPolicy(self.bparams, self.cruise)
        self.relay_min_batt = float(cfg["relay.min_battery_pct"])
        gcs = cfg.gcs_position()
        self.gcs_pos = gcs
        # default relay point until the GCS sends one: toward the PoI centroid at 75 % of GCS range
        pois = [p for p in cfg.pois() if p.get("initial", True)]
        cx = sum(p["position"][0] for p in pois) / max(1, len(pois))
        cy = sum(p["position"][1] for p in pois) / max(1, len(pois))
        d = math.hypot(cx - gcs[0], cy - gcs[1]) or 1.0
        r = 0.75 * self.gcs_range
        self.relay_point = (gcs[0] + (cx - gcs[0]) / d * r, gcs[1] + (cy - gcs[1]) / d * r, self.alt)

        # ---------------------------------------------------------- state
        self.fs = FS.BOOT
        self.role = Role.IDLE
        self.tasks: list[dict] = []           # ordered task queue from the GCS
        self.current: dict | None = None      # task being executed
        self.survey_wps: list = []
        self.wp_idx = 0
        self.survey_phase = None              # "approach" | "orbit"
        self.survey_t0 = None
        self.images = 0
        self.completed: list[str] = []
        self.outbox: dict[str, dict] = {}     # poi_id -> report (awaiting GCS ACK)
        self.outbox_sent: dict[str, float] = {}
        self.manual_goal = None
        self.manual_until = None
        self.idle_since = None
        self.idle_pos = None
        self.rth_reason = None
        self.carrot = None
        self.last_ctrl = None
        self.arm_attempt_t = 0.0
        self.land_cmd_t = 0.0
        self.failed = False
        self.radio_up = True
        self.mission_started = False
        self.last_gcs_rx = None
        self.plan_version = -1
        self.acked_cmds: set = set()
        self.neighbors: dict[str, dict] = {}
        self.daa: dict[str, dict] = {}        # other UAVs' states (detect-and-avoid sensing)
        self.avoid_active: list = []
        self.avoid_seen: dict[int, float] = {}
        self.lost_action = None
        self.bridge = False
        self.self_elected = False
        self.batt_warned = False
        self.pos = self.home
        self.vel = (0.0, 0.0, 0.0)
        self.airborne = False
        self.geofence_status = "INSIDE"
        self.speed_limit = self.cruise

        # ---------------------------------------------------------- ROS I/O
        self.pub_state = self.create_publisher(String, "state", QOS_STATE)
        self.pub_pos = self.create_publisher(PointStamped, "position", QOS_STATE)
        self.pub_vel = self.create_publisher(Vector3Stamped, "velocity", QOS_STATE)
        self.pub_batt = self.create_publisher(BatteryState, "battery", QOS_STATE)
        self.pub_role = self.create_publisher(String, "role", QOS_LATCHED)
        self.pub_mstat = self.create_publisher(String, "mission_status", QOS_STATE)
        self.pub_radio = self.create_publisher(String, "radio", QOS_LATCHED)
        self.pub_tx = self.create_publisher(String, "/net/tx", QOS_STREAM)
        self.create_subscription(String, f"/net/rx/{self.uid}", self.on_packet, QOS_STREAM)
        self.create_subscription(String, "inject", self.on_inject, QOS_STREAM)
        self.create_subscription(String, "/mission/start", self.on_mission_start, QOS_LATCHED)
        for other in cfg.uav_ids():
            if other != self.uid:
                self.create_subscription(String, f"/{other}/state",
                                         lambda m, o=other: self.on_daa(o, m), QOS_STATE)
        self.pub_radio.publish(to_msg("UP"))
        self._last_role_pub = None

        rate = float(fl["setpoint_rate_hz"])
        self.create_timer(1.0 / rate, self.control_step)
        self.create_timer(1.0 / float(cm["telemetry_rate_hz"]), self.send_telemetry)
        self.create_timer(1.0 / float(cm["beacon_rate_hz"]), self.send_beacon)
        self.create_timer(0.1, self.publish_local)
        self.create_timer(1.0, self.slow_step)
        self.get_logger().info(f"{self.uid}: PX4 sysid {self.idx} on udp {self.port}, home {self.home[:2]}, "
                               f"cruise altitude {self.alt} m")

    # ================================================================= helpers
    def now(self) -> float:
        return self.clock.now()

    def event(self, etype: str, message: str, **details) -> None:
        self.ev.emit(self.now(), etype, message, self.uid, **details)

    def send(self, dst: str, ptype: str, payload: dict) -> None:
        if not self.radio_up or self.failed:
            return
        self.pub_tx.publish(to_msg(self.pf.make(dst, ptype, payload, self.now())))

    def gcs_contact_age(self) -> float:
        return math.inf if self.last_gcs_rx is None else self.now() - self.last_gcs_rx

    def label(self) -> str:
        return self.uid.upper()

    # ================================================================= radio rx
    def on_mission_start(self, msg: String) -> None:
        d = from_msg(msg) or {}
        if d.get("t0") is not None:
            self.ev.mission_t0 = float(d["t0"])

    def on_packet(self, msg: String) -> None:
        if self.failed or not self.radio_up:
            return
        pkt = from_msg(msg)
        if not pkt:
            return
        ptype, src, pl = pkt.get("type"), pkt.get("src"), pkt.get("payload", {})
        if src == "gcs":
            self.last_gcs_rx = self.now()
            if not self.mission_started:
                self.mission_started = True
        if ptype == "BEACON":
            self.neighbors[src] = {**pl, "t": self.now()}
        elif ptype == "ACK" and pl.get("poi_id"):
            if self.outbox.pop(pl["poi_id"], None) is not None:
                self.event("REPORT_ACKED", f"{self.label()} survey report {pl['poi_id']} acknowledged by GCS",
                           poi_id=pl["poi_id"])
        elif ptype == "CMD":
            self.on_command(pl)

    def on_command(self, pl: dict) -> None:
        cid = pl.get("cmd_id")
        self.send("gcs", "ACK", {"cmd_id": cid})
        if cid in self.acked_cmds:
            return
        self.acked_cmds.add(cid)
        cmd = pl.get("cmd")
        if cmd == "TAKEOFF":
            if self.fs == FS.READY:
                self.fs = FS.ARMING
                self.carrot = None
                self.event("TAKEOFF_COMMANDED", f"{self.label()} takeoff commanded (target {self.alt:.0f} m)")
        elif cmd == "ASSIGN":
            ver = int(pl.get("version", 0))
            if ver <= self.plan_version:
                return
            self.plan_version = ver
            self.apply_assignment(pl)
        elif cmd == "RTH":
            self.start_rth(pl.get("reason", "GCS_COMMAND"))
        elif cmd == "LAND":
            self.start_landing("GCS_COMMAND")
        elif cmd == "HOLD":
            self.manual_goal = self.pos
        elif cmd == "GOTO":
            p = pl["position"]
            self.manual_goal = (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else self.alt)

    def apply_assignment(self, pl: dict) -> None:
        if self.role in (Role.RETURN_HOME, Role.FAILED, Role.EMERGENCY):
            return
        new_role = Role(pl.get("role", self.role.value))
        if new_role in (Role.RETURN_HOME, Role.FAILED, Role.EMERGENCY):
            return          # return-home is only accepted as an explicit RTH command
        if pl.get("relay_point"):
            rp = pl["relay_point"]
            self.relay_point = (float(rp[0]), float(rp[1]), self.alt)
        tasks = pl.get("tasks", [])
        ids = [t["poi_id"] for t in tasks]
        if self.current and self.current["poi_id"] not in ids:
            self.event("TASK_ABORTED", f"{self.label()} aborts {self.current['poi_id']} (re-planned by GCS)",
                       poi_id=self.current["poi_id"])
            self.current = None
            self.survey_phase = None
        elif self.current and ids and ids[0] != self.current["poi_id"]:
            # a higher-priority task was put in front: pre-empt the running survey
            self.event("TASK_PREEMPTED_ONBOARD", f"{self.label()} pre-empts {self.current['poi_id']} for {ids[0]}",
                       poi_id=self.current["poi_id"], new=ids[0])
            self.current = None
            self.survey_phase = None
        self.tasks = [t for t in tasks if t["poi_id"] not in self.completed]
        if self.current:
            self.tasks = [t for t in self.tasks if t["poi_id"] != self.current["poi_id"]]
        self.manual_goal = None
        if new_role != self.role:
            self.event("ROLE_CHANGED", f"{self.label()} role {self.role.value} -> {new_role.value}",
                       old=self.role.value, new=new_role.value)
            self.role = new_role
        if self.role != Role.RELAY:
            self.bridge = False
            self.self_elected = False
        if self.role == Role.RELAY and self.current:
            self.current = None
            self.survey_phase = None

    # ================================================================= sensing / injection
    def on_daa(self, other: str, msg: String) -> None:
        d = from_msg(msg)
        if d:
            d["t_rx"] = self.now()
            self.daa[other] = d

    def on_inject(self, msg: String) -> None:
        d = from_msg(msg) or {}
        typ = d.get("type")
        if typ == "UAV_FAILURE":
            self.fail(d.get("reason", "INJECTED_FAILURE"))
        elif typ == "BATTERY_DEGRADATION":
            before = self.battery.pct
            self.battery.degrade(d.get("drain_multiplier"), d.get("drop_pct"), d.get("set_pct"))
            self.event("BATTERY_FAULT", f"{self.label()} battery fault injected: {before:.1f}% -> "
                       f"{self.battery.pct:.1f}%, drain x{self.battery.multiplier:g}",
                       before=round(before, 2), after=round(self.battery.pct, 2), multiplier=self.battery.multiplier)
        elif typ == "RETURN_HOME":
            self.start_rth(d.get("reason", "MANUAL"))
        elif typ == "GOTO":
            p = d["position"]
            self.manual_goal = (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else self.alt)
            self.manual_until = self.now() + float(d["duration"]) if d.get("duration") else None
            clamped = self.fence.clamp(self.manual_goal)
            note = "" if clamped == self.manual_goal else \
                f" -> clamped to {tuple(round(v, 1) for v in clamped)} (outside geofence)"
            self.event("MANUAL_GOTO", f"{self.label()} operator goto {tuple(round(v, 1) for v in self.manual_goal)}"
                       f"{note}", goal=self.manual_goal, clamped=clamped, duration=d.get("duration"))

    def fail(self, reason: str) -> None:
        if self.failed:
            return
        self.failed = True
        self.radio_up = False
        self.pub_radio.publish(to_msg("DOWN"))
        self.role = Role.FAILED
        self.fs = FS.FAILED
        self.link.land()
        self.land_cmd_t = self.now()
        self.event("FAILURE_ONSET", f"{self.label()} FAILURE ({reason}): radio silent, emergency descent",
                   reason=reason)

    # ================================================================= high-level actions
    def start_rth(self, reason: str) -> None:
        if self.failed or self.fs in (FS.LANDING, FS.LANDED, FS.READY, FS.BOOT) or self.role == Role.RETURN_HOME:
            return
        self.rth_reason = reason
        prev_role = self.role
        self.role = Role.RETURN_HOME
        self.fs = FS.RETURN_HOME
        self.manual_goal = None
        self.bridge = False
        self.self_elected = False
        self.lost_action = None
        if self.current:
            self.current = None
            self.survey_phase = None
        self.event("RTH_STARTED", f"{self.label()} returning home ({reason}), battery {self.battery.pct:.1f}%, "
                   f"was {prev_role.value}", reason=reason, battery=round(self.battery.pct, 2), prev_role=prev_role.value)

    def start_landing(self, reason: str) -> None:
        if self.fs in (FS.LANDING, FS.LANDED) or self.failed:
            return
        self.fs = FS.LANDING
        self.link.land()
        self.land_cmd_t = self.now()
        self.event("LANDING", f"{self.label()} landing ({reason})", reason=reason)

    # ================================================================= control loop (20 Hz)
    def control_step(self) -> None:
        now = self.now()
        dt = 0.05 if self.last_ctrl is None else max(0.0, min(0.5, now - self.last_ctrl))
        self.last_ctrl = now
        tel = self.link.telemetry()
        if not self.link.connected():
            return
        e, n, u = ned_to_enu(*tel.ned)
        self.pos = (self.home[0] + e, self.home[1] + n, u)
        ve, vn, vu = ned_to_enu(*tel.ned_vel)
        self.vel = (ve, vn, vu)
        self.airborne = tel.landed_state == LANDED_IN_AIR or (tel.armed and self.pos[2] > 0.8)
        speed = norm(self.vel)
        self.battery.update(dt, self.airborne, speed, relay=(self.role == Role.RELAY),
                            surveying=(self.fs == FS.SURVEY))
        self.geofence_status = self.fence.status(self.pos) if self.airborne else "INSIDE"
        if self.failed:
            if self.fs == FS.FAILED and not tel.armed and tel.landed_state == LANDED_ON_GROUND:
                pass
            elif now - self.land_cmd_t > 3.0 and tel.mode_name != "AUTO.LAND" and tel.armed:
                self.link.land()
                self.land_cmd_t = now
            return
        self.battery_checks()

        fs = self.fs
        if fs == FS.BOOT:
            if tel.local_valid and tel.prearm_ok:
                self.fs = FS.READY
                self.event("UAV_READY", f"{self.label()} ready (PX4 sysid {self.idx}, udp {self.port})")
            return
        if fs == FS.READY:
            return
        if fs == FS.ARMING:
            if self.carrot is None:
                self.carrot = self.pos
            self.send_setpoint(self.carrot, (0.0, 0.0, 0.0))
            if tel.armed and tel.is_offboard:
                self.fs = FS.TAKEOFF
                self.event("TAKEOFF", f"{self.label()} armed in OFFBOARD, climbing to {self.alt:.0f} m")
            elif now - self.arm_attempt_t > 0.5:
                self.arm_attempt_t = now
                if not tel.is_offboard:
                    self.link.set_offboard()
                else:
                    self.link.arm()
            return
        if fs == FS.TAKEOFF:
            goal = (self.home[0], self.home[1], self.alt)
            self.navigate(goal, self.cruise, dt, avoid=False)
            if abs(self.pos[2] - self.alt) < self.alt_tol:
                self.fs = FS.HOLD
                self.event("AIRBORNE", f"{self.label()} reached cruise altitude {self.alt:.0f} m")
            return
        if fs == FS.LANDING:
            if tel.landed_state == LANDED_ON_GROUND and not tel.armed:
                self.fs = FS.LANDED
                self.event("LANDED", f"{self.label()} landed at ({self.pos[0]:.1f}, {self.pos[1]:.1f}), "
                           f"battery {self.battery.pct:.1f}%", position=self.pos, battery=round(self.battery.pct, 2),
                           at_home=dist2d(self.pos, self.home) < 5.0)
            elif now - self.land_cmd_t > 3.0 and tel.mode_name != "AUTO.LAND":
                self.link.land()
                self.land_cmd_t = now
            return
        if fs == FS.LANDED:
            return
        self.airborne_logic(dt)

    def airborne_logic(self, dt: float) -> None:
        # ---- return home
        if self.role == Role.RETURN_HOME:
            goal = (self.home[0], self.home[1], self.alt)
            self.fs = FS.RETURN_HOME
            self.navigate(goal, self.cruise, dt)
            # settle over the pad before descending, so the vehicle lands on it
            if dist2d(self.pos, goal) < 1.0 and norm(self.vel) < 0.6:
                self.start_landing(f"home reached ({self.rth_reason})")
            return
        # ---- manual goal (scenario / operator)
        if self.manual_goal is not None and self.manual_until is not None and self.now() >= self.manual_until:
            self.event("MANUAL_GOTO_END", f"{self.label()} operator goto finished, resuming mission")
            self.manual_goal = None
            self.manual_until = None
            self.carrot = None
        if self.manual_goal is not None:
            self.fs = FS.TRANSIT
            self.navigate(self.manual_goal, self.cruise, dt)
            return
        # ---- lost link procedures
        if self.lost_action in ("BRIDGE", "RECONNECT"):
            goal = self.lost_goal()
            self.fs = FS.RELAY_STATION if dist2d(self.pos, goal) < self.arrival else FS.TRANSIT
            self.navigate(goal, self.cruise, dt)
            return
        # ---- relay (assigned by the GCS, or self-elected during a partition until the GCS re-plans)
        if self.role == Role.RELAY or self.self_elected:
            goal = (self.relay_point[0], self.relay_point[1], self.alt)
            self.navigate(goal, self.cruise, dt)
            self.fs = FS.RELAY_STATION if dist2d(self.pos, goal) < self.arrival * 2 else FS.TRANSIT
            return
        # ---- isolated: the survey in progress is finished -> go back into coverage
        if self.lost_action == "CONTINUE_CURRENT" and self.current is None:
            self.lost_action = "RECONNECT"
            self.event("LOST_LINK", f"{self.label()} survey finished while isolated -> RECONNECT: "
                       f"flying back into coverage", action="RECONNECT")
            return
        # ---- survey tasks
        if self.current is not None or self.tasks:
            self.idle_since = None
        if self.current is None and self.tasks and self.role in (Role.SURVEY, Role.SURVEY_RELAY, Role.IDLE):
            self.current = self.tasks.pop(0)
            c = self.current["position"]
            self.survey_wps = orbit_waypoints(c, self.survey_r, self.alt, self.survey_n, self.pos)
            self.survey_phase = "approach"
            self.wp_idx = 0
            self.images = 0
            self.event("TASK_STARTED", f"{self.label()} heading to {self.current['poi_id']} "
                       f"({self.current.get('priority', '')})", poi_id=self.current["poi_id"])
        if self.current is not None:
            self.survey_step(dt)
            return
        # ---- nothing to do: after a short hold, wait at a standby point inside coverage
        # (between the GCS and the relay point, offset per UAV), ready for new tasks
        self.fs = FS.HOLD
        if self.idle_since is None:
            self.idle_since = self.now()
            self.idle_pos = self.pos
        if self.now() - self.idle_since > 10.0:
            goal = self.standby_point()
        else:
            goal = (self.idle_pos[0], self.idle_pos[1], self.alt)
        self.navigate(goal, self.cruise, dt)

    def survey_step(self, dt: float) -> None:
        if self.survey_phase == "approach":
            self.fs = FS.TRANSIT
            goal = self.survey_wps[0]
            self.navigate(goal, self.cruise, dt)
            if dist(self.pos, goal) < self.arrival * 1.5:
                self.survey_phase = "orbit"
                self.wp_idx = 1
                self.survey_t0 = self.now()
                self.event("SURVEY_STARTED", f"{self.label()} surveying {self.current['poi_id']}",
                           poi_id=self.current["poi_id"])
                self.send("gcs", "EVENT", {"event": "SURVEY_STARTED", "poi_id": self.current["poi_id"]})
            return
        self.fs = FS.SURVEY
        goal = self.survey_wps[self.wp_idx]
        self.navigate(goal, self.survey_speed, dt, stop_at_goal=False)
        if dist2d(self.pos, goal) < self.arrival + 1.0:
            self.wp_idx += 1
            self.images += 1
            if self.wp_idx >= len(self.survey_wps):
                self.finish_survey()

    def finish_survey(self) -> None:
        poi = self.current["poi_id"]
        dur = self.now() - (self.survey_t0 or self.now())
        report = {
            "uav_id": self.uid, "poi_id": poi, "timestamp": self.now(),
            "position": [round(v, 2) for v in self.pos], "status": "SURVEYED",
            "data_collected": {"images": self.images, "coverage_pct": 100.0,
                               "data_mb": round(self.images * 4.2, 1), "survey_duration_s": round(dur, 1),
                               "orbit_radius_m": self.survey_r},
            "battery_pct": round(self.battery.pct, 2),
        }
        self.completed.append(poi)
        self.outbox[poi] = report
        self.outbox_sent[poi] = 0.0
        self.event("SURVEY_COMPLETE", f"{self.label()} completed survey of {poi}: {self.images} images, "
                   f"{dur:.0f} s", poi_id=poi, images=self.images)
        self.current = None
        self.survey_phase = None
        self.flush_outbox(force=True)

    # ================================================================= navigation
    def navigate(self, goal, speed: float, dt: float, avoid: bool = True, stop_at_goal: bool = True) -> None:
        goal = self.fence.clamp(goal)
        to_goal = sub(goal, self.pos)
        d = norm(to_goal)
        v_nom = scale(unit(to_goal), min(speed, 0.8 * d if stop_at_goal else speed))
        v_nom = (v_nom[0], v_nom[1], max(-2.0, min(2.5, v_nom[2])))
        v_av = (0.0, 0.0, 0.0)
        if avoid and self.airborne:
            neigh = []
            now = self.now()
            for other, s in self.daa.items():
                if now - s.get("t_rx", 0) > 1.5 or not s.get("airborne"):
                    continue
                neigh.append((self.cfg.uav_index(other), tuple(s["position"]), tuple(s.get("velocity", (0, 0, 0)))))
            v_av, active = avoidance_velocity(self.idx, self.pos, self.vel, neigh, self.av_radius, self.min_safe,
                                              self.av_gain)
            # one event per encounter: a neighbour must have been clear for 5 s before it counts again
            new = [i for i in active if now - self.avoid_seen.get(i, -1e9) > 5.0]
            for i in active:
                self.avoid_seen[i] = now
            if new:
                others = [self.cfg.uav_ids()[i - 1] for i in new]
                sep = min(dist(self.pos, tuple(self.daa[o]["position"])) for o in others)
                self.event("AVOIDANCE_ACTIVE", f"{self.label()} collision avoidance: {', '.join(o.upper() for o in others)} "
                           f"at {sep:.1f} m", neighbours=others, separation=round(sep, 2))
            self.avoid_active = active
        v = clamp_norm(add(v_nom, v_av), max(speed, self.av_gain) + 1.0)
        if self.carrot is None or dist(self.carrot, self.pos) > 3 * self.max_lead:
            self.carrot = self.pos
        if stop_at_goal and d < self.arrival and norm(v_av) < 1e-3:
            self.carrot = goal
            v = (0.0, 0.0, 0.0)
        else:
            self.carrot = add(self.carrot, scale(v, dt))
            lead = sub(self.carrot, self.pos)
            if norm(lead) > self.max_lead:
                self.carrot = add(self.pos, scale(unit(lead), self.max_lead))
        self.carrot = self.fence.clamp(self.carrot)
        if self.fs not in (FS.TAKEOFF,) and self.carrot[2] < 5.0:
            self.carrot = (self.carrot[0], self.carrot[1], 5.0)
        self.send_setpoint(self.carrot, v)

    def send_setpoint(self, p_world, v_world) -> None:
        n, e, d = enu_to_ned(p_world[0] - self.home[0], p_world[1] - self.home[1], p_world[2])
        vn, ve, vd = enu_to_ned(*v_world)
        self.link.send_setpoint_ned(n, e, d, vn, ve, vd, yaw=float("nan"), use_velocity=True)

    def standby_point(self):
        g, rp = self.gcs_pos, self.relay_point
        vx, vy = rp[0] - g[0], rp[1] - g[1]
        d = math.hypot(vx, vy) or 1.0
        ux, uy = vx / d, vy / d
        back = min(0.8 * d, max(0.0, d - 50.0))           # 50 m on the GCS side of the relay point
        lateral = (self.idx - (self.cfg.num_uavs + 1) / 2.0) * 25.0
        return self.fence.clamp((g[0] + ux * back - uy * lateral, g[1] + uy * back + ux * lateral, self.alt))

    def lost_goal(self):
        if self.role == Role.RELAY and not self.bridge:
            # move toward the GCS until well inside its range
            g = self.gcs_pos
            vec = (self.pos[0] - g[0], self.pos[1] - g[1])
            dd = math.hypot(*vec) or 1.0
            r = 0.6 * self.gcs_range
            return (g[0] + vec[0] / dd * r, g[1] + vec[1] / dd * r, self.alt)
        return (self.relay_point[0], self.relay_point[1], self.alt)

    # ================================================================= battery / lost link (1 Hz)
    def battery_checks(self) -> None:
        if not self.airborne or self.fs in (FS.LANDING, FS.LANDED):
            return
        pct = self.battery.pct
        if pct <= self.bparams.critical and self.role != Role.EMERGENCY:
            self.role = Role.EMERGENCY
            self.event("BATTERY_CRITICAL", f"{self.label()} battery CRITICAL {pct:.1f}%: emergency landing",
                       battery=round(pct, 2))
            self.start_landing("battery critical")
            return
        thr = self.bpolicy.rth_threshold(dist2d(self.pos, self.home), self.battery.multiplier)
        if pct <= thr and self.role != Role.RETURN_HOME:
            self.event("BATTERY_RTH", f"{self.label()} battery {pct:.1f}% <= RTH threshold {thr:.1f}%",
                       battery=round(pct, 2), threshold=round(thr, 2))
            self.start_rth("LOW_BATTERY")
            return
        if pct <= self.bparams.warning and not self.batt_warned:
            self.batt_warned = True
            self.event("BATTERY_WARNING", f"{self.label()} battery warning {pct:.1f}%", battery=round(pct, 2))

    def slow_step(self) -> None:
        self.flush_outbox()
        if self.failed or not self.mission_started or not self.airborne:
            return
        if self.role in (Role.RETURN_HOME, Role.EMERGENCY) or self.fs in (FS.LANDING, FS.LANDED):
            self.lost_action = None
            return
        lost_for = self.gcs_contact_age()
        if lost_for < self.lost_timeout:
            if self.lost_action is not None:
                self.event("LINK_RESTORED", f"{self.label()} GCS link restored after lost-link ({self.lost_action})",
                           action=self.lost_action)
                if self.lost_action == "BRIDGE":
                    self.self_elected = True
                self.lost_action = None
            return
        now = self.now()
        peers = []
        for pid, b in self.neighbors.items():
            peers.append(PeerInfo(pid, int(b.get("idx", 99)), tuple(b.get("pos", (0, 0, 0))),
                                  float(b.get("battery", 0)), bool(b.get("gcs_ok")), bool(b.get("eligible")),
                                  now - b.get("t", 0)))
        me = PeerInfo(self.uid, self.idx, self.pos, self.battery.pct, False, self.relay_eligible(), 0.0)
        action, why = lost_link_action(is_relay=(self.role == Role.RELAY and not self.bridge), me=me, peers=peers,
                                       relay_point=self.relay_point, gcs_range=self.gcs_range,
                                       rth_pct=self.bparams.rth, lost_for=lost_for, rth_after=self.lost_rth_after,
                                       has_tasks=bool(self.current or self.tasks),
                                       has_current=self.current is not None)
        if action != self.lost_action:
            self.event("LOST_LINK", f"{self.label()} no GCS contact for {lost_for:.0f}s -> {action}: {why}",
                       action=action, reason=why, lost_for=round(lost_for, 1))
            if action == "BRIDGE":
                self.bridge = True
                if self.current:
                    self.tasks.insert(0, self.current)
                    self.current = None
                    self.survey_phase = None
                self.event("PEER_RELAY_ELECTED", f"{self.label()} self-elected as bridge relay "
                           f"(peer election, no GCS contact)", relay_point=self.relay_point)
            if action == "RETURN":
                self.start_rth("LOST_LINK")
            self.lost_action = action if action != "RETURN" else None

    def relay_eligible(self) -> bool:
        return (not self.failed and self.role not in (Role.RETURN_HOME, Role.EMERGENCY)
                and self.battery.pct >= self.relay_min_batt)

    def flush_outbox(self, force: bool = False) -> None:
        now = self.now()
        for poi, rep in list(self.outbox.items()):
            if force or now - self.outbox_sent.get(poi, 0.0) >= self.report_retry:
                self.outbox_sent[poi] = now
                self.send("gcs", "REPORT", rep)

    # ================================================================= radio tx
    def reported_role(self) -> str:
        if self.bridge or self.self_elected:
            return Role.RELAY.value
        return self.role.value

    def send_telemetry(self) -> None:
        if self.failed or self.fs == FS.BOOT:
            return
        age = self.gcs_contact_age()
        self.send("gcs", "TELEMETRY", {
            "position": [round(v, 2) for v in self.pos], "velocity": [round(v, 2) for v in self.vel],
            "battery": round(self.battery.pct, 2), "role": self.reported_role(), "flight_state": self.fs.value,
            "airborne": self.airborne, "current_task": self.current["poi_id"] if self.current else None,
            "task_queue": [t["poi_id"] for t in self.tasks], "completed": list(self.completed),
            "outbox": list(self.outbox), "gcs_contact_age": None if math.isinf(age) else round(age, 2),
            "lost_link_action": self.lost_action, "self_elected_relay": self.bridge or self.self_elected,
            "neighbors": {k: round(self.now() - v["t"], 2) for k, v in self.neighbors.items()
                          if self.now() - v["t"] < 3.0},
            "relay_point": [round(v, 1) for v in self.relay_point], "geofence_status": self.geofence_status,
            "rth_reason": self.rth_reason, "plan_version": self.plan_version,
            "avoidance": [self.cfg.uav_ids()[i - 1] for i in self.avoid_active],
            "survey_progress": (self.wp_idx / max(1, len(self.survey_wps) - 1)) if self.survey_phase == "orbit" else 0.0,
        })

    def send_beacon(self) -> None:
        if self.failed or not self.airborne:
            return
        self.send("*", "BEACON", {"idx": self.idx, "pos": [round(v, 1) for v in self.pos],
                                  "battery": round(self.battery.pct, 1),
                                  "gcs_ok": self.gcs_contact_age() < min(3.0, self.lost_timeout / 2),
                                  "eligible": self.relay_eligible(), "role": self.reported_role()})

    # ================================================================= local topics (10 Hz)
    def publish_local(self) -> None:
        stamp = self.get_clock().now().to_msg()
        tel = self.link.telemetry()
        st = {
            "uav_id": self.uid, "position": [round(v, 3) for v in self.pos],
            "velocity": [round(v, 3) for v in self.vel], "battery": round(self.battery.pct, 3),
            "role": self.reported_role(), "flight_state": self.fs.value, "airborne": self.airborne,
            "armed": tel.armed, "px4_mode": tel.mode_name, "px4_connected": self.link.connected(),
            "current_task": self.current["poi_id"] if self.current else None,
            "task_queue": [t["poi_id"] for t in self.tasks], "completed": list(self.completed),
            "radio": "UP" if self.radio_up else "DOWN", "failed": self.failed,
            "geofence_status": self.geofence_status, "home": list(self.home),
            "gcs_contact_age": None if math.isinf(self.gcs_contact_age()) else round(self.gcs_contact_age(), 2),
            "lost_link_action": self.lost_action, "battery_multiplier": self.battery.multiplier,
            "avoidance": [self.cfg.uav_ids()[i - 1] for i in self.avoid_active],
        }
        self.pub_state.publish(to_msg(st))
        p = PointStamped()
        p.header.stamp = stamp
        p.header.frame_id = "world"
        p.point.x, p.point.y, p.point.z = self.pos
        self.pub_pos.publish(p)
        v = Vector3Stamped()
        v.header = p.header
        v.vector.x, v.vector.y, v.vector.z = self.vel
        self.pub_vel.publish(v)
        b = BatteryState()
        b.header = p.header
        b.percentage = float(self.battery.pct / 100.0)
        b.present = True
        b.power_supply_status = BatteryState.POWER_SUPPLY_STATUS_DISCHARGING if self.airborne else \
            BatteryState.POWER_SUPPLY_STATUS_NOT_CHARGING
        self.pub_batt.publish(b)
        role = self.reported_role()
        if role != self._last_role_pub:
            self.pub_role.publish(to_msg(role))
            self._last_role_pub = role
        self.pub_mstat.publish(to_msg({"current_task": st["current_task"], "queue": st["task_queue"],
                                       "completed": self.completed, "pending_reports": list(self.outbox),
                                       "flight_state": self.fs.value,
                                       "survey_phase": self.survey_phase}))


def main():
    rclpy.init()
    node = UavAgent()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.link.close()
        node.destroy_node()
        rclpy.try_shutdown()
