"""Lightweight web dashboard (Python standard library HTTP server + one static page).

GET /            -> dashboard/index.html
GET /api/state   -> JSON: swarm status (GCS view), network state, onboard UAV states,
                    live metrics, last 80 events
Open http://localhost:8080 (also works from the Windows browser under WSL2).
"""
from __future__ import annotations

import json
import os
import threading
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from .common import GuardedNode, QOS_STATE, QOS_STREAM, from_msg, load_config


class Dashboard(GuardedNode):
    def __init__(self):
        super().__init__("dashboard")
        self.cfg = cfg = load_config(self)
        self.port = int(self.declare_parameter("port", 8080).value)
        self.host = self.declare_parameter("host", "127.0.0.1").value
        self.static = os.path.join(cfg.root, "dashboard")
        self.lock = threading.Lock()
        self.data = {"status": {}, "network": {}, "uavs": {}, "metrics": {}, "events": deque(maxlen=80)}
        self.config_view = {
            "gcs": cfg.gcs_position(), "geofence": cfg["safety.geofence"], "homes": cfg.home_positions(),
            "pois": cfg.pois(), "uav_ids": cfg.uav_ids(),
            "ranges": {"gcs": cfg["communication.gcs_range_m"], "uav": cfg["communication.uav_range_m"]},
            "battery": {"warning": cfg["battery.warning_pct"], "rth": cfg["battery.rth_pct"]},
            "scenario": self.get_parameter("scenario").value,
        }
        self.create_subscription(String, "/swarm/status", lambda m: self.put("status", m), QOS_STATE)
        self.create_subscription(String, "/network/state", lambda m: self.put("network", m), QOS_STATE)
        self.create_subscription(String, "/metrics/live", lambda m: self.put("metrics", m), QOS_STATE)
        self.create_subscription(String, "/events", self.on_event, QOS_STREAM)
        for u in cfg.uav_ids():
            self.create_subscription(String, f"/{u}/state", lambda m, u=u: self.put_uav(u, m), QOS_STATE)
        node = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                if self.path.startswith("/api/state"):
                    body = json.dumps(node.snapshot(), default=str).encode()
                    self._send(200, "application/json", body)
                    return
                name = "index.html" if self.path in ("/", "/index.html") else None
                if name is None:
                    self._send(404, "text/plain", b"not found")
                    return
                with open(os.path.join(node.static, name), "rb") as f:
                    self._send(200, "text/html; charset=utf-8", f.read())

            def _send(self, code, ctype, body):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self.httpd = ThreadingHTTPServer((self.host, self.port), Handler)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        self.get_logger().info(f"dashboard at http://localhost:{self.port}")

    def put(self, key: str, msg: String) -> None:
        d = from_msg(msg)
        if d is not None:
            with self.lock:
                self.data[key] = d

    def put_uav(self, uid: str, msg: String) -> None:
        d = from_msg(msg)
        if d is not None:
            with self.lock:
                self.data["uavs"][uid] = d

    def on_event(self, msg: String) -> None:
        d = from_msg(msg)
        if d is not None:
            with self.lock:
                self.data["events"].append(d)

    def snapshot(self) -> dict:
        with self.lock:
            net = dict(self.data["network"])
            net.pop("counters", None)
            return {"config": self.config_view, "status": self.data["status"], "network": net,
                    "uavs": self.data["uavs"], "metrics": self.data["metrics"], "events": list(self.data["events"])}


def main():
    rclpy.init()
    node = Dashboard()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.httpd.shutdown()
        node.destroy_node()
        rclpy.try_shutdown()
