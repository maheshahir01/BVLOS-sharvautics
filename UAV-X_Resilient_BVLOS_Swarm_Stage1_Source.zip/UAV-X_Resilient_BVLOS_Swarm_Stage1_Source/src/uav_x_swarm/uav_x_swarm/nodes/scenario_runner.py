"""Scenario runner: fires the fault/event injections declared in a scenario YAML.

Injections go to the component that physically experiences them:
  UAV_FAILURE, BATTERY_DEGRADATION, RETURN_HOME, GOTO     -> /<uav>/inject   (the vehicle)
  COMM_DEGRADATION, COMM_OUTAGE, COMM_RESTORE, LATENCY,
  PACKET_LOSS                                             -> /network/inject (the radio channel)
  NEW_PRIORITY_POI                                        -> /gcs/inject     (an external emergency report)
The swarm software is never told directly what was injected: it must detect it.

COMM_DEGRADATION supports a ramp: `ramp: [[0, 0.05], [15, 0.2], [30, 0.5], [45, 1.0]]`
(seconds after trigger, packet loss) applied to the target resolved at trigger time.
"""
from __future__ import annotations

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from ..core.scenario import Scenario
from .common import GuardedNode, QOS_LATCHED, QOS_STATE, QOS_STREAM, Clock, EventPublisher, from_msg, load_config, to_msg

UAV_TYPES = {"UAV_FAILURE", "BATTERY_DEGRADATION", "RETURN_HOME", "GOTO"}
NET_TYPES = {"COMM_DEGRADATION", "COMM_OUTAGE", "COMM_RESTORE", "LATENCY", "PACKET_LOSS"}


class ScenarioRunner(GuardedNode):
    def __init__(self):
        super().__init__("scenario_runner")
        self.cfg = load_config(self)
        path = self.get_parameter("scenario").value
        self.clock = Clock(self)
        self.ev = EventPublisher(self, "scenario")
        self.scn = Scenario.load(self.cfg.path(path)) if path else Scenario("none", "")
        self.status: dict = {}
        self.ramps: list[dict] = []
        self.pub_net = self.create_publisher(String, "/network/inject", QOS_STREAM)
        self.pub_gcs = self.create_publisher(String, "/gcs/inject", QOS_STREAM)
        self.pub_uav = {u: self.create_publisher(String, f"/{u}/inject", QOS_STREAM) for u in self.cfg.uav_ids()}
        self.create_subscription(String, "/swarm/status", self.on_status, QOS_STATE)
        self.create_subscription(String, "/mission/start", self.on_start, QOS_LATCHED)
        self.create_timer(0.5, self.tick)
        self.get_logger().info(f"scenario '{self.scn.name}': {len(self.scn.events)} events")

    def now(self) -> float:
        return self.clock.now()

    def on_start(self, msg):
        d = from_msg(msg) or {}
        if d.get("t0") is not None:
            self.ev.mission_t0 = float(d["t0"])

    def on_status(self, msg):
        self.status = from_msg(msg) or {}

    def tick(self) -> None:
        st = self.status
        if not st or st.get("t0") is None or st.get("phase") in ("MISSION_COMPLETE", "MISSION_FAILED"):
            return
        mt = self.now() - float(st["t0"])
        for e in self.scn.due(mt, st):
            targets = Scenario.resolve_target(e.target, st)
            if e.target and not targets:
                continue       # e.g. no relay assigned yet: try again next tick
            e.fired, e.fired_at, e.resolved_target = True, mt, ",".join(targets)
            self.fire(e, targets, mt)
        for r in list(self.ramps):
            while r["steps"] and mt >= r["t"] + r["steps"][0][0]:
                off, loss = r["steps"].pop(0)
                self.pub_net.publish(to_msg({"type": "COMM_DEGRADATION", "targets": r["targets"], "packet_loss": loss}))
                self.ev.emit(self.now(), "SCENARIO_INJECT", f"Injecting packet loss {loss:.0%} on "
                             f"{', '.join(t.upper() for t in r['targets'])} ({r['id']} ramp +{off:.0f}s)", r["targets"][0],
                             event_id=r["id"], inject_type="COMM_DEGRADATION_STEP", targets=r["targets"],
                             packet_loss=loss)
            if not r["steps"]:
                self.ramps.remove(r)

    def fire(self, e, targets: list[str], mt: float) -> None:
        p = dict(e.params)
        desc = {k: v for k, v in p.items() if k not in ("ramp", "poi_def")}
        who = ", ".join(t.upper() for t in targets) if targets else "swarm"
        if e.target and str(e.target).upper() in ("RELAY", "SURVEY"):
            who += f" (current {str(e.target).upper()})"
        self.ev.emit(self.now(), "SCENARIO_INJECT", f"Injecting {e.type} on {who} {desc if desc else ''}".strip(),
                     targets[0] if targets else None, event_id=e.id, inject_type=e.type, targets=targets,
                     params=desc)
        if e.type in UAV_TYPES:
            for t in targets:
                self.pub_uav[t].publish(to_msg({"type": e.type, **p}))
        elif e.type in NET_TYPES:
            ramp = p.pop("ramp", None)
            if ramp:
                # steps are applied by tick() as mission time passes (offset-0 steps on the next tick, <= 0.5 s)
                self.ramps.append({"id": e.id, "t": mt, "targets": targets,
                                   "steps": sorted((float(a), float(b)) for a, b in ramp)})
            else:
                self.pub_net.publish(to_msg({"type": e.type, "targets": targets, **p}))
        elif e.type == "NEW_PRIORITY_POI":
            self.pub_gcs.publish(to_msg({"type": e.type, "poi": p.get("poi"), "poi_def": p.get("poi_def")}))


def main():
    rclpy.init()
    node = ScenarioRunner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
