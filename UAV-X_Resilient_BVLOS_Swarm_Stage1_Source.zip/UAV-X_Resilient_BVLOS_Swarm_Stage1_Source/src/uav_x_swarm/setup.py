from setuptools import find_packages, setup

package_name = "uav_x_swarm"

setup(
    name=package_name,
    version="1.0.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="amg",
    maintainer_email="maheshgagiya129@gmail.com",
    description="UAV-X resilient BVLOS swarm autonomy",
    license="BSD-3-Clause",
    entry_points={
        "console_scripts": [
            "heartbeat = uav_x_swarm.nodes.heartbeat:main",
            "uav_agent = uav_x_swarm.nodes.uav_agent:main",
            "comm_manager = uav_x_swarm.nodes.comm_manager:main",
            "swarm_manager = uav_x_swarm.nodes.swarm_manager:main",
            "gcs = uav_x_swarm.nodes.gcs:main",
            "scenario_runner = uav_x_swarm.nodes.scenario_runner:main",
            "metrics_logger = uav_x_swarm.nodes.metrics_logger:main",
            "dashboard = uav_x_swarm.nodes.dashboard:main",
        ],
    },
)
