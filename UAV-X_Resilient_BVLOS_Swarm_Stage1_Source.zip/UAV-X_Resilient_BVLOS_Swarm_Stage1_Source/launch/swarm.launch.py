"""Launch the UAV-X swarm software stack (Gazebo + PX4 are started separately by
scripts/start_simulation.sh).

    ros2 launch launch/swarm.launch.py scenario:=scenarios/stage1_demo.yaml run_dir:=results/runs/x

Nodes: comm_manager, gcs, swarm_manager, N x uav_agent (namespaces /uav1../uavN),
scenario_runner, metrics_logger (prints the event console), dashboard.
The number of UAVs comes from config/swarm.yaml (and scenario overrides).
"""
import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction, Shutdown
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), ".."))


def _setup(context):
    from uav_x_swarm.core.config import Config

    cfg_path = LaunchConfiguration("config").perform(context)
    scenario = LaunchConfiguration("scenario").perform(context)
    run_dir = LaunchConfiguration("run_dir").perform(context)
    dashboard = LaunchConfiguration("dashboard").perform(context).lower() in ("1", "true", "yes")
    port = int(LaunchConfiguration("dashboard_port").perform(context))
    cfg_abs = cfg_path if os.path.isabs(cfg_path) else os.path.join(ROOT, cfg_path)
    scen_abs = (scenario if os.path.isabs(scenario) else os.path.join(ROOT, scenario)) if scenario else ""
    cfg = Config.load(cfg_abs, scen_abs or None)
    common = {"config": cfg_abs, "scenario": scen_abs}
    quiet = "log"

    def critical(reason):
        # a crashed critical node must end the run loudly, never leave it hanging
        return [Shutdown(reason=reason)]

    nodes = [
        Node(package="uav_x_swarm", executable="comm_manager", name="comm_manager", parameters=[common], output=quiet,
             on_exit=critical("comm_manager exited")),
        Node(package="uav_x_swarm", executable="gcs", name="gcs", parameters=[common], output=quiet,
             on_exit=critical("gcs exited")),
        Node(package="uav_x_swarm", executable="swarm_manager", name="swarm_manager", parameters=[common],
             output=quiet, on_exit=critical("swarm_manager exited")),
        Node(package="uav_x_swarm", executable="metrics_logger", name="metrics_logger",
             parameters=[{**common, "run_dir": run_dir, "print_events": True}], output="screen",
             emulate_tty=True),
    ]
    for uid in cfg.uav_ids():
        nodes.append(Node(package="uav_x_swarm", executable="uav_agent", name="uav_agent", namespace=uid,
                          parameters=[{**common, "uav_id": uid}], output=quiet,
                          on_exit=critical(f"{uid} agent exited")))
    if scen_abs:
        nodes.append(Node(package="uav_x_swarm", executable="scenario_runner", name="scenario_runner",
                          parameters=[common], output=quiet))
    if dashboard:
        nodes.append(Node(package="uav_x_swarm", executable="dashboard", name="dashboard",
                          parameters=[{**common, "port": port}], output=quiet))
    return nodes


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument("config", default_value="config/swarm.yaml"),
        DeclareLaunchArgument("scenario", default_value="scenarios/stage1_demo.yaml"),
        DeclareLaunchArgument("run_dir", default_value=""),
        DeclareLaunchArgument("dashboard", default_value="true"),
        DeclareLaunchArgument("dashboard_port", default_value="8080"),
        OpaqueFunction(function=_setup),
    ])
