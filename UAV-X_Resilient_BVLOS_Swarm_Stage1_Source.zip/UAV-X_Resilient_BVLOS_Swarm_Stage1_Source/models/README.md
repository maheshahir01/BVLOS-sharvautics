# models/

`models/x500_base/` is **generated** by `scripts/tools/make_visual_model.py` (run by
`./scripts/build.sh`). It is PX4's `x500_base` model with only the `<visual>` elements
enlarged (`sim.uav_visual_scale` in `config/swarm.yaml`) so the drones are visible in the
Gazebo GUI; collisions, mass, inertia, joints and sensors are verified identical to PX4's.
Because this directory is first on `GZ_SIM_RESOURCE_PATH`, Gazebo uses it instead of PX4's
copy. It is not version-controlled.
