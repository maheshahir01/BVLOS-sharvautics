# Run report: scenarios/stage1_demo.yaml

* Run id: `20260925_014851_stage1_demo`
* Started (wall clock): 2026-09-25T01:49:21
* UAVs: 4; world: disaster_zone
* **Mission result: MISSION_COMPLETE**

## Mission
| Metric | Value |
|---|---|
| PoIs completed | 7 / 7 |
| Completion rate | 1.000 |
| Completion time (all PoIs reported) | 172.0 s |
| Mission duration (start to all landed) | 255.0 s |
| Priority-weighted score | 1.000 |

## Communication
| Metric | Value |
|---|---|
| Packet delivery ratio (end-to-end unicast) | 0.828 (2351/2838) |
| Average latency | 16.7 ms |
| p95 latency | 30.0 ms |
| Maximum latency | 45.4 ms |
| Connectivity availability | 0.948 |
| Communication downtime (UAV-seconds) | 39.0 s |
| Downtime per UAV | {'uav1': 11.0, 'uav3': 11.0, 'uav4': 17.0} |

## Autonomous relay & role management / fault recovery
| Metric | Value |
|---|---|
| Relay reallocations | 1 |
| Task reallocations | 4 |
| Network reconfigurations | 2 |
| Recovery times | [17.83, 15.33] s |
| Mean recovery time | 16.6 s |

## Safety
| Metric | Value |
|---|---|
| Collisions | 0 |
| Minimum inter-UAV distance | 8.885 m ('uav1', 'uav2') |
| Separation violations (< min safe distance) | 0 |
| Collision-avoidance activations | 4 |
| Geofence violations | 0 |
| Geofence warnings | 0 |

## Battery
| Metric | Value |
|---|---|
| Lowest battery per UAV | {'uav1': 66.7, 'uav2': 88.2, 'uav3': 21.8, 'uav4': 59.2} |
| Low-battery RTH events | 1 |
| Depleted UAVs | none |

## Robustness
| Metric | Value |
|---|---|
| Mission success before first failure | 0.333 |
| Mission success after first failure | 1.000 |
| Communication recovery success | 1.000 |

## Software health
| Metric | Value |
|---|---|
| Software errors (caught exceptions) | 0 |

### Injected faults
| Fault | Target | Injected (mission s) | Detected by | Detection delay | Recovered | Recovery time |
|---|---|---|---|---|---|---|
| UAV_FAILURE (relay_failure) | uav2 | 68.2 | HEARTBEAT_LOST | 3.330 s | True | 17.8 s |
| BATTERY_DEGRADATION (battery_fault) | uav3 | 118.2 | BATTERY_ANOMALY | 0.260 s | True | 15.3 s |
