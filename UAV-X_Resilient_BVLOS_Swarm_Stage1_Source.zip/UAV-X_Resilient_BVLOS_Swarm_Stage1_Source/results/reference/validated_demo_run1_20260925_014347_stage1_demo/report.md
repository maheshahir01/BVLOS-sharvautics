# Run report: scenarios/stage1_demo.yaml

* Run id: `20260925_014347_stage1_demo`
* Started (wall clock): 2026-09-25T01:44:16
* UAVs: 4; world: disaster_zone
* **Mission result: MISSION_COMPLETE**

## Mission
| Metric | Value |
|---|---|
| PoIs completed | 7 / 7 |
| Completion rate | 1.000 |
| Completion time (all PoIs reported) | 171.5 s |
| Mission duration (start to all landed) | 254.5 s |
| Priority-weighted score | 1.000 |

## Communication
| Metric | Value |
|---|---|
| Packet delivery ratio (end-to-end unicast) | 0.840 (2377/2830) |
| Average latency | 16.8 ms |
| p95 latency | 30.0 ms |
| Maximum latency | 45.5 ms |
| Connectivity availability | 0.950 |
| Communication downtime (UAV-seconds) | 37.5 s |
| Downtime per UAV | {'uav1': 10.5, 'uav3': 10.5, 'uav4': 16.5} |

## Autonomous relay & role management / fault recovery
| Metric | Value |
|---|---|
| Relay reallocations | 1 |
| Task reallocations | 4 |
| Network reconfigurations | 2 |
| Recovery times | [16.39, 14.89] s |
| Mean recovery time | 15.6 s |

## Safety
| Metric | Value |
|---|---|
| Collisions | 0 |
| Minimum inter-UAV distance | 9.041 m ('uav1', 'uav2') |
| Separation violations (< min safe distance) | 0 |
| Collision-avoidance activations | 4 |
| Geofence violations | 0 |
| Geofence warnings | 0 |

## Battery
| Metric | Value |
|---|---|
| Lowest battery per UAV | {'uav1': 66.7, 'uav2': 88.1, 'uav3': 21.7, 'uav4': 59.3} |
| Low-battery RTH events | 1 |
| Depleted UAVs | none |

## Robustness
| Metric | Value |
|---|---|
| Mission success before first failure | 0.333 |
| Mission success after first failure | 1.000 |
| Communication recovery success | 1.000 |

## Software health
| Metric | Value |
|---|---|
| Software errors (caught exceptions) | 0 |

### Injected faults
| Fault | Target | Injected (mission s) | Detected by | Detection delay | Recovered | Recovery time |
|---|---|---|---|---|---|---|
| UAV_FAILURE (relay_failure) | uav2 | 68.1 | HEARTBEAT_LOST | 2.890 s | True | 16.4 s |
| BATTERY_DEGRADATION (battery_fault) | uav3 | 118.1 | BATTERY_ANOMALY | 0.290 s | True | 14.9 s |
