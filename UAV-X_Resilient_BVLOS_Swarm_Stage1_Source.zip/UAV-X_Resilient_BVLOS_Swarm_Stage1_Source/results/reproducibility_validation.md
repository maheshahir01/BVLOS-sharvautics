# Reproducibility validation of the submission package

Date: 27 Sep 2026. This report records how the packaged source archive
`UAV-X_Resilient_BVLOS_Swarm_Stage1_Source.zip` was tested, every problem the tests found, and
how each problem was fixed. Three kinds of test were run; they are deliberately kept apart
because they prove different things:

| Test | What it proves | What it does NOT prove |
|---|---|---|
| **A. Clean-extraction test (host)** | The archive alone is complete: extracted into a new directory, with the original development tree made inaccessible (`mv` to a hidden name for the whole test), it installs, builds PX4, passes the simulator tests and runs the full GUI demo. Nothing refers back to the original tree. | System packages (ROS 2, Gazebo, compilers) were already installed on the host, so their installation path is not exercised. |
| **B. Fresh-OS test (container)** | On a bare `ubuntu:26.04` image (no python3, no ROS, no Gazebo, no git, no sudo) `install.sh` adds the official ROS 2 and Gazebo apt sources, installs everything, clones and builds PX4, and the headless demo runs to MISSION_COMPLETE. | It is a rootless podman container on the same WSL2 kernel, not a physical fresh machine; the Gazebo GUI was not run in it (headless demo). |
| **C. Unit/sim test suites** | Run inside A and B by `install.sh` (36 unit tests) and by A (`run_tests.sh --sim`, TEST 1-6). | |

## 1. Tested environment

| Item | Value |
|---|---|
| Host | Windows 11 + WSL2, kernel 6.18.33.2-microsoft-standard-WSL2, Intel i5-12450H (12 threads), 7.6 GiB RAM, WSLg (GUI demo) |
| Host OS | Ubuntu 26.04.1 LTS, x86_64 |
| ROS 2 / Gazebo / PX4 | ROS 2 Lyrical (ros-base 0.13.0), Gazebo Jetty (gz-sim 10.5.0, gz-transport 15.1.0), PX4 v1.18.0-rc1 `fca3df865af36124a28c9d607e850f111dbaaea9` |
| Python | 3.14; pymavlink 2.4.49, PyYAML 6.0.3, pytest 9.0.2, empy 3.3.4 (PX4) |
| Container (test B) | podman 5.7.0 rootless, image `docker.io/library/ubuntu:26.04` (Ubuntu 26.04.1 LTS), `--shm-size=2g` (a normal machine's /dev/shm; the container default is 64 MB) |
| Container result versions | ros-lyrical-ros-base 0.13.0-3, ros-lyrical-rclpy 10.0.11, ros-lyrical-ros-gz-bridge 3.0.10, gz-jetty 1.0.0, libgz-sim10 10.5.0, python3 3.14.3, empy 3.3.4 |

## 2. Package

| Item | Value |
|---|---|
| Name | `UAV-X_Resilient_BVLOS_Swarm_Stage1_Source.zip` |
| Top-level directory | `UAV-X_Resilient_BVLOS_Swarm_Stage1_Source/` |
| Produced by | `git archive` of a clean commit (only version-controlled files; executable bits preserved) |
| Content | 112 files (the 111 files tested in A3 plus this report); no build output, logs, caches, PX4 checkout or secrets |
| Size / SHA256 | see `UAV-X_Resilient_BVLOS_Swarm_Stage1_Source.zip.sha256` shipped next to the archive (this report is inside the archive, so it cannot contain the archive's own hash) |

Secret scan of all tracked files (API keys, tokens, private keys, passwords, absolute home
paths): none found. The only personal data is the package maintainer e-mail in
`src/uav_x_swarm/package.xml` and `setup.py` (required by ROS 2 packaging).

## 3. Test runs

| Run | Type | Source commit | Result |
|---|---|---|---|
| A1 | clean extraction, host, GUI demo | ae4d501 | 16/17 PASS: `ros_graph` FAIL (problem 3) |
| A2 | clean extraction, host, GUI demo | 5c04193 | **17/17 PASS** |
| B1 | fresh OS, container, headless | 762d6a8 | FAIL: PX4 build error (problem 6) |
| B2 | fresh OS, container, headless | 8c0d0fa | 13/14 PASS: `demo_checks` FAIL, TEST 16/21 (problem 7) |
| A3 | clean extraction, host, GUI demo | 041d9d3 | **17/17 PASS** |

Changes between B2 and A3: `core/metrics.py` (problem 7, battery-recovery attribution),
documentation and `CHANGELOG.md`. `install.sh` is identical in B2 and A3.

### Steps and checks (test A, every run)

1. **Hide the original tree** (`~/uav_x_swarm` renamed; restored by an exit trap). Checked it no longer exists.
2. **Extraction** of the ZIP into `~/uav_x_repro_test/`; `install.sh` and `run_demo.sh` executable; 111 files.
3. **Dependency detection**: `./install.sh --check` must report PX4 as missing and change nothing.
4. **Installation**: `./install.sh` (clones PX4 at the pinned tag, verifies the commit, installs missing Python packages, builds PX4 SITL, the visual model, the world and the ROS 2 workspace, runs `check_system.sh` and the 36 unit tests). Exit code 0 required.
5. **PX4 pinned commit** = `fca3df86…`; **build** outputs present (`px4`, `install/setup.bash`, `models/x500_base/model.sdf`).
6. **Post-install check**: `./install.sh --check` must report "nothing missing".
7. **Simulator tests** `./scripts/run_tests.sh --sim` (TEST 1-6: single/four UAV SITL, takeoff, waypoints, landing).
8. **Launch** `./run_demo.sh` (Gazebo GUI + follow camera). 25 s after "Mission started", live checks:
   * **PX4**: exactly 4 `px4` processes, all started from the extracted copy, 0 processes referencing the original tree.
   * **Gazebo**: `gz-sim-main` running.
   * **ROS 2 graph**: `tests/sim/ros_live_check.py`: 8/8 nodes, 31/31 topics delivering, ≥ 7 `/events` publishers.
   * **Dashboard**: `http://127.0.0.1:8080/` serves the page, `/api/state` lists 4 UAVs with flight states and a mission phase.
9. **Mission**: demo exit code 0 and `RESULT: MISSION_COMPLETE`.
10. **Demo checks** on the run record: TEST 12 relay failure, 15 priority PoI, 16 low battery, 17 RTH, 20 complete mission, 21 failure recovery.
11. **Metrics** `report.md` + `summary.json` generated.
12. **No references** to the original tree in the copy's results, logs, build and install directories.
13. **Clean stop** `./scripts/stop_all.sh`.

Test B runs steps 2-6 and 8-13 inside the container (headless demo, no simulator tests,
no original tree exists there). Before `install.sh` it runs the one documented prerequisite
`apt install unzip`.

## 4. Results of the final runs

### A3: clean extraction on the host (final package)

| Check | Result | Evidence |
|---|---|---|
| Original tree hidden | PASS | `~/uav_x_swarm` did not exist during the test; restored afterwards |
| Extraction | PASS | 111 files, scripts executable |
| Dependency detection | PASS | `--check`: PX4 reported missing, nothing installed |
| Installation | PASS | `install.sh` exit 0 in 503 s (PX4 clone + build, ROS 2 workspace, 36 unit tests passed) |
| PX4 pinned commit | PASS | `fca3df865af36124a28c9d607e850f111dbaaea9` |
| Build | PASS | PX4 SITL binary, ROS 2 install space, visual model |
| Post-install check | PASS | "nothing missing" |
| Simulator tests TEST 1-6 | PASS | `run_tests.sh --sim` |
| Launch: four PX4 from the copy | PASS | 4 `px4` processes; 0 processes referencing the original tree, 16 referencing the extracted copy |
| Gazebo | PASS | `gz-sim-main` running with GUI and follow camera |
| ROS 2 graph | PASS | 8/8 nodes, 31/31 topics delivering, 8 `/events` publishers |
| Dashboard | PASS | page served; `/api/state`: phase DEPLOY, uav1-uav4 in TRANSIT |
| Mission | PASS | `RESULT: MISSION_COMPLETE`, demo exit 0 |
| Demo checks TEST 12/15/16/17/20/21 | PASS | relay failure detected 2.9 s, network reconfigured 17.9 s; POI7 assigned 0.4 s; battery fault detected 0.33 s, low-battery RTH, tasks re-assigned 9.4 s; all UAVs landed at home |
| Metrics | PASS | 7/7 PoIs, completion 232.5 s, duration 345.0 s, PDR 0.819, connectivity 0.947, 0 collisions, min separation 8.31 m, 0 geofence violations, lowest battery 15.2 % (critical 15 %) |
| No references to the original tree | PASS | none in results, logs, build, install |
| Clean stop | PASS | `stop_all.sh` |

Observation: this run was slower than usual (completion 232.5 s; median 174.5 s) and the
battery-fault UAV landed with 15.2 %, just above the 15 % critical level (all other runs
landed with >= 20.8 %). It is within the specification (no UAV depleted or reached critical
during flight), but it is the lowest margin observed; see `docs/REPRODUCIBILITY.md` §2.

### B2: fresh Ubuntu 26.04 container

| Check | Result | Evidence |
|---|---|---|
| Bare image | - | no python3, no /opt/ros, no gz, no git, no sudo |
| Extraction | PASS | |
| Dependency detection | PASS | 47 items missing reported, python3 absent reported, nothing installed |
| Installation (ROS 2 + Gazebo apt sources, all packages, PX4 clone + build, colcon, check, unit tests) | PASS | 1209 s, exit 0, 36 unit tests passed |
| PX4 pinned commit / build | PASS / PASS | |
| Post-install check | PASS | nothing missing |
| Four PX4 instances | PASS | 4 processes |
| Gazebo running | PASS | headless server |
| ROS 2 graph | PASS | 8/8 nodes, 31/31 topics, 8 `/events` publishers |
| Dashboard | PASS | phase DEPLOY, uav1-uav4 |
| Mission | PASS | MISSION_COMPLETE 7/7 PoIs, completion 139.5 s, 0 collisions, min separation 9.17 m, PDR 0.839 |
| Demo checks | **FAIL** | TEST 12, 15, 17, 20 PASS; **TEST 16 and 21 FAIL**: no low-battery RTH (problem 7) |
| Metrics generated / clean stop | PASS / PASS | |

## 5. Problems found and fixed

| # | Found by | Problem | Root cause | Fix |
|---|---|---|---|---|
| 1 | packaging review | `models/x500_base/` (generated) was committed | an inline comment in `.gitignore` made the pattern not match | comments on their own line; file removed from the index |
| 2 | packaging review | `install.sh` would always fail its last step | `run_tests.sh --unit` exited 1 because the 21 simulator tests were "NOT RUN" | `tests/sim/aggregate.py --partial`: partial runs pass when nothing failed |
| 3 | A1 | `ros_graph` FAIL | `/events` is event-driven and was silent during the 20 s check window | 60 s window, and `/events` checked by publisher count |
| 4 | A1 | `install.sh --check` said "nothing missing" with PX4 absent | PX4 was not counted as a missing item | PX4 counted |
| 5 | bare-image check | `--check` said "Python requirements satisfied" with no python3; `ss` missing on minimal images | failed python3 call was not treated as a failure; `iproute2`/`procps` not in the base list | explicit python3 handling; `procps iproute2` added |
| 6 | B1 | PX4 build failed on a fresh OS: `module 'em' has no attribute 'RAW_OPT'` | ROS 2 pulls in Ubuntu's `python3-empy` 4.2.1; PX4 needs `empy>=3.3,<4`; the requirement check only tested presence, not version | version-aware requirement check (`packaging` specifiers), `python3-packaging` added; B2 then installed empy 3.3.4 and built PX4 |
| 7 | B2 (and 1 earlier host run) | TEST 16/21 FAIL although the mission completed; the metrics reported the battery fault as "recovered by RTH_STARTED" | timing: the battery fault is injected 15 s after the CRITICAL PoI; in 2 of 17 runs the fault target was already on its last task and had enough energy to finish, so the mission ended (about 140 s) before a low-battery RTH was needed. The metrics credited the normal end-of-mission RTH as the recovery | metrics: the end-of-mission RTH is no longer counted as recovery (verified by replaying the recorded events: the affected run now reports "not recovered", normal runs unchanged). The scenario trigger was **not** changed (fault injection is outside the packaging scope and changing it would invalidate the validated results); the behaviour is documented in `docs/REPRODUCIBILITY.md` §2, `docs/DEMO_GUIDE.md` and `docs/TROUBLESHOOTING.md` |

## 6. Final result

**Clean-extraction test of the final package (A3): PASS, 17/17 checks.** The archive is
self-contained: from the extracted copy alone, with the original tree inaccessible,
`./install.sh` fetched and built the pinned PX4 and the workspace and `./run_demo.sh` ran the
full Stage-1 GUI demo to MISSION_COMPLETE with all six demo checks passing.

**Fresh-OS installation (B2): PASS for installation, build, launch and mission; the demo
checks FAILED in that run** (TEST 16/21: the low-battery storyline was not triggered, problem
7). The installation path from a bare Ubuntu 26.04 image is therefore verified; the
intermittent storyline gap (2 of 18 runs) is a known, documented limitation.

**Not claimed:** a test on a physical freshly installed machine, on native (non-WSL) Ubuntu,
or on Ubuntu 24.04. The fresh-OS test was a container on the same WSL2 host.
