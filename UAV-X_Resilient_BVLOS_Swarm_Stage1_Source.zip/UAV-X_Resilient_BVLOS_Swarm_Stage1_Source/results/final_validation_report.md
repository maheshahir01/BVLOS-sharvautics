# Final Validation Report: UAV-X Stage-1 Swarm

> **Evidence in this repository:** the raw run folders named below (`results/runs/...`, `results/tests/...`) are generated locally by each run and are not part of the repository. The report, metrics summary, fault table and relay changes of both demonstration runs are kept in [`results/reference/`](reference/). Re-run with `./run_demo.sh` (one run) or `./scripts/tools/final_validation.sh` (full procedure).

Generated 2026-09-25T01:54:52 by `scripts/tools/final_report.py` from recorded evidence only.

## System

| Component | Version |
|---|---|
| Ubuntu | Ubuntu 26.04.1 LTS (kernel 6.18.33.2-microsoft-standard-WSL2) |
| ROS 2 | lyrical |
| Gazebo | gz-sim 10.5.0 (Jetty) |
| PX4 | v1.18.0-rc1 (fca3df865af3) |
| Python | Python 3.14.4 |
| pymavlink | 2.4.49 |
| ros_gz_bridge | 3.0.10-1resolute.20260915.142616 |
| Project commit | 9da4531 |
| Hardware | 12th Gen Intel(R) Core(TM) i5-12450H, 7.6Gi RAM (WSL2) |

## Simulation

* 4 PX4 SITL x500 quadrotors (instances 0-3, MAV_SYS_ID 1-4, MAVLink UDP 14540-14543), Gazebo world `disaster_zone` (GCS, 4 launch pads, geofence 520 m x 460 m x 60 m, about 60 buildings, rubble, roads).
* PoIs: POI1-POI6 at start (priorities LOW..HIGH, 270-390 m from the GCS, beyond the 250 m GCS radio range), POI7 CRITICAL emerging at runtime.
* Communication: range-limited, distance-dependent loss/latency model with ETX multi-hop routing (ARCHITECTURE.md §5).

## Automated tests

Suite `20260925_010007`: **22/22 PASS** (details: `results/tests/20260925_010007/TEST_RESULTS.md`, copied to `TEST_RESULTS.md`).

| Test | Status |
|---|---|
| unit_tests | PASS |
| test_01_px4_startup | PASS |
| test_02_takeoff | PASS |
| test_03_waypoints | PASS |
| test_04_landing | PASS |
| test_05_four_uav_startup | PASS |
| test_06_independent_control | PASS |
| test_07_ros_communication | PASS |
| test_08_gcs_communication | PASS |
| test_09_uav_to_uav_communication | PASS |
| test_10_multi_hop_routing | PASS |
| test_11_relay_selection | PASS |
| test_12_relay_failure | PASS |
| test_13_communication_outage | PASS |
| test_14_packet_loss | PASS |
| test_15_new_priority_poi | PASS |
| test_16_low_battery | PASS |
| test_17_return_to_home | PASS |
| test_18_collision_avoidance | PASS |
| test_19_geofence | PASS |
| test_20_complete_mission | PASS |
| test_21_failure_recovery_mission_completion | PASS |

## Stage-1 demonstration runs

Procedure (`scripts/tools/final_validation.sh`): full test suite (22/22 PASS) → demo run 1 from a clean login shell (MISSION_COMPLETE) → `stop_all.sh` (no PX4/Gazebo processes left) → wiped `build/ install/ log/ .run/` and PX4 lock files, clean `colcon` rebuild + system check from a clean login shell (passed) → demo run 2 (MISSION_COMPLETE). Both demo runs used the Gazebo GUI. Logs: `logs/final_validation/`. (The report step of that run failed on a suite-folder selection bug in the script; it was fixed and this report was regenerated from the same recorded evidence.)

### Demonstration run 1

Run `20260925_014347_stage1_demo` (scenario `stage1_demo.yaml`), evidence in `results/runs/20260925_014347_stage1_demo/`.

| Area | Metric | Value |
|---|---|---|
| Mission | result | **MISSION_COMPLETE** |
| Mission | PoIs completed | 7/7 (rate 1.000) |
| Mission | completion time (all PoIs reported) | 171.5 s |
| Mission | mission duration (start → all landed) | 254.5 s |
| Mission | priority-weighted score | 1.000 |
| Communication | packet delivery ratio | 0.840 (2377/2830) |
| Communication | latency mean / p95 / max | 16.8 ms / 30.0 ms / 45.5 ms |
| Communication | connectivity availability | 0.950 |
| Communication | downtime (UAV-seconds) | 37.5 s {'uav1': 10.5, 'uav3': 10.5, 'uav4': 16.5} |
| Swarm | relay changes | 1 |
| Swarm | task reallocations | 4 |
| Swarm | network reconfigurations | 2 |
| Swarm | recovery times | [16.39, 14.89] s |
| Safety | collisions | 0 |
| Safety | minimum inter-UAV separation | 9.041 m ('uav1', 'uav2') |
| Safety | separation violations (< 5 m) | 0 |
| Safety | avoidance activations | 4 |
| Safety | geofence violations / warnings | 0 / 0 |
| Battery | lowest battery per UAV | {'uav1': 66.7, 'uav2': 88.1, 'uav3': 21.7, 'uav4': 59.3} |
| Battery | low-battery RTH events / depleted UAVs | 1 / none |
| Software | caught exceptions | 0 |

Injected failures:

| Fault | Target | Injected at (mission s) | Detected by | Detection delay | Recovered by | Recovery time |
|---|---|---|---|---|---|---|
| UAV_FAILURE | uav2 | 68.1 | HEARTBEAT_LOST | 2.89 s | RECONFIG_COMPLETE | 16.4 s |
| BATTERY_DEGRADATION | uav3 | 118.1 | BATTERY_ANOMALY | 0.29 s | TASK_ASSIGNED | 14.9 s |

Mission success before / after first failure: 0.333 / 1.000; communication recovery success 1.000.

### Demonstration run 2

Run `20260925_014851_stage1_demo` (scenario `stage1_demo.yaml`), evidence in `results/runs/20260925_014851_stage1_demo/`.

| Area | Metric | Value |
|---|---|---|
| Mission | result | **MISSION_COMPLETE** |
| Mission | PoIs completed | 7/7 (rate 1.000) |
| Mission | completion time (all PoIs reported) | 172.0 s |
| Mission | mission duration (start → all landed) | 255.0 s |
| Mission | priority-weighted score | 1.000 |
| Communication | packet delivery ratio | 0.828 (2351/2838) |
| Communication | latency mean / p95 / max | 16.7 ms / 30.0 ms / 45.4 ms |
| Communication | connectivity availability | 0.948 |
| Communication | downtime (UAV-seconds) | 39.0 s {'uav1': 11.0, 'uav3': 11.0, 'uav4': 17.0} |
| Swarm | relay changes | 1 |
| Swarm | task reallocations | 4 |
| Swarm | network reconfigurations | 2 |
| Swarm | recovery times | [17.83, 15.33] s |
| Safety | collisions | 0 |
| Safety | minimum inter-UAV separation | 8.885 m ('uav1', 'uav2') |
| Safety | separation violations (< 5 m) | 0 |
| Safety | avoidance activations | 4 |
| Safety | geofence violations / warnings | 0 / 0 |
| Battery | lowest battery per UAV | {'uav1': 66.7, 'uav2': 88.2, 'uav3': 21.8, 'uav4': 59.2} |
| Battery | low-battery RTH events / depleted UAVs | 1 / none |
| Software | caught exceptions | 0 |

Injected failures:

| Fault | Target | Injected at (mission s) | Detected by | Detection delay | Recovered by | Recovery time |
|---|---|---|---|---|---|---|
| UAV_FAILURE | uav2 | 68.2 | HEARTBEAT_LOST | 3.33 s | RECONFIG_COMPLETE | 17.8 s |
| BATTERY_DEGRADATION | uav3 | 118.2 | BATTERY_ANOMALY | 0.26 s | TASK_ASSIGNED | 15.3 s |

Mission success before / after first failure: 0.333 / 1.000; communication recovery success 1.000.

## Honest limitations

* Communication is a documented mathematical model (range, distance-dependent loss, latency, estimator lag, routing), not RF propagation. Gazebo does not simulate radio.
* The battery is a deterministic model maintained by each UAV agent, not PX4's simulated battery (PX4's is held at >= 50 % so it never triggers PX4 failsafes).
* Survey imaging is simulated (orbit + image count); no computer vision.
* Collision avoidance uses simulated detect-and-avoid sensing (true neighbour states), independent of the radio model.
* Validation was done on WSL2. A full Windows-side `wsl --shutdown` restart could not be performed from inside the session. The restart test re-ran everything from a clean process state and a clean colcon rebuild (see above).

