#!/usr/bin/env bash
# Alias of ./install.sh (kept for compatibility): install missing dependencies, fetch the
# pinned PX4, build everything and verify (system check + unit tests).
exec "$(cd "$(dirname "$0")" && pwd)/install.sh" "$@"
