# Changelog

All dates 2026-09-24 unless noted. Each milestone was verified before moving on (see git history).

## 1.0.0: Stage-1 proof of concept

### Phase 1–5: platform
* System inspection and compatibility decision (Ubuntu 26.04 + ROS 2 Lyrical + Gazebo Jetty +
  PX4 v1.18.0-rc1): `docs/system_compatibility_report.md`.
* PX4 v1.18.0-rc1 cloned (pinned) and built in a ROS-free environment. Verified CMake found the
  system Gazebo Jetty libraries.
* `scripts/lib/common.sh`: clean simulator environment, session-leader PID files,
  process-group shutdown.
* `px4/link.py`: pymavlink interface (per-instance port, system-ID filtering, GCS heartbeat).
* Single-UAV SITL test: takeoff, 2 waypoints, landing (TEST 1–4).

### Phase 6: four UAVs
* Generated lightweight disaster world (`scripts/tools/generate_world.py`).
* `scripts/start_simulation.sh` (N PX4 instances in standalone mode, fresh working dirs,
  `PX4_PARAM_*` overrides) and `scripts/stop_all.sh`.
* TEST 5–6: unique system ID/port/model per UAV; independent control verified against Gazebo
  ground truth (also verifies the NED→ENU frame mapping).

### Phase 7–19: swarm software
* ROS 2 `ament_python` package `uav_x_swarm`; pure-Python core with unit tests.
* Nodes: `uav_agent`, `comm_manager`, `gcs`, `swarm_manager`, `scenario_runner`,
  `metrics_logger`, `dashboard`; launch file; scenario files; web dashboard.
* First end-to-end nominal mission completed.

### Fixes from end-to-end validation
* Swarm manager crash at mission end (event keyword collision) → explicit event details,
  guarded callbacks, launch shutdown on critical node exit.
* Load balancing (makespan cost); link classification hysteresis and debounce;
  pad-accurate landing; relay placement hysteresis.
* Relay-failure recovery: PDR reset on reconnection, new-relay grace period, relay sent home
  only for relay-specific radio faults, late partition inference, passive liveness from
  forwarded packets, peer-bridge preference, selection hold, fresh and stable
  reconfiguration check.
* Battery safety: RTH threshold = 1.25 × energy home + critical + reserve (property-tested);
  GCS drain-rate estimation and step-drop anomaly detection.
* Per-fault recovery-time definitions; avoidance events debounced per encounter.

### Phase 20–22: tests, demonstration, validation
* `scripts/run_tests.sh`: unit tests, simulator tests (TEST 1–6), 9 scenario runs evaluated
  from recorded evidence (TEST 7–21), live ROS graph check, aggregated `TEST_RESULTS.md`.
* `scripts/run_stage1_demo.sh`, `docs/DEMO_GUIDE.md`.
* Clean-restart validation: `results/final_validation_report.md`.

## 1.0.1: submission packaging (2026-09-27)

* `install.sh` / `run_demo.sh`, docs moved to `docs/`, evaluator README, pinned `requirements.txt`.
* Found by the clean-extraction and fresh-OS container tests and fixed:
  `.gitignore` inline comment, `run_tests.sh --unit` exit code, `/events` check window in
  `ros_live_check.py`, `install.sh --check` summary without PX4 / without python3,
  `procps` + `iproute2` for bare images, and a version-aware Python requirement check
  (Ubuntu's empy 4 broke the PX4 build; PX4 needs empy < 4).
* Metrics: the normal end-of-mission return is no longer credited as recovery from a battery
  fault.
* Documented run-to-run variation and the intermittent battery-storyline gap
  (`docs/REPRODUCIBILITY.md` §2).
