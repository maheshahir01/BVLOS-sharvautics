#!/usr/bin/env bash
# =============================================================================
# UAV-X Stage-1 swarm: install dependencies, fetch the pinned PX4, build, verify.
#
#   ./install.sh            # install what is missing, build, verify   (uses sudo for apt)
#   ./install.sh --check    # only report what is missing; change nothing
#
# Validated on Ubuntu 26.04 + ROS 2 Lyrical + Gazebo Jetty + PX4 v1.18.0-rc1 (x86_64).
# Ubuntu 24.04 (ROS 2 Jazzy + Gazebo Harmonic) uses the same code path but has NOT
# been validated.
#
# Safety: every step checks first and installs only what is missing. The script never
# removes packages, never edits ~/.bashrc, /etc/sudoers or anything outside this
# repository except: apt packages (+ the official ROS / Gazebo apt sources if they are
# absent) and missing Python packages installed with `pip --user` (as PX4 does).
# =============================================================================
set -u
LOG_TAG=install
source "$(dirname "$0")/scripts/lib/common.sh"
cd "$PROJECT_ROOT"
CHECK_ONLY=0
[[ "${1:-}" == "--check" ]] && CHECK_ONLY=1

# ---------------------------------------------------------------- 0. platform
. /etc/os-release
ARCH="$(uname -m)"
[[ "$ARCH" == "x86_64" ]] || { c_err "unsupported CPU architecture $ARCH (x86_64 required)"; exit 1; }
case "$VERSION_ID" in
  26.04) DISTRO=lyrical; GZ_PKG=gz-jetty;    GZ_PY="python3-gz-transport15 python3-gz-msgs12" ;;
  24.04) DISTRO=jazzy;   GZ_PKG=gz-harmonic; GZ_PY="python3-gz-transport13 python3-gz-msgs10"
         c_warn "Ubuntu 24.04: supported code path, but this project was validated on 26.04 only" ;;
  *) c_err "Ubuntu $VERSION_ID is not supported (validated: 26.04; code path also for 24.04)"; exit 1 ;;
esac
c_info "Ubuntu $VERSION_ID ($VERSION_CODENAME, $ARCH): ROS 2 $DISTRO, Gazebo $GZ_PKG, PX4 $PX4_TAG (${PX4_COMMIT:0:12})"
grep -qi microsoft /proc/version 2>/dev/null && c_info "WSL2 detected (validated platform)"

if [[ $EUID -eq 0 ]]; then SUDO=""
elif command -v sudo >/dev/null; then SUDO="sudo"
else c_err "sudo is required to install apt packages"; exit 1; fi

APT_UPDATED=0
MISSING_TOTAL=()
apt_install() {  # apt_install pkg...   (only the missing ones)
  local missing=() p
  for p in "$@"; do
    dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q "install ok installed" || missing+=("$p")
  done
  (( ${#missing[@]} )) || return 0
  MISSING_TOTAL+=("${missing[@]}")
  if (( CHECK_ONLY )); then c_warn "missing apt packages: ${missing[*]}"; return 0; fi
  [[ -n "$SUDO" ]] && c_info "sudo is needed to install: ${missing[*]}"
  if (( ! APT_UPDATED )); then $SUDO apt-get update -y --quiet || return 1; APT_UPDATED=1; fi
  $SUDO env DEBIAN_FRONTEND=noninteractive apt-get install -y --quiet --no-install-recommends "${missing[@]}"
}

# ---------------------------------------------------------------- 1. base tools
c_info "[1/7] base tools"
apt_install ca-certificates curl gnupg lsb-release software-properties-common git build-essential cmake \
  ninja-build pkg-config python3 python3-dev python3-pip python3-setuptools python3-wheel python3-yaml \
  python3-pytest python3-packaging rsync unzip zip file bc libxml2-utils mesa-utils procps iproute2 || { c_err "base packages failed"; exit 1; }

# ---------------------------------------------------------------- 2. ROS 2 (official apt repository)
c_info "[2/7] ROS 2 $DISTRO"
if [[ ! -f "/opt/ros/$DISTRO/setup.bash" ]]; then
  if (( CHECK_ONLY )); then
    c_warn "ROS 2 $DISTRO is not installed (would add the official ROS 2 apt source and install ros-$DISTRO-ros-base)"
    MISSING_TOTAL+=("ros-$DISTRO-ros-base")
  else
    c_info "adding the official ROS 2 apt source (ros2-apt-source, as documented on docs.ros.org)"
    $SUDO add-apt-repository -y universe
    ver=$(curl -fsSL https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest | grep -F '"tag_name"' | awk -F\" '{print $4}')
    [[ -n "$ver" ]] || { c_err "could not determine the ros-apt-source release"; exit 1; }
    curl -fL -o /tmp/ros2-apt-source.deb \
      "https://github.com/ros-infrastructure/ros-apt-source/releases/download/${ver}/ros2-apt-source_${ver}.${VERSION_CODENAME}_all.deb" \
      && $SUDO dpkg -i /tmp/ros2-apt-source.deb || { c_err "could not add the ROS apt source"; exit 1; }
    APT_UPDATED=0
    apt_install "ros-$DISTRO-ros-base" || exit 1
  fi
else
  c_ok "ROS 2 $DISTRO present (/opt/ros/$DISTRO)"
fi
apt_install "ros-$DISTRO-ros-gz-bridge" python3-colcon-common-extensions || exit 1

# ---------------------------------------------------------------- 3. Gazebo (OSRF apt repository)
c_info "[3/7] Gazebo ($GZ_PKG)"
if ! env -i PATH=/usr/bin:/bin gz sim --versions >/dev/null 2>&1; then
  if (( CHECK_ONLY )); then
    c_warn "Gazebo is not installed (would add packages.osrfoundation.org and install $GZ_PKG)"
    MISSING_TOTAL+=("$GZ_PKG")
  else
    $SUDO curl -fsSL https://packages.osrfoundation.org/gazebo.gpg -o /usr/share/keyrings/pkgs-osrf-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/pkgs-osrf-archive-keyring.gpg] http://packages.osrfoundation.org/gazebo/ubuntu-stable $VERSION_CODENAME main" \
      | $SUDO tee /etc/apt/sources.list.d/gazebo-stable.list > /dev/null
    APT_UPDATED=0
    apt_install "$GZ_PKG" || exit 1
  fi
else
  c_ok "Gazebo present: gz-sim $(env -i PATH=/usr/bin:/bin gz sim --versions 2>/dev/null | head -1)"
fi
# Gazebo Python bindings (follow camera) + PX4 simulation build dependencies (PX4 Tools/setup/ubuntu.sh)
# shellcheck disable=SC2086
apt_install $GZ_PY libunwind-dev cppzmq-dev dmidecode libopencv-dev libeigen3-dev protobuf-compiler \
  libprotobuf-dev libgstreamer-plugins-base1.0-dev gstreamer1.0-plugins-bad gstreamer1.0-plugins-base \
  gstreamer1.0-plugins-good gstreamer1.0-plugins-ugly gstreamer1.0-libav libimage-exiftool-perl || exit 1

# ---------------------------------------------------------------- 4. PX4 source (pinned tag + commit)
c_info "[4/7] PX4-Autopilot $PX4_TAG"
if [[ ! -d "$PX4_DIR/.git" ]]; then
  if (( CHECK_ONLY )); then
    c_warn "PX4 not present (would clone $PX4_TAG, commit ${PX4_COMMIT:0:12}, into external/, ~2 GB)"
    MISSING_TOTAL+=("PX4-Autopilot")
  else
    c_info "cloning PX4-Autopilot $PX4_TAG with submodules into external/ (~2 GB, several minutes)"
    mkdir -p "$PROJECT_ROOT/external"
    git clone --branch "$PX4_TAG" --depth 1 --recurse-submodules --shallow-submodules -j 8 \
      https://github.com/PX4/PX4-Autopilot.git "$PX4_DIR" || { c_err "PX4 clone failed"; exit 1; }
  fi
fi
if [[ -d "$PX4_DIR/.git" ]]; then
  have="$(git -C "$PX4_DIR" rev-parse HEAD 2>/dev/null)"
  if [[ "$have" != "$PX4_COMMIT" ]]; then
    c_err "external/PX4-Autopilot is at commit $have, but $PX4_COMMIT ($PX4_TAG) is required."
    c_err "Not modifying it. Move it away (e.g. mv external/PX4-Autopilot external/PX4-old) and re-run."
    exit 1
  fi
  c_ok "PX4 at pinned commit ${PX4_COMMIT:0:12} ($PX4_TAG)"
fi

# ---------------------------------------------------------------- 5. Python packages
c_info "[5/7] Python packages"
REQS=("$PROJECT_ROOT/requirements.txt")
[[ -f "$PX4_DIR/Tools/setup/requirements.txt" ]] && REQS+=("$PX4_DIR/Tools/setup/requirements.txt")
PY_CHECK_OK=1
command -v python3 >/dev/null || PY_CHECK_OK=0
(( PY_CHECK_OK )) && missing_py=$(python3 - "${REQS[@]}" <<'PY'
import sys, importlib.metadata as md
try:
    from packaging.requirements import Requirement
except ImportError:
    from pip._vendor.packaging.requirements import Requirement
miss = []
for path in sys.argv[1:]:
    for line in open(path):
        line = line.split("#")[0].strip()
        if not line:
            continue
        req = Requirement(line)
        if req.marker is not None and not req.marker.evaluate():
            continue
        try:
            have = md.version(req.name)
        except md.PackageNotFoundError:
            miss.append(line)
            continue
        # a present but out-of-range version counts as missing (e.g. Ubuntu's empy 4.x vs PX4's empy<4)
        if req.specifier and not req.specifier.contains(have, prereleases=True):
            miss.append(line)
print(" ".join(sorted(set(miss))))
PY
) || PY_CHECK_OK=0
if (( ! PY_CHECK_OK )); then
  if (( CHECK_ONLY )); then
    c_warn "python3 is not usable yet: Python packages not checked (would pip-install requirements.txt + PX4's Tools/setup/requirements.txt)"
    MISSING_TOTAL+=("python-requirements(unchecked)")
  else
    c_err "python3 is not available after installing the base packages"; exit 1
  fi
elif [[ -n "$missing_py" ]]; then
  if (( CHECK_ONLY )); then c_warn "missing Python packages: $missing_py"; MISSING_TOTAL+=($missing_py)
  else
    c_info "pip install --user (as PX4's ubuntu.sh does): $missing_py"
    # shellcheck disable=SC2086
    python3 -m pip install --user --break-system-packages $missing_py || exit 1
    # pip --user packages (e.g. empy 3.x for PX4) take precedence over the apt ones on sys.path
  fi
else
  c_ok "all project + PX4 Python requirements satisfied"
fi

chmod +x "$PROJECT_ROOT"/*.sh "$PROJECT_ROOT"/scripts/*.sh "$PROJECT_ROOT"/scripts/tools/*.py \
  "$PROJECT_ROOT"/scripts/tools/*.sh "$PROJECT_ROOT"/tests/sim/*.py 2>/dev/null

if (( CHECK_ONLY )); then
  if (( ${#MISSING_TOTAL[@]} )); then c_warn "check complete: ${#MISSING_TOTAL[@]} item(s) missing (nothing was installed)"
  else c_ok "check complete: nothing missing (nothing was installed)"; fi
  exit 0
fi

# ---------------------------------------------------------------- 6. build
c_info "[6/7] build (Gazebo world, drone visual model, PX4 SITL ~10 min first time, ROS 2 workspace)"
./scripts/build.sh || exit 1

# ---------------------------------------------------------------- 7. verify
c_info "[7/7] verification"
./scripts/check_system.sh || exit 1
./scripts/run_tests.sh --unit > "$LOG_DIR/install_unit_tests.log" 2>&1 \
  && c_ok "unit tests passed ($(grep -oE '[0-9]+ passed' "$LOG_DIR/install_unit_tests.log" | tail -1))" \
  || { c_err "unit tests failed: $LOG_DIR/install_unit_tests.log"; exit 1; }
echo
c_ok "installation complete. Run the Stage-1 demonstration with:  ./run_demo.sh"
