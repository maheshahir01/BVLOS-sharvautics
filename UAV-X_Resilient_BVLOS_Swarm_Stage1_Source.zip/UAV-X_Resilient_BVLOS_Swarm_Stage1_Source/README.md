# UAV-X: Resilient BVLOS Swarm Challenge — Stage-1 Proof of Concept

PUSHPAK Grand Challenge 2026 · Techfest IIT Bombay / IISER Bhopal

A 4-UAV disaster-response swarm simulated with **PX4 SITL + Gazebo + ROS 2**. The UAVs
survey Points of Interest (PoIs) beyond the radio range of the Ground Control Station (GCS)
while keeping an end-to-end, multi-hop link to it. They select and replace relay UAVs
autonomously, recover from UAV and link failures, take on emerging high-priority tasks,
manage battery and return home safely, avoid each other and stay inside a geofence. Every
run is measured and reported automatically.

```bash
./install.sh     # once: dependencies, pinned PX4, build, verification
./run_demo.sh    # the Stage-1 demonstration (Gazebo + 4 PX4 UAVs + GCS + dashboard)
```

---

## 1. Project overview

**Scenario.** A GCS stands outside a disaster zone. Four x500 quadrotors take off from launch
pads next to it and survey six damaged sites 270–390 m away, beyond the GCS's 250 m radio
range. During the mission a seventh, CRITICAL site appears.

| Capability | Implementation |
|---|---|
| Autonomous takeoff, navigation, landing | each UAV's onboard agent flies its own PX4 instance via MAVLink offboard control |
| PoI survey | 15 m-radius orbit per PoI; a survey report is sent to the GCS and acknowledged |
| GCS link + multi-hop UAV↔UAV↔GCS networking | radio-network emulator: range limits, distance-dependent loss/latency, ETX routing |
| Autonomous relay selection | weighted suitability score (link, battery, connectivity, position, latency, load) + relay placement optimisation, with hysteresis |
| Dynamic roles | RELAY / SURVEY / SURVEY_RELAY / RETURN_HOME / EMERGENCY / FAILED, changed at run time |
| Degradation / outage handling | measured packet-delivery ratio → WARNING / DEGRADED / FAILED → relay replaced before total loss |
| UAV failure recovery | heartbeat loss + partition inference; cut-off UAVs elect a bridge relay among themselves; GCS adopts it |
| Priority tasks | priority-first, energy-feasible allocation with pre-emption |
| Battery / return-to-home | per-UAV battery model, drain-rate anomaly detection, return-home threshold that guarantees arrival above the critical level |
| Collision avoidance | altitude layers + onboard predictive avoidance |
| Geofencing | planning check, onboard setpoint clamping, GCS monitoring |
| Logging & metrics | structured event log + CSV/JSON + automatic report for every run |

**What is simulated physically and what is modelled.**

| Physically simulated (real flight software) | Modelled (documented mathematical models) |
|---|---|
| PX4 v1.18 flight control, estimation (EKF2), arming, landing | radio links: range, distance-dependent packet loss, per-hop latency and jitter |
| Gazebo rigid-body dynamics, IMU, barometer, magnetometer, GPS | multi-hop routing (ETX shortest paths over estimated link quality) |
| x500 quadrotor model (PX4's) | battery: deterministic drain model per UAV; injected battery faults |
| | survey "imagery": represented by image counts per orbit (no camera, no computer vision) |

No radio hardware or RF propagation is simulated; Gazebo has no radio model. The
communication layer is a software emulator with explicit, documented equations
([docs/ARCHITECTURE.md §5](docs/ARCHITECTURE.md)).

## 2. Architecture

```mermaid
flowchart LR
  GZ[Gazebo Jetty<br/>world disaster_zone] <--> PX[4 x PX4 SITL<br/>x500]
  PX <-->|MAVLink UDP 14540..14543| AG[4 x uav_agent<br/>ROS 2 /uav1../uav4]
  AG <-->|/net/tx, /net/rx| NET([comm_manager<br/>radio network emulator])
  NET <--> GCS[gcs] & SM[swarm_manager]
  SCN[scenario_runner] -.fault injection.-> AG & NET & GCS
  SM & NET --> ML[metrics_logger] & DB[dashboard :8080]
```

Full design, algorithms and diagrams: **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)**.
Rulebook requirement → code → test → evidence: [docs/stage1_requirements_mapping.md](docs/stage1_requirements_mapping.md).

## 3. Requirements

| Item | Validated version |
|---|---|
| OS | **Ubuntu 26.04.1 LTS**, x86_64 (validated under WSL2 on Windows; native Ubuntu uses the same path) |
| ROS 2 | **Lyrical Luth** (`ros-lyrical-ros-base 0.13.0`, rclpy 10.0.10, `ros-lyrical-ros-gz-bridge 3.0.10`) |
| Gazebo | **Jetty** (`gz-jetty 1.0.0`: gz-sim 10.5.0, gz-transport 15.1.0, gz-msgs 12.0.2) |
| PX4 | **v1.18.0-rc1**, commit `fca3df865af36124a28c9d607e850f111dbaaea9` (cloned and verified by `install.sh`) |
| Python | 3.14.4 with pymavlink 2.4.49, PyYAML 6.0.3, pytest 9.0.2 (`requirements.txt`) |
| Hardware | 4+ CPU cores (validated: 6-core/12-thread i5-12450H), 8 GB RAM (the simulation uses about 2 GB), 10 GB free disk |
| Network | Internet access during installation (apt, GitHub for PX4, PyPI) |
| Privileges | `sudo` only for installing missing apt packages |

Why not Ubuntu 24.04 + ROS 2 Jazzy + Gazebo Harmonic? The validation machine runs Ubuntu 26.04,
for which Jazzy and Harmonic have no packages; PX4 v1.18 is the first release that supports
Gazebo Jetty. Details: [docs/system_compatibility_report.md](docs/system_compatibility_report.md).
Node.js is **not** required (the dashboard is plain HTML served by a Python node).

## 4. Installation

Exact ordered steps (details for every step: **[docs/INSTALLATION.md](docs/INSTALLATION.md)**):

```bash
# 1. Get the source (either clone the repository ...)
git clone <repository-url> uav_x_swarm && cd uav_x_swarm
#    (... or extract the submission ZIP)
unzip UAV-X_Resilient_BVLOS_Swarm_Stage1_Source.zip && cd UAV-X_Resilient_BVLOS_Swarm_Stage1_Source
#    (a minimal Ubuntu image may first need:  sudo apt install -y unzip)

# 2. (optional) see what is missing, without changing anything
./install.sh --check

# 3. Install missing dependencies, fetch PX4 v1.18.0-rc1, build everything, verify
./install.sh                     # ~20-30 min the first time (PX4 clone ~2 GB + PX4 build)

# 4. Verify at any time
./scripts/check_system.sh
```

No environment variables need to be set and nothing is added to `~/.bashrc`: every script
sets up its own environment (details in [docs/INSTALLATION.md §I](docs/INSTALLATION.md)).
For interactive ROS 2 tools use `source environment_setup.sh`.

## 5. Run the demo

```bash
./run_demo.sh                    # = ./scripts/run_stage1_demo.sh
```

* **What opens:** the Gazebo GUI (on WSL2 via WSLg) with the disaster world. The camera
  follows the swarm from behind. The terminal shows a colour-coded event console. The
  **dashboard** is at **http://localhost:8080** (live map, UAV table, metrics, events).
* **What happens:** 4 UAVs (`x500_0`–`x500_3`) take off to altitude layers 25/30/35/40 m,
  one becomes relay, the others survey the PoIs. The storyline in §6 plays out; the run takes
  about 5 minutes of mission time (about 6–7 minutes wall clock including startup).
* **Expected end of the console:**
  ```
  [ 25x.xs] [MISSION] MISSION COMPLETE: 7/7 PoIs, mission time 25x.x s (all UAVs landed)
  [RESULT] MISSION_COMPLETE: 7/7 PoIs, completion time 17x s, priority score 1.0
  ...
  [run] RESULT: MISSION_COMPLETE
  ```
  The exit code is 0 only for `MISSION_COMPLETE`. Everything is stopped automatically.
* **Outputs:** `results/latest/` → `report.md`, `summary.json`, `events.json`, and the CSV logs
  `mission`, `communication`, `battery`, `safety`, `failures`, `relay_changes`.

Options: `--headless` (no Gazebo GUI), `--keep` (leave running). Stop everything with
`./scripts/stop_all.sh`. Guide for recording the demonstration video: [docs/DEMO_GUIDE.md](docs/DEMO_GUIDE.md).

## 6. Demonstration scenario (`scenarios/stage1_demo.yaml`)

| Mission time (typical) | What happens |
|---|---|
| 0–18 s | Takeoff; relay chosen by score; PoIs auctioned to the three survey UAVs |
| 18–50 s | Deploy: relay to its computed position, survey UAVs to their PoIs |
| 50–68 s | Surveys; reports arrive over multi-hop routes (e.g. UAV3 → UAV1 → GCS) |
| ≈ 68 s | **The current relay fails** (radio silent, emergency descent). Heartbeat loss detected in about 3 s; the other UAVs are identified as *partitioned*, not failed |
| +6–16 s | Cut-off UAVs elect a **bridge relay** among themselves; routes restored; the GCS adopts it; buffered reports delivered (store-and-forward); network reconfigured |
| ≈ 104 s | **CRITICAL PoI7** appears; assigned within 0.5 s, pre-empting a lower-priority survey |
| ≈ 119 s | **Battery fault** on the busiest survey UAV: sudden drop detected, drain rate estimated, UAV **returns home**, its task is **taken over** by another UAV |
| ≈ 170 s | All 7 PoIs reported → everybody returns home, relay last |
| ≈ 255 s | All surviving UAVs landed on their pads → **MISSION COMPLETE** |

Nothing but the three faults is scripted, and the swarm is never told what was injected. It
detects the failure from missing heartbeats, the degradation from measured delivery ratio, and
the battery fault from telemetry. More scenarios: [docs/MISSION_SCENARIOS.md](docs/MISSION_SCENARIOS.md).

## 7. Expected results

Measured in the two validation runs of the Stage-1 demo (clean restart between them;
`results/reference/`, [results/final_validation_report.md](results/final_validation_report.md)):

| Metric | Run 1 | Run 2 |
|---|---|---|
| Mission result | MISSION_COMPLETE | MISSION_COMPLETE |
| PoIs completed (priority-weighted score) | 7/7 (1.000) | 7/7 (1.000) |
| All PoIs reported / all landed | 171.5 s / 254.5 s | 172.0 s / 255.0 s |
| Packet delivery ratio (end-to-end) | 0.840 | 0.828 |
| Latency mean / p95 / max | 16.8 / 30 / 45.5 ms | 16.7 / 30 / 45.4 ms |
| Connectivity availability | 0.950 | 0.948 |
| Relay failure: detection / network reconfigured | 2.9 s / 16.4 s | 3.3 s / 17.8 s |
| Battery fault: detection / task reassigned | 0.29 s / 14.9 s | 0.26 s / 15.3 s |
| Relay changes | 1 | 1 |
| Collisions / minimum separation | 0 / 9.04 m | 0 / 8.89 m |
| Geofence violations | 0 | 0 |
| Lowest battery (UAV with the fault) | 21.7 % | 21.8 % |

Values vary slightly between runs (timing, random packet loss draws); the storyline and
outcome are the same. Metric definitions: [docs/METRICS.md](docs/METRICS.md).

## 8. Testing

```bash
./scripts/run_tests.sh --unit     # 36 unit tests of the algorithms (seconds)
./scripts/run_tests.sh --sim      # TEST 1-6: single-UAV and four-UAV PX4/Gazebo tests (~10 min)
./scripts/run_tests.sh            # all 21 spec tests + unit tests (~60 min, 9 scenario runs)
./scripts/run_scenario.sh scenarios/scenario_comm_outage.yaml   # any single scenario
```
Verdicts come only from recorded evidence (event log, metrics, CSVs, live ROS graph).
Latest full suite: **22/22 PASS** ([TEST_RESULTS.md](TEST_RESULTS.md)). Reproducibility of the
packaged source: [results/reproducibility_validation.md](results/reproducibility_validation.md).

## 9. Troubleshooting (short list)

| Symptom | Fix |
|---|---|
| `ros2 topic list` shows nothing | `source environment_setup.sh` (project uses `ROS_DOMAIN_ID=42`, localhost discovery) |
| `gz sim` missing after sourcing ROS | expected: ROS Lyrical's vendored `gz` hides it. Scripts run Gazebo in a clean environment; use `./scripts/start_simulation.sh` |
| "simulation already running" / leftover PX4 | `./scripts/stop_all.sh --force` |
| PX4 not built / wrong PX4 commit | `./install.sh` (it refuses to modify a PX4 checkout at a different commit and tells you what to do) |
| No Gazebo window (WSL2) | WSLg must work (`glxinfo -B`); or run `./run_demo.sh --headless` and use the dashboard |
| Port 8080 in use | stop the other program, or `./scripts/run_scenario.sh scenarios/stage1_demo.yaml --no-dashboard` |
| "Permission denied" on scripts | `chmod +x *.sh scripts/*.sh` (install.sh does this) |

Full list with root causes: [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md).

## 10. Project structure

```
.
├── install.sh / run_demo.sh      evaluator entry points (setup.sh = alias of install.sh)
├── environment_setup.sh          source for interactive ros2 tools
├── config/swarm.yaml             every tunable parameter (ranges, weights, thresholds, geofence, …)
├── config/mission_pois.yaml      PoIs
├── scenarios/                    stage1_demo + nominal + 7 fault scenarios (declarative fault injection)
├── src/uav_x_swarm/              ROS 2 package
│   └── uav_x_swarm/core/         pure-Python algorithms (network, relay, allocation, battery, failure, …)
│   └── uav_x_swarm/nodes/        uav_agent, comm_manager, swarm_manager, gcs, scenario_runner,
│                                 metrics_logger, dashboard
│   └── uav_x_swarm/px4/          MAVLink link to PX4
├── launch/swarm.launch.py        launches the ROS 2 stack (N UAVs from config)
├── worlds/disaster_zone.sdf      Gazebo world (generated from config by scripts/tools/generate_world.py)
├── models/                       generated enlarged-visual x500 model (build time)
├── dashboard/index.html          web dashboard
├── scripts/                      build / start / stop / run / test scripts, lib/common.sh, tools/
├── tests/unit, tests/sim         unit tests; simulator tests and evidence checkers
├── docs/                         architecture, installation, reproducibility, demo guide, metrics, …
├── results/                      final validation report, reference runs (runs write results/runs/)
└── external/PX4-Autopilot        created by install.sh (pinned; not in the repository)
```

## 11. Reproducibility

* All versions are pinned and documented ([docs/REPRODUCIBILITY.md](docs/REPRODUCIBILITY.md)):
  PX4 is cloned at tag `v1.18.0-rc1` and its commit is verified; Python packages are pinned in
  `requirements.txt`; apt package versions are listed in `ros2_dependencies.txt`.
* Each run starts from a clean state (fresh PX4 working directories and parameters) and records
  its configuration and results in `results/runs/<run>/`.
* The packaged source archive was extracted into a separate directory, installed, built and run
  end to end with the original tree made inaccessible; see
  [results/reproducibility_validation.md](results/reproducibility_validation.md).
* The installation was also run from a bare `ubuntu:26.04` container image (no ROS, Gazebo or
  Python preinstalled): installation, PX4 build and headless demo to MISSION_COMPLETE passed.
  Not tested on a physical fresh machine.
* Timings vary between runs; in 2 of 18 runs the low-battery storyline did not trigger
  (the mission still completed); see [docs/REPRODUCIBILITY.md §2](docs/REPRODUCIBILITY.md).
* The number of UAVs is `swarm.number_of_uavs` in `config/swarm.yaml`; nothing is written for
  4 UAVs specifically (validated with 4).

License: BSD-3-Clause ([LICENSE](LICENSE)).
