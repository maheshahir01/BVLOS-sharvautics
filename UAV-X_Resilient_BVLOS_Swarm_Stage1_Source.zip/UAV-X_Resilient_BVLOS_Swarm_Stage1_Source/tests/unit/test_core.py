"""Unit tests for the swarm autonomy core (no simulator needed)."""
import math
import random

import pytest

from uav_x_swarm.core.allocation import TaskAllocator
from uav_x_swarm.core.battery import BatteryModel, BatteryParams, BatteryPolicy, DrainEstimator
from uav_x_swarm.core.collision import SeparationMonitor, avoidance_velocity
from uav_x_swarm.core.comm import LinkEstimator, PdrMonitor, classify_link
from uav_x_swarm.core.config import Config
from uav_x_swarm.core.failure import FailureDetector
from uav_x_swarm.core.geofence import BREACH, INSIDE, WARNING, Geofence
from uav_x_swarm.core.lostlink import PeerInfo, elect_bridge, lost_link_action
from uav_x_swarm.core.mission import InvalidTransition, MissionStateMachine
from uav_x_swarm.core.network import GCS, LinkModel, NetworkGraph
from uav_x_swarm.core.priority import PriorityManager
from uav_x_swarm.core.relay import RelayManager
from uav_x_swarm.core.scenario import Scenario
from uav_x_swarm.core.types import (FlightState, Health, LinkStatus, MissionPhase, PoI, Role, TaskStatus,
                                    UAVView)


@pytest.fixture(scope="module")
def cfg():
    return Config.load()


@pytest.fixture
def lm(cfg):
    return LinkModel(cfg["communication"])


def graph_from(lm, positions, est=True):
    g = NetworkGraph()
    names = list(positions)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            l = lm.evaluate(a, b, positions[a], positions[b])
            l.est_quality = l.quality if est else 0.0
            g.set_link(l)
    return g


# ------------------------------------------------------------------ network / routing
def test_link_model_range_and_loss(lm):
    near = lm.evaluate(GCS, "uav1", (0, 0, 0), (50, 0, 0))
    edge = lm.evaluate(GCS, "uav1", (0, 0, 0), (lm.gcs_range - 1, 0, 0))
    out = lm.evaluate(GCS, "uav1", (0, 0, 0), (lm.gcs_range + 1, 0, 0))
    assert near.available and near.loss == pytest.approx(lm.base_loss)
    assert edge.available and edge.loss > near.loss and edge.loss <= lm.base_loss + lm.edge_loss + 1e-9
    assert not out.available and out.quality == 0.0
    uu = lm.evaluate("uav1", "uav2", (0, 0, 0), (lm.uav_range + 1, 0, 0))
    assert not uu.available  # UAV-UAV range is shorter than GCS range
    inj = lm.evaluate(GCS, "uav1", (0, 0, 0), (50, 0, 0), inj_loss_a=0.5)
    assert inj.loss == pytest.approx(1 - (1 - lm.base_loss) * 0.5)
    down = lm.evaluate(GCS, "uav1", (0, 0, 0), (50, 0, 0), radio_b=False)
    assert not down.available


def test_multi_hop_route_uav3_uav2_uav1_gcs(lm):
    # chain along x: only neighbours are within range
    pos = {GCS: (0, 0, 3), "uav1": (200, 0, 25), "uav2": (360, 0, 25), "uav3": (520, 0, 25)}
    g = graph_from(lm, pos)
    path, cost = g.shortest_path("uav3", GCS)
    assert path == ["uav3", "uav2", "uav1", GCS]
    assert cost > 3.0
    # the relay uav1 is a cut vertex for uav2 and uav3
    cuts = g.cut_vertices_for(GCS)
    assert cuts["uav1"] == ["uav2", "uav3"]
    # without uav1 there is no route
    p2, c2 = g.shortest_path("uav3", GCS, exclude={"uav1"})
    assert p2 is None and c2 == math.inf


def test_route_prefers_reliable_path(lm):
    pos = {GCS: (0, 0, 0), "a": (240, 0, 0), "b": (120, 30, 0)}
    g = graph_from(lm, pos)
    direct = g.link("a", GCS)
    path, _ = g.shortest_path("a", GCS)
    # ETX: a lossy long direct link may lose against two short good hops
    two_hop = 1 / g.link("a", "b").est_quality + 1 / g.link("b", GCS).est_quality
    expect = ["a", GCS] if 1 / direct.est_quality <= two_hop else ["a", "b", GCS]
    assert path == expect


def test_link_estimator_tracks_quality():
    est = LinkEstimator(alpha=0.12, rng=random.Random(1))
    k = ("gcs", "uav1")
    for _ in range(200):
        est.update(k, 0.8, True)
    assert est.get(k) == pytest.approx(0.8, abs=0.12)
    for _ in range(30):
        est.update(k, 0.8, False)
    assert est.get(k) < 0.05


def test_classify_link_thresholds(cfg):
    th = cfg["communication.thresholds"]
    assert classify_link(0.99, 20, th) == LinkStatus.GOOD
    assert classify_link(th["warning_pdr"] - 0.05, 20, th) == LinkStatus.WARNING
    assert classify_link(th["degraded_pdr"] - 0.05, 20, th) == LinkStatus.DEGRADED
    assert classify_link(th["failed_pdr"] - 0.05, 20, th) == LinkStatus.FAILED
    assert classify_link(0.99, th["degraded_latency_ms"] + 50, th) == LinkStatus.DEGRADED
    assert classify_link(0.0, 0, th, received_any=False) == LinkStatus.DISCONNECTED
    # hysteresis: recovering to a better class requires clearing its threshold by the margin
    just_above = th["warning_pdr"] + th["recovery_margin"] / 2
    assert classify_link(just_above, 20, th, previous=LinkStatus.WARNING) == LinkStatus.WARNING
    assert classify_link(just_above, 20, th) == LinkStatus.GOOD
    assert classify_link(0.99, 20, th, previous=LinkStatus.WARNING) == LinkStatus.GOOD
    # degradation is reported immediately
    assert classify_link(th["degraded_pdr"] - 0.01, 20, th, previous=LinkStatus.GOOD) == LinkStatus.DEGRADED


def test_pdr_monitor_measures_loss():
    m = PdrMonitor(window_s=6.0, expected_rate_hz=2.0)
    rng = random.Random(3)
    t = 0.0
    for i in range(200):   # 100 s at 2 Hz, 30 % loss
        t = i * 0.5
        if rng.random() > 0.3:
            m.record("uav1", t, 12.0)
    pdr, lat, n = m.stats("uav1", t)
    assert 0.4 <= pdr <= 0.95 and lat == pytest.approx(12.0)
    pdr2, _, n2 = m.stats("uav1", t + 20)
    assert pdr2 == 0.0 and n2 == 0


# ------------------------------------------------------------------ relay
def view(uid, pos, battery=90.0, role=Role.SURVEY, fs=FlightState.HOLD, link=LinkStatus.GOOD, lq=0.95,
         health=Health.OK, queue=None, home=(15, 0), neighbors=None):
    v = UAVView(uid, home)
    v.position, v.battery, v.role, v.flight_state = pos, battery, role, fs
    v.link_status, v.link_quality, v.health = link, lq, health
    v.task_queue = list(queue or [])
    v.neighbors = neighbors or {"x": 1}
    v.last_heartbeat = 0.0
    return v


def test_relay_selection_and_hysteresis(cfg, lm):
    rm = RelayManager(cfg, lm, Geofence.from_cfg(cfg["safety.geofence"]))
    point = (200, 0, 25)
    uavs = {"uav1": view("uav1", (190, 0, 25)), "uav2": view("uav2", (100, 50, 25)),
            "uav3": view("uav3", (300, -80, 25), queue=["POI1", "POI2"])}
    d = rm.select(uavs, None, point, (0, 0, 3))
    assert d.new_relay == "uav1" and d.changed and d.reason == "INITIAL_SELECTION"
    # a slightly better candidate does not displace a healthy relay (hysteresis)
    uavs["uav2"].position = (195, 5, 25)
    d2 = rm.select(uavs, "uav1", point, (0, 0, 3))
    assert d2.new_relay == "uav1" and not d2.changed
    # relay fails -> replaced immediately, with reason
    uavs["uav1"].health = Health.LOST
    d3 = rm.select(uavs, "uav1", point, (0, 0, 3))
    assert d3.new_relay == "uav2" and d3.changed and d3.reason == "LOST"
    # low battery candidates are not eligible
    uavs["uav2"].battery = 20.0
    d4 = rm.select(uavs, "uav1", point, (0, 0, 3))
    assert d4.new_relay == "uav3"


def test_relay_degraded_link_triggers_reselection(cfg, lm):
    rm = RelayManager(cfg, lm, Geofence.from_cfg(cfg["safety.geofence"]))
    uavs = {"uav1": view("uav1", (190, 0, 25), link=LinkStatus.DEGRADED, lq=0.5),
            "uav2": view("uav2", (150, 20, 25), link=LinkStatus.DEGRADED, lq=0.4)}
    d = rm.select(uavs, "uav1", (200, 0, 25), (0, 0, 3))
    assert d.changed and d.new_relay == "uav2" and d.reason.startswith("LINK_")


def _brute_force_direct(far, rmax, plan_r, step=5):
    best = 0
    for x in range(-int(rmax), int(rmax) + 1, step):
        for y in range(-int(rmax), int(rmax) + 1, step):
            if math.hypot(x, y) <= rmax:
                best = max(best, sum(1 for q in far if math.dist((x, y, 25), q) <= plan_r))
    return best


def test_relay_placement(cfg, lm):
    rm = RelayManager(cfg, lm, Geofence.from_cfg(cfg["safety.geofence"]))
    rmax = lm.gcs_range * cfg["relay.placement.gcs_range_margin"]
    plan_r = lm.uav_range * cfg["relay.placement.uav_range_margin"]
    # (a) points that one relay can cover directly -> all covered in one hop
    near = [(300, 50, 25), (320, -40, 25), (280, -100, 25)]
    p = rm.placement((0, 0, 3), near, 25.0)
    assert math.dist(p[:2], (0, 0)) <= rmax + 1e-6
    assert all(math.dist(p, q) <= plan_r for q in near)
    # (b) far, widely spread points: direct coverage is optimal (brute force) and the
    #     remaining points are connected through a neighbouring survey point (multi-hop)
    far = [(380, -20, 25), (350, 90, 25), (340, -140, 25)]
    p = rm.placement((0, 0, 3), far, 25.0)
    direct = sum(1 for q in far if math.dist(p, q) <= plan_r)
    assert direct == _brute_force_direct(far, rmax, plan_r)
    covered = {q for q in far if math.dist(p, q) <= plan_r}
    frontier = set(covered)
    while True:
        new = {q for q in far if q not in covered and any(math.dist(q, r) <= plan_r for r in frontier)}
        if not new:
            break
        covered |= new
        frontier = new
    assert covered == set(far)
    assert rm.relay_needed(far, (0, 0, 3))
    assert not rm.relay_needed([(100, 0, 25)], (0, 0, 3))


# ------------------------------------------------------------------ allocation / priority
def make_alloc(cfg):
    bp = BatteryPolicy(BatteryParams.from_cfg(cfg["battery"]), cfg["flight.cruise_speed_mps"])
    pm = PriorityManager(cfg["mission.priority_weights"], cfg["mission.allocation.preempt_for"])
    return TaskAllocator(cfg, bp, pm), pm


def test_allocation_by_proximity_and_priority(cfg):
    ta, _ = make_alloc(cfg)
    pois = {"A": PoI("A", "a", (250, 100), "MEDIUM"), "B": PoI("B", "b", (250, -100), "MEDIUM")}
    uavs = {"uav2": view("uav2", (200, 90, 25)), "uav3": view("uav3", (200, -90, 25))}
    q, ev = ta.plan(pois, uavs, {"uav2": [], "uav3": []}, {})
    assert q["uav2"] == ["A"] and q["uav3"] == ["B"]
    assert all(p.status == TaskStatus.ASSIGNED for p in pois.values())
    assert len([e for e in ev if e.type == "TASK_ASSIGNED"]) == 2


def test_critical_task_preempts(cfg):
    ta, _ = make_alloc(cfg)
    pois = {"A": PoI("A", "a", (250, 100), "LOW", status=TaskStatus.IN_PROGRESS, assigned_to="uav2"),
            "C": PoI("C", "c", (260, 80), "CRITICAL")}
    uavs = {"uav2": view("uav2", (250, 90, 25), queue=["A"])}
    q, ev = ta.plan(pois, uavs, {"uav2": ["A"]}, {"uav2": "A"})
    assert q["uav2"][0] == "C" and "A" in q["uav2"]
    assert any(e.type == "TASK_PREEMPTED" for e in ev)


def test_energy_infeasible_task_not_assigned(cfg):
    ta, _ = make_alloc(cfg)
    pois = {"FAR": PoI("FAR", "far", (440, 200), "HIGH")}
    # 40 %: flying there and surveying (~14 %) would leave ~26 % < 30 % RTH threshold
    uavs = {"uav2": view("uav2", (20, 0, 25), battery=40.0)}
    q, ev = ta.plan(pois, uavs, {"uav2": []}, {})
    assert q["uav2"] == [] and ev[0].type == "TASK_UNASSIGNABLE"


def test_tasks_released_when_uav_fails_or_returns(cfg):
    ta, _ = make_alloc(cfg)
    pois = {"A": PoI("A", "a", (250, 100), status=TaskStatus.ASSIGNED, assigned_to="uav2"),
            "B": PoI("B", "b", (260, 110), status=TaskStatus.ASSIGNED, assigned_to="uav2")}
    uavs = {"uav2": view("uav2", (240, 90, 25), health=Health.FAILED), "uav3": view("uav3", (230, 80, 25))}
    q, ev = ta.plan(pois, uavs, {"uav2": ["A", "B"], "uav3": []}, {})
    assert q["uav2"] == [] and set(q["uav3"]) == {"A", "B"}
    assert len([e for e in ev if e.type == "TASK_RELEASED"]) == 2
    # a LOST (possibly partitioned) UAV keeps its tasks
    pois2 = {"A": PoI("A", "a", (250, 100), status=TaskStatus.ASSIGNED, assigned_to="uav2")}
    uavs2 = {"uav2": view("uav2", (240, 90, 25), health=Health.LOST), "uav3": view("uav3", (230, 80, 25))}
    q2, _ = ta.plan(pois2, uavs2, {"uav2": ["A"], "uav3": []}, {})
    assert q2["uav2"] == ["A"]


def test_priority_weighted_score(cfg):
    pm = PriorityManager(cfg["mission.priority_weights"], ["HIGH", "CRITICAL"])
    pois = [PoI("a", "", (0, 0), "LOW", status=TaskStatus.COMPLETED), PoI("b", "", (0, 0), "CRITICAL")]
    assert pm.weighted_score(pois) == pytest.approx(1 / 6)
    fence = Geofence.from_cfg(cfg["safety.geofence"])
    ok, _ = pm.validate(PoI("x", "", (1000, 0)), fence, 10)
    assert not ok


# ------------------------------------------------------------------ battery
def test_battery_model_deterministic_and_policy(cfg):
    p = BatteryParams.from_cfg(cfg["battery"])
    b1, b2 = BatteryModel(p, 100), BatteryModel(p, 100)
    for _ in range(600):
        b1.update(0.1, True, 8.0, relay=False, surveying=True)
        b2.update(0.1, True, 8.0, relay=False, surveying=True)
    assert b1.pct == b2.pct < 100
    ground = BatteryModel(p, 100)
    ground.update(10.0, False, 0.0)
    assert ground.pct == 100
    b1.degrade(multiplier=4.0)
    before = b1.pct
    b1.update(1.0, True, 0.0)
    assert before - b1.pct == pytest.approx(4 * p.hover)
    pol = BatteryPolicy(p, 8.0)
    assert pol.rth_threshold(10) == p.rth
    assert pol.rth_threshold(5000) > p.rth
    assert pol.status(p.rth - 1) == "RTH" and pol.status(p.critical - 1) == "CRITICAL"


# ------------------------------------------------------------------ collision / geofence
def test_avoidance_pushes_apart_and_splits_vertically():
    v1, act1 = avoidance_velocity(1, (0, 0, 25), (5, 0, 0), [(2, (6, 0, 25), (-5, 0, 0))], 12, 5, 6)
    v2, act2 = avoidance_velocity(2, (6, 0, 25), (-5, 0, 0), [(1, (0, 0, 25), (5, 0, 0))], 12, 5, 6)
    assert act1 == [2] and act2 == [1]
    # exact head-on: both turn right (opposite lateral directions), never toward each other
    assert v1[1] < 0 and v2[1] > 0
    assert v1[0] <= 1e-9 and v2[0] >= -1e-9
    assert v1[2] > 0 and v2[2] < 0          # lower index climbs, higher descends
    v3, act3 = avoidance_velocity(1, (0, 0, 25), (0, 0, 0), [(2, (50, 0, 25), (0, 0, 0))], 12, 5, 6)
    assert act3 == [] and v3 == (0.0, 0.0, 0.0)


def test_separation_monitor_counts_edges():
    m = SeparationMonitor(min_safe=5.0, collision_dist=1.5)
    assert m.update({"a": (0, 0, 0), "b": (10, 0, 0)}) == []
    ev = m.update({"a": (0, 0, 0), "b": (4, 0, 0)})
    assert ev[0]["type"] == "SEPARATION_VIOLATION"
    assert m.update({"a": (0, 0, 0), "b": (3, 0, 0)}) == []    # same episode
    m.update({"a": (0, 0, 0), "b": (20, 0, 0)})
    m.update({"a": (0, 0, 0), "b": (4, 0, 0)})
    assert m.violations == 2 and m.collisions == 0 and m.min_separation == pytest.approx(3.0)


def test_geofence(cfg):
    f = Geofence.from_cfg(cfg["safety.geofence"])
    assert f.status((100, 0, 25)) == INSIDE
    assert f.status((f.x[1] - 3, 0, 25)) == WARNING
    assert f.status((f.x[1] + 3, 0, 25)) == BREACH
    c = f.clamp((f.x[1] + 50, f.y[0] - 50, 999))
    assert f.contains(c) and c[2] <= f.z[1] - f.clamp_margin


# ------------------------------------------------------------------ failure detection
def test_failure_detector_partition_inference():
    fd = FailureDetector(heartbeat_timeout=3.0, confirm_s=10.0)
    views = {u: view(u, (0, 0, 25)) for u in ("uav1", "uav2", "uav3")}
    views["uav1"].route = ["uav1", "gcs"]
    views["uav2"].route = ["uav2", "uav1", "gcs"]
    views["uav3"].route = ["uav3", "uav2", "uav1", "gcs"]
    for v in views.values():
        v.last_heartbeat = 100.0
    assert fd.update(views, 102.0) == []
    ev = fd.update(views, 104.0)
    lost = {e["uav_id"]: e for e in ev if e["type"] == "HEARTBEAT_LOST"}
    assert set(lost) == {"uav1", "uav2", "uav3"}
    assert lost["uav1"]["partitioned_behind"] is None
    assert lost["uav2"]["partitioned_behind"] == "uav1" and lost["uav3"]["partitioned_behind"] == "uav1"
    ev = fd.update(views, 115.0)
    failed = {e["uav_id"] for e in ev if e["type"] == "UAV_FAILED"}
    assert failed == {"uav1"}            # partitioned UAVs are not declared failed yet
    views["uav2"].last_heartbeat = 116.0
    ev = fd.update(views, 116.5)
    assert any(e["type"] == "RECONNECTED" and e["uav_id"] == "uav2" for e in ev)
    assert views["uav2"].health == Health.OK and views["uav1"].health == Health.FAILED


# ------------------------------------------------------------------ mission state machine
def test_mission_state_machine():
    sm = MissionStateMachine()
    sm.transition(MissionPhase.TAKEOFF, 1, "start")
    with pytest.raises(InvalidTransition):
        sm.transition(MissionPhase.MISSION_COMPLETE, 2, "skip")
    for ph in (MissionPhase.FORMATION, MissionPhase.DEPLOY, MissionPhase.SURVEY, MissionPhase.RECONFIGURING,
               MissionPhase.SURVEY, MissionPhase.RETURN_HOME, MissionPhase.LAND, MissionPhase.MISSION_COMPLETE):
        sm.transition(ph, 3, "ok")
    assert sm.terminal and len(sm.history) == 9


# ------------------------------------------------------------------ scenario
def test_scenario_triggers(tmp_path):
    p = tmp_path / "s.yaml"
    p.write_text("""
name: t
events:
  - {id: a, type: UAV_FAILURE, target: RELAY, trigger: {condition: {completed_pois_gte: 2}, min_time: 30}}
  - {id: b, type: NEW_PRIORITY_POI, poi: POI7, trigger: {after_event: a, delay: 10}}
  - {id: c, type: BATTERY_DEGRADATION, target: uav3, drain_multiplier: 3, time: 100}
""")
    s = Scenario.load(str(p))
    st = {"completed_pois": 1, "relay": "uav1", "uavs": {"uav1": {}, "uav3": {}}}
    assert s.due(40, st) == []
    st["completed_pois"] = 2
    due = s.due(40, st)
    assert [e.id for e in due] == ["a"]
    assert Scenario.resolve_target("RELAY", st) == ["uav1"]
    due[0].fired, due[0].fired_at = True, 40
    assert s.due(45, st) == []
    assert [e.id for e in s.due(50, st)] == ["b"]
    assert [e.id for e in s.due(100, st)] == ["b", "c"]
    assert s.events[2].params["drain_multiplier"] == 3


def test_scenario_rejects_unknown_type(tmp_path):
    p = tmp_path / "bad.yaml"
    p.write_text("events: [{type: EXPLODE, time: 1}]")
    with pytest.raises(ValueError):
        Scenario.load(str(p))


# ------------------------------------------------------------------ lost link / peer election
def test_peer_election_is_consistent():
    rp = (200, 0, 25)
    a = PeerInfo("uav2", 2, (260, 10, 25), 80, False, True, 0.5)
    b = PeerInfo("uav3", 3, (330, -60, 25), 85, False, True, 0.5)
    c = PeerInfo("uav4", 4, (300, 90, 25), 90, False, True, 0.5)
    w_a = elect_bridge(a, [b, c], rp, 250, 30)
    w_b = elect_bridge(b, [a, c], rp, 250, 30)
    w_c = elect_bridge(c, [a, b], rp, 250, 30)
    assert w_a == w_b == w_c == "uav2"        # all agree, closest to the relay point
    act, _ = lost_link_action(is_relay=False, me=a, peers=[b, c], relay_point=rp, gcs_range=250, rth_pct=30,
                              lost_for=10, rth_after=90, has_tasks=True)
    assert act == "BRIDGE"
    act_b, _ = lost_link_action(is_relay=False, me=b, peers=[a, c], relay_point=rp, gcs_range=250, rth_pct=30,
                                lost_for=10, rth_after=90, has_tasks=True)
    assert act_b == "CONTINUE"
    act_r, _ = lost_link_action(is_relay=True, me=a, peers=[], relay_point=rp, gcs_range=250, rth_pct=30,
                                lost_for=10, rth_after=90, has_tasks=False)
    assert act_r == "RECONNECT"
    act_t, _ = lost_link_action(is_relay=False, me=a, peers=[], relay_point=rp, gcs_range=250, rth_pct=30,
                                lost_for=95, rth_after=90, has_tasks=True)
    assert act_t == "RETURN"


# ------------------------------------------------------------------ config
def test_config_scales_to_n_uavs(cfg):
    import copy
    c = Config(copy.deepcopy(cfg.data), cfg.root)
    c.data["swarm"]["number_of_uavs"] = 7
    ids = c.uav_ids()
    homes = c.home_positions()
    assert ids == [f"uav{k}" for k in range(1, 8)] and len(homes) == 7
    assert len({h for h in homes.values()}) == 7                 # unique pads
    alts = [c.cruise_altitude(u) for u in ids]
    assert len(set(alts)) == 7                                    # unique altitude layers


def test_pdr_reset_after_reconnection():
    m = PdrMonitor(window_s=10.0, expected_rate_hz=2.0)
    m.record("uav1", 0.0, 10.0)            # one packet, then a 12 s outage
    pdr, _, _ = m.stats("uav1", 12.0)
    assert pdr == 0.0
    m.reset("uav1", 12.0)
    m.record("uav1", 12.0, 10.0)
    pdr2, _, n2 = m.stats("uav1", 12.4)
    assert n2 == 1 and pdr2 == 1.0         # the outage is not held against the restored link


def test_new_relay_link_grace(cfg, lm):
    rm = RelayManager(cfg, lm, Geofence.from_cfg(cfg["safety.geofence"]))
    uavs = {"uav1": view("uav1", (190, 0, 25), link=LinkStatus.FAILED, lq=0.1),
            "uav2": view("uav2", (150, 20, 25))}
    kept = rm.select(uavs, "uav1", (200, 0, 25), (0, 0, 3), link_grace=True)
    assert kept.new_relay == "uav1" and not kept.changed
    replaced = rm.select(uavs, "uav1", (200, 0, 25), (0, 0, 3), link_grace=False)
    assert replaced.changed and replaced.new_relay == "uav2"


def test_rth_threshold_guarantees_safe_arrival(cfg):
    """Property: a UAV that starts home exactly at the RTH threshold arrives above critical+reserve."""
    p = BatteryParams.from_cfg(cfg["battery"])
    cruise = cfg["flight.cruise_speed_mps"]
    pol = BatteryPolicy(p, cruise)
    for d in (0, 50, 150, 300, 450, 600):
        for mult in (1.0, 1.5, 2.5, 4.0):
            b = BatteryModel(p, pol.rth_threshold(d, mult))
            b.multiplier = mult
            t, dt = 0.0, 0.05
            while t * cruise < d:
                b.update(dt, True, cruise)
                t += dt
            assert b.pct >= p.critical + p.reserve - 1e-6, (d, mult, b.pct)


def test_drain_estimator_detects_fault(cfg):
    p = BatteryParams.from_cfg(cfg["battery"])
    est = DrainEstimator(p)
    batt = 80.0
    t = 0.0
    for _ in range(60):                   # 30 s nominal flight at 8 m/s, 2 Hz telemetry
        batt -= (p.hover + p.per_m * 8.0) * 0.5
        est.update("uav4", t, batt, 8.0, True, False, False)
        t += 0.5
    assert est.get("uav4") == pytest.approx(1.0, abs=0.1)
    step = est.update("uav4", t, batt - 35.0, 8.0, True, False, False)     # cell failure
    assert step == pytest.approx(35.0, abs=0.01)
    batt -= 35.0
    for _ in range(80):                   # then 2.5x drain
        t += 0.5
        batt -= 2.5 * (p.hover + p.per_m * 8.0) * 0.5
        est.update("uav4", t, batt, 8.0, True, False, False)
    assert est.get("uav4") == pytest.approx(2.5, rel=0.15)


def test_late_partition_inference():
    """A UAV that times out slightly before its relay is re-classified as partitioned."""
    fd = FailureDetector(heartbeat_timeout=3.0, confirm_s=10.0)
    views = {u: view(u, (0, 0, 25)) for u in ("uav3", "uav4")}
    views["uav3"].route = ["uav3", "gcs"]
    views["uav4"].route = ["uav4", "uav3", "gcs"]
    views["uav4"].last_heartbeat = 100.0
    views["uav3"].last_heartbeat = 101.0
    ev = fd.update(views, 103.5)                   # only uav4 lost so far: no known cause
    assert ev[0]["uav_id"] == "uav4" and ev[0]["partitioned_behind"] is None
    ev = fd.update(views, 104.5)                   # now the relay uav3 is lost too
    late = [e for e in ev if e.get("late_inference")]
    assert late and late[0]["uav_id"] == "uav4" and late[0]["partitioned_behind"] == "uav3"
    ev = fd.update(views, 115.0)                   # only the root cause is declared failed
    assert {e["uav_id"] for e in ev if e["type"] == "UAV_FAILED"} == {"uav3"}


def _fly(starts, goals, speed=8.0, radius=12.0, min_safe=5.0, gain=6.0, t_end=25.0, dt=0.05, tau=0.5):
    """Kinematic check of the avoidance law: point masses tracking v_nom + v_avoid with lag tau."""
    pos = [list(p) for p in starts]
    vel = [[0.0, 0.0, 0.0] for _ in starts]
    min_sep = math.inf
    t = 0.0
    while t < t_end:
        cmds = []
        for i, p in enumerate(pos):
            to = [goals[i][k] - p[k] for k in range(3)]
            dn = math.sqrt(sum(x * x for x in to)) or 1.0
            v_nom = [x / dn * min(speed, 0.8 * dn) for x in to]
            neigh = [(j + 1, tuple(pos[j]), tuple(vel[j])) for j in range(len(pos)) if j != i]
            v_av, _ = avoidance_velocity(i + 1, tuple(p), tuple(vel[i]), neigh, radius, min_safe, gain)
            cmds.append([v_nom[k] + v_av[k] for k in range(3)])
        for i in range(len(pos)):
            for k in range(3):
                vel[i][k] += (cmds[i][k] - vel[i][k]) * dt / tau
                pos[i][k] += vel[i][k] * dt
        for i in range(len(pos)):
            for j in range(i + 1, len(pos)):
                min_sep = min(min_sep, math.dist(pos[i], pos[j]))
        t += dt
    return min_sep, pos


def test_predictive_avoidance_head_on_keeps_min_safe_distance():
    sep, pos = _fly([(0, 0, 25), (0, 80, 25)], [(0, 80, 25), (0, 0, 25)])
    assert sep >= 5.0, sep
    assert math.dist(pos[0], (0, 80, 25)) < 3 and math.dist(pos[1], (0, 0, 25)) < 3   # both still arrive


def test_predictive_avoidance_crossing_and_three_way():
    sep, _ = _fly([(-40, 0, 25), (0, -40, 25)], [(40, 0, 25), (0, 40, 25)])
    assert sep >= 5.0, sep
    sep3, _ = _fly([(0, 0, 25), (0, 80, 25), (0, 40, 25)], [(0, 80, 25), (0, 0, 25), (0, 40, 25)])
    assert sep3 >= 4.0, sep3      # a hovering UAV in the middle of a head-on pair


def test_no_avoidance_for_parallel_traffic():
    v, act = avoidance_velocity(1, (0, 0, 25), (8, 0, 0), [(2, (0, 20, 25), (8, 0, 0))], 12, 5, 6)
    assert act == [] and v == (0.0, 0.0, 0.0)


def test_isolated_idle_uav_reconnects_instead_of_bridging():
    me = PeerInfo("uav4", 4, (370, 90, 40), 80, False, True, 0.0)
    act, why = lost_link_action(is_relay=False, me=me, peers=[], relay_point=(200, 0, 25), gcs_range=250,
                                rth_pct=30, lost_for=8, rth_after=90, has_tasks=False)
    assert act == "RECONNECT"
    # isolated with a survey in progress: finish it, then reconnect (queued tasks wait)
    act2, _ = lost_link_action(is_relay=False, me=me, peers=[], relay_point=(200, 0, 25), gcs_range=250,
                               rth_pct=30, lost_for=8, rth_after=90, has_tasks=True, has_current=True)
    assert act2 == "CONTINUE_CURRENT"
    act3, _ = lost_link_action(is_relay=False, me=me, peers=[], relay_point=(200, 0, 25), gcs_range=250,
                               rth_pct=30, lost_for=8, rth_after=90, has_tasks=True, has_current=False)
    assert act3 == "RECONNECT"


def test_faded_link_gets_longer_failure_confirmation():
    fd = FailureDetector(heartbeat_timeout=3.0, confirm_s=10.0)
    views = {"uav1": view("uav1", (0, 0, 25), link=LinkStatus.GOOD),
             "uav4": view("uav4", (370, 90, 40), link=LinkStatus.DEGRADED)}
    for v in views.values():
        v.route = [v.uav_id, "gcs"]
        v.last_heartbeat = 100.0
    ev = fd.update(views, 103.5)
    assert {e["uav_id"]: e["fade"] for e in ev} == {"uav1": False, "uav4": True}
    ev = fd.update(views, 114.0)                    # 10.5 s lost: only the abrupt silence is failed
    assert {e["uav_id"] for e in ev if e["type"] == "UAV_FAILED"} == {"uav1"}
    ev = fd.update(views, 134.0)                    # 30.5 s: now the faded one too
    assert {e["uav_id"] for e in ev if e["type"] == "UAV_FAILED"} == {"uav4"}


def test_silence_at_coverage_edge_is_treated_as_fade():
    fd = FailureDetector(heartbeat_timeout=3.0, confirm_s=10.0)
    v = view("uav3", (380, -20, 35), link=LinkStatus.GOOD)
    v.coverage_margin = 0.05                 # last seen almost at the edge of radio range
    v.route, v.last_heartbeat = ["uav3", "uav1", "gcs"], 100.0
    ev = fd.update({"uav3": v}, 103.5)
    assert ev[0]["fade"] is True
    assert fd.update({"uav3": v}, 115.0) == []        # not declared failed after 10 s


def test_swarm_camera_frames_all_uavs_from_behind():
    import os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "scripts", "tools"))
    from swarm_camera import frame_swarm
    hfov, aspect, margin = 75.0, 16 / 9, 0.70
    tan_h = math.tan(math.radians(hfov) / 2)
    tan_v = tan_h / aspect
    for pts in ([(15, 0, 25), (15, -20, 30), (15, 20, 35), (15, 40, 40)],
                [(195, -75, 25), (250, 110, 30), (255, -140, 35), (350, 90, 40)]):
        pose, dist = frame_swarm(pts, 30.0, hfov, aspect, margin)
        cam, pitch = pose[:3], pose[4]
        f = (math.cos(pitch), 0.0, -math.sin(pitch))
        u = (math.sin(pitch), 0.0, math.cos(pitch))
        assert all(cam[0] < p[0] for p in pts)                          # behind the swarm (looking +x)
        for p in pts:
            d = [p[i] - cam[i] for i in range(3)]
            depth = sum(a * b for a, b in zip(d, f))
            assert depth > 0
            assert abs(d[1]) / depth <= tan_h * margin + 1e-6            # inside horizontally, with margin
            assert abs(sum(a * b for a, b in zip(d, u))) / depth <= tan_v * margin + 1e-6
        # minimal: a 10 % closer camera would leave some UAV outside the margin
        closer = [cam[i] + 0.1 * dist * f[i] for i in range(3)]
        worst = max(max(abs(p[1] - closer[1]) / (tan_h * margin),
                        abs(sum((p[i] - closer[i]) * u[i] for i in range(3))) / (tan_v * margin))
                    / sum((p[i] - closer[i]) * f[i] for i in range(3)) for p in pts)
        assert worst > 1.0
