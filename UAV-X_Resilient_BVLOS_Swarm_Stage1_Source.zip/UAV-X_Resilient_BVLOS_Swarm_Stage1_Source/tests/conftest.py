import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "src", "uav_x_swarm"))
os.environ.setdefault("UAVX_ROOT", ROOT)
