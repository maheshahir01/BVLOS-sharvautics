#!/usr/bin/env python3
"""Evaluate the spec tests (TEST 7-21) against the recorded evidence of a scenario run.

Usage: check_run.py <run_dir> <test_id> [<test_id> ...]
Each test prints PASS/FAIL with the evidence it used; exit code 0 only if all pass.
Nothing is inferred: every criterion is read from summary.json, events.json or the CSVs.
"""
from __future__ import annotations

import csv
import json
import math
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


class Run:
    def __init__(self, run_dir: str):
        self.dir = run_dir
        self.summary = json.load(open(os.path.join(run_dir, "summary.json")))
        self.events = json.load(open(os.path.join(run_dir, "events.json")))
        self.meta = json.load(open(os.path.join(run_dir, "meta.json")))
        self.cfg = self.meta["config"]

    def ev(self, *types) -> list[dict]:
        return [e for e in self.events if e["event_type"] in types]

    def csv(self, name: str) -> list[dict]:
        with open(os.path.join(self.dir, f"{name}.csv")) as f:
            return list(csv.DictReader(f))

    @property
    def complete(self) -> bool:
        return self.summary["mission"]["result"] == "MISSION_COMPLETE"

    def injected(self, typ: str) -> list[dict]:
        return [e for e in self.ev("SCENARIO_INJECT") if e["details"].get("inject_type") == typ]


def t_ros_communication(r: Run):
    # all per-UAV onboard topics were recorded by the metrics logger through ROS 2
    uavs = {row["uav_id"] for row in r.csv("battery")}
    n = r.cfg["swarm"]["number_of_uavs"]
    ok = len(uavs) == n
    return ok, f"onboard /uavN/state received from {sorted(uavs)} (expected {n})"


def t_gcs_communication(r: Run):
    pt = r.summary["communication"]["per_type"]
    tel, rep, hb = pt.get("TELEMETRY", {}), pt.get("REPORT", {}), pt.get("GCS_HB", {})
    reports = r.ev("REPORT_RECEIVED")
    ok = tel.get("delivered", 0) > 0 and hb.get("delivered", 0) > 0 and len(reports) > 0
    return ok, (f"UAV->GCS telemetry delivered {tel.get('delivered')}/{tel.get('sent')}, GCS->UAV beacons "
                f"{hb.get('delivered')}/{hb.get('sent')}, survey reports received {len(reports)}")


def t_uav_to_uav(r: Run):
    b = r.summary["communication"]["per_type"].get("BEACON", {})
    relayed = [e for e in r.ev("REPORT_RECEIVED") if (e["details"].get("hops") or 0) >= 2]
    ok = b.get("delivered", 0) > 0 and len(relayed) > 0
    return ok, (f"UAV<->UAV beacons delivered {b.get('delivered')}; reports forwarded through other UAVs "
                f"{len(relayed)}")


def t_multihop(r: Run):
    rows = r.csv("communication")
    hops = [int(x["hops"]) for x in rows if x["hops"] not in ("", "None")]
    max_h = max(hops) if hops else 0
    routes3 = sorted({x["route"] for x in rows if x["hops"] not in ("", "None") and int(x["hops"]) >= 3})
    rep_hops = max([e["details"].get("hops") or 0 for e in r.ev("REPORT_RECEIVED")] or [0])
    ok = max_h >= 3 and rep_hops >= 2
    return ok, f"max route length {max_h} hops (e.g. {routes3[:2]}); max hops of a delivered report {rep_hops}"


def t_relay_selection(r: Run):
    init = [e for e in r.ev("RELAY_CHANGED") if e["details"].get("reason") == "INITIAL_SELECTION"]
    scores = r.ev("RELAY_SCORES")
    ok = len(init) == 1 and len(scores) >= 1
    return ok, (f"initial relay {init[0]['uav_id'] if init else None} selected by score: "
                f"{scores[0]['message'] if scores else 'no scores'}")


def t_relay_failure(r: Run):
    inj = r.injected("UAV_FAILURE")
    if not inj:
        return False, "no UAV_FAILURE injected"
    victim = inj[0]["details"]["targets"][0]
    t0 = inj[0]["t"]
    lost = [e for e in r.ev("HEARTBEAT_LOST") if e["uav_id"] == victim and e["t"] >= t0]
    failed = [e for e in r.ev("UAV_FAILED") if e["uav_id"] == victim]
    new_relay = [e for e in r.ev("RELAY_CHANGED") if e["details"].get("old") == victim and e["t"] >= t0]
    rec = [e for e in r.ev("RECONFIG_COMPLETE") if e["t"] >= t0]
    ok = bool(lost and failed and new_relay and rec) and r.complete
    return ok, (f"relay {victim} failed at mission t={inj[0]['mission_time']}s; heartbeat loss detected after "
                f"{lost[0]['t'] - t0:.1f}s; " if lost else "no detection; ") + \
        (f"new relay {new_relay[0]['uav_id']} ({new_relay[0]['details'].get('reason', '')[:40]}) after "
         f"{new_relay[0]['t'] - t0:.1f}s; " if new_relay else "no new relay; ") + \
        (f"network reconfigured after {rec[0]['t'] - t0:.1f}s; " if rec else "no reconfiguration; ") + \
        f"mission {r.summary['mission']['result']}"


def t_comm_outage(r: Run):
    steps = r.injected("COMM_DEGRADATION_STEP")
    if not steps:
        return False, "no degradation injected"
    victim = steps[0]["details"]["targets"][0]
    t_total = next((e["t"] for e in steps if e["details"].get("packet_loss", 0) >= 1.0), None)
    early = [e for e in r.ev("LINK_WARNING", "LINK_DEGRADED", "LINK_FAILED", "RELAY_INVALID")
             if e["uav_id"] == victim and t_total is not None and steps[0]["t"] <= e["t"] < t_total]
    replaced = [e for e in r.ev("RELAY_CHANGED") if e["details"].get("old") == victim]
    ok = bool(early) and bool(replaced) and replaced[0]["t"] <= (t_total or math.inf) + 30 and r.complete
    return ok, (f"relay {victim} degraded 5%->20%->50%->100%; degradation detected before total loss: "
                f"{[e['event_type'] for e in early][:4]}; relay replaced by "
                f"{replaced[0]['uav_id'] if replaced else None} at mission t="
                f"{replaced[0]['mission_time'] if replaced else None}s (100% loss at "
                f"{next((e['mission_time'] for e in steps if e['details'].get('packet_loss', 0) >= 1.0), None)}s); "
                f"mission {r.summary['mission']['result']}")


def t_packet_loss(r: Run):
    pt = r.summary["communication"]["per_type"]
    tel = pt.get("TELEMETRY", {})
    rep = pt.get("REPORT", {})
    reports = r.ev("REPORT_RECEIVED")
    pois = r.summary["mission"]["pois_total"]
    ok = tel.get("pdr") is not None and tel["pdr"] < 0.95 and len(reports) == pois and r.complete
    return ok, (f"telemetry PDR under 15% injected loss = {tel.get('pdr')}; report packets delivered "
                f"{rep.get('delivered')}/{rep.get('sent')} (retransmissions until ACK); unique reports at GCS "
                f"{len(reports)}/{pois}; mission {r.summary['mission']['result']}")


def t_priority_poi(r: Run):
    new = r.ev("NEW_PRIORITY_POI")
    if not new:
        return False, "no priority PoI announced"
    pid = new[0]["details"]["poi_id"]
    asg = [e for e in r.ev("TASK_ASSIGNED") if e["details"].get("poi_id") == pid]
    done = [e for e in r.ev("POI_COMPLETED") if e["details"].get("poi_id") == pid]
    ok = bool(asg and done) and r.complete
    return ok, (f"{pid} ({new[0]['details'].get('priority')}) announced at t={new[0]['mission_time']}s, assigned "
                f"to {asg[0]['uav_id'] if asg else None} after "
                f"{(asg[0]['t'] - new[0]['t']) if asg else float('nan'):.1f}s, completed at "
                f"t={done[0]['mission_time'] if done else None}s; mission {r.summary['mission']['result']}")


def t_low_battery(r: Run):
    inj = r.injected("BATTERY_DEGRADATION")
    if not inj:
        return False, "no battery fault injected"
    victim = inj[0]["details"]["targets"][0]
    rth = [e for e in r.ev("BATTERY_RTH", "RTH_STARTED") if e["uav_id"] == victim and e["t"] >= inj[0]["t"]
           and ("BATTERY" in e["event_type"] or e["details"].get("reason") == "LOW_BATTERY")]
    landed = [e for e in r.ev("LANDED") if e["uav_id"] == victim]
    crit = r.cfg["battery"]["critical_pct"]
    lowest = r.summary["battery"]["lowest_battery_pct"].get(victim)
    released = [e for e in r.ev("TASK_RELEASED") if e["uav_id"] == victim]
    ok = bool(rth) and bool(landed) and landed[-1]["details"].get("at_home") and lowest is not None \
        and lowest > crit and not r.summary["battery"]["depleted_uavs"] and r.complete
    return ok, (f"{victim}: battery fault at t={inj[0]['mission_time']}s; RTH at t="
                f"{rth[0]['mission_time'] if rth else None}s; landed at home="
                f"{landed[-1]['details'].get('at_home') if landed else None} with lowest battery {lowest}% "
                f"(critical {crit}%); tasks released {len(released)}; mission {r.summary['mission']['result']}")


def t_rth(r: Run):
    landed = {e["uav_id"]: e for e in r.ev("LANDED")}
    # excluded: UAVs whose last health event is UAV_FAILED (a reconnected UAV must land at home)
    last = {}
    for e in r.ev("UAV_FAILED", "RECONNECTED"):
        last[e["uav_id"]] = e["event_type"]
    failed = {u for u, t in last.items() if t == "UAV_FAILED"}
    n = r.cfg["swarm"]["number_of_uavs"]
    expected = [f"uav{k}" for k in range(1, n + 1) if f"uav{k}" not in failed]
    home = all(u in landed and landed[u]["details"].get("at_home") for u in expected)
    ok = home and r.complete
    return ok, "; ".join(f"{u} landed at {tuple(round(x, 1) for x in landed[u]['details']['position'][:2])} "
                         f"home={landed[u]['details'].get('at_home')}" if u in landed else f"{u} NOT landed"
                         for u in expected)


def t_collision(r: Run):
    s = r.summary["safety"]
    coll_d = r.cfg["safety"]["collision_distance_m"]
    ok = s["collision_count"] == 0 and s["avoidance_activations"] >= 1 and \
        (s["minimum_inter_uav_distance_m"] or 0) > coll_d and r.complete
    return ok, (f"collisions {s['collision_count']}, avoidance activations {s['avoidance_activations']}, minimum "
                f"separation {s['minimum_inter_uav_distance_m']} m {s['closest_pair']} (collision < {coll_d} m, "
                f"min safe {r.cfg['safety']['minimum_safe_distance_m']} m, violations "
                f"{s['separation_violations']}); mission {r.summary['mission']['result']}")


def t_geofence(r: Run):
    s = r.summary["safety"]
    gf = r.cfg["safety"]["geofence"]
    goto = r.ev("MANUAL_GOTO")
    uav = goto[0]["uav_id"] if goto else None
    warn = r.ev("GEOFENCE_WARNING")
    ok = s["geofence_violations"] == 0 and (s["geofence_warnings"] >= 1 or warn) and bool(goto) and r.complete
    return ok, (f"{uav} commanded to {goto[0]['details'].get('goal') if goto else None} (outside fence x<={gf['x'][1]}),"
                f" clamped to {goto[0]['details'].get('clamped') if goto else None}; geofence warnings "
                f"{s['geofence_warnings']} (GCS events {len(warn)}), violations {s['geofence_violations']}; "
                f"mission {r.summary['mission']['result']}")


def t_complete(r: Run):
    m = r.summary["mission"]
    ok = r.complete and m["completion_rate"] == 1.0
    return ok, (f"{m['result']}: {m['pois_completed']}/{m['pois_total']} PoIs, completion time "
                f"{m['completion_time_s']} s, duration {m['mission_duration_s']} s, priority score "
                f"{m['priority_weighted_score']}")


def t_failure_recovery_complete(r: Run):
    ok_f, d_f = t_relay_failure(r)
    ok_p, d_p = t_priority_poi(r)
    ok_b, d_b = t_low_battery(r)
    ok_c, d_c = t_complete(r)
    return ok_f and ok_p and ok_b and ok_c, f"[failure] {d_f} | [priority] {d_p} | [battery] {d_b} | [mission] {d_c}"


TESTS = {
    "test_07_ros_communication": t_ros_communication,
    "test_08_gcs_communication": t_gcs_communication,
    "test_09_uav_to_uav_communication": t_uav_to_uav,
    "test_10_multi_hop_routing": t_multihop,
    "test_11_relay_selection": t_relay_selection,
    "test_12_relay_failure": t_relay_failure,
    "test_13_communication_outage": t_comm_outage,
    "test_14_packet_loss": t_packet_loss,
    "test_15_new_priority_poi": t_priority_poi,
    "test_16_low_battery": t_low_battery,
    "test_17_return_to_home": t_rth,
    "test_18_collision_avoidance": t_collision,
    "test_19_geofence": t_geofence,
    "test_20_complete_mission": t_complete,
    "test_21_failure_recovery_mission_completion": t_failure_recovery_complete,
}


def main() -> int:
    run_dir, names = sys.argv[1], sys.argv[2:]
    if not os.path.isfile(os.path.join(run_dir, "summary.json")):
        for n in names:
            print(f"  FAIL  {n}: run produced no summary.json ({run_dir})")
        return 1
    r = Run(run_dir)
    out = {}
    all_ok = True
    for n in names:
        try:
            ok, detail = TESTS[n](r)
        except Exception as exc:  # a malformed record is a failure, not a crash
            ok, detail = False, f"checker error: {type(exc).__name__}: {exc}"
        all_ok &= bool(ok)
        out[n] = {"pass": bool(ok), "detail": detail, "run": os.path.basename(run_dir)}
        print(f"  {'PASS' if ok else 'FAIL'}  {n}: {detail}", flush=True)
    with open(os.path.join(run_dir, "checks.json"), "w") as f:
        json.dump(out, f, indent=2)
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
