#!/usr/bin/env python3
"""Record the Gazebo GUI camera and the UAV poses during a run and check the framing.

For every sample, each UAV is projected into the image using the camera pose from
/gui/camera/pose, the configured horizontal FOV and the real 3D-view size; the sample
passes if all UAVs are inside the image (and in front of the camera). Also reports
whether the camera is behind the swarm (camera x < every UAV x) and its distance.
Usage: camera_check.py --out <csv> --duration <s> [--width 777 --height 952 --hfov 75]
"""
import argparse
import csv
import math
import time

from gz.msgs.pose_pb2 import Pose
from gz.msgs.pose_v_pb2 import Pose_V
from gz.transport import Node


def quat_rot(q, v):  # rotate v by quaternion (w, x, y, z)
    w, x, y, z = q
    tx, ty, tz = 2 * (y * v[2] - z * v[1]), 2 * (z * v[0] - x * v[2]), 2 * (x * v[1] - y * v[0])
    return (v[0] + w * tx + y * tz - z * ty, v[1] + w * ty + z * tx - x * tz, v[2] + w * tz + x * ty - y * tx)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--duration", type=float, default=300)
    ap.add_argument("--world", default="disaster_zone")
    ap.add_argument("--models", nargs="+", default=[f"x500_{i}" for i in range(4)])
    ap.add_argument("--width", type=int, default=777)
    ap.add_argument("--height", type=int, default=952)
    ap.add_argument("--hfov", type=float, default=75.0)
    a = ap.parse_args()
    cam, uav = {}, {}

    def on_cam(m):
        cam["p"] = (m.position.x, m.position.y, m.position.z)
        cam["q"] = (m.orientation.w, m.orientation.x, m.orientation.y, m.orientation.z)

    def on_pose(m):
        for p in m.pose:
            if p.name in a.models:
                uav[p.name] = (p.position.x, p.position.y, p.position.z)

    n = Node()
    n.subscribe(Pose, "/gui/camera/pose", on_cam)
    n.subscribe(Pose_V, f"/world/{a.world}/pose/info", on_pose)
    tan_h = math.tan(math.radians(a.hfov) / 2)
    tan_v = tan_h * a.height / a.width
    rows, t0 = [], time.time()
    while time.time() - t0 < a.duration:
        time.sleep(0.5)
        if "p" not in cam or len(uav) < len(a.models):
            continue
        fwd, left, up = quat_rot(cam["q"], (1, 0, 0)), quat_rot(cam["q"], (0, 1, 0)), quat_rot(cam["q"], (0, 0, 1))
        worst, inside = 0.0, True
        for m in a.models:
            d = tuple(u - c for u, c in zip(uav[m], cam["p"]))
            depth = sum(x * y for x, y in zip(d, fwd))
            if depth <= 0.5:
                inside, worst = False, 9.9
                continue
            nx = abs(sum(x * y for x, y in zip(d, left))) / (depth * tan_h)   # 1.0 = image edge
            ny = abs(sum(x * y for x, y in zip(d, up))) / (depth * tan_v)
            worst = max(worst, nx, ny)
            inside &= nx <= 1.0 and ny <= 1.0
        cen = [sum(uav[m][i] for m in a.models) / len(a.models) for i in range(3)]
        rows.append({"t": round(time.time() - t0, 1), "cam_x": round(cam["p"][0], 1), "cam_y": round(cam["p"][1], 1),
                     "cam_z": round(cam["p"][2], 1), "dist_to_centroid": round(math.dist(cam["p"], cen), 1),
                     "behind": int(cam["p"][0] < min(uav[m][0] for m in a.models)),
                     "all_inside": int(inside), "worst_edge_ratio": round(worst, 3),
                     "uavs": ";".join(f"{m}:{uav[m][0]:.0f},{uav[m][1]:.0f},{uav[m][2]:.0f}" for m in a.models)})
    with open(a.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    ok = [r for r in rows if r["all_inside"]]
    print(f"samples {len(rows)}; all 4 UAVs inside image: {len(ok)}/{len(rows)} "
          f"({100 * len(ok) / len(rows):.1f}%); behind swarm: {sum(r['behind'] for r in rows)}/{len(rows)}; "
          f"worst edge ratio {max(r['worst_edge_ratio'] for r in rows):.2f} (1.0 = image edge); "
          f"camera-centroid distance min/median/max {min(r['dist_to_centroid'] for r in rows):.0f}/"
          f"{sorted(r['dist_to_centroid'] for r in rows)[len(rows) // 2]:.0f}/"
          f"{max(r['dist_to_centroid'] for r in rows):.0f} m")


if __name__ == "__main__":
    main()
