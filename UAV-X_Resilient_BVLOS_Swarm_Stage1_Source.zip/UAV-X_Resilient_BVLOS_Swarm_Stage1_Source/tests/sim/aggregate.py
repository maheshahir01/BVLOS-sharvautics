#!/usr/bin/env python3
"""Aggregate a test-suite directory into results/tests/<suite>/test_results.json and TEST_RESULTS.md.

A test that was evaluated more than once (e.g. TEST 17 in several scenarios) passes only
if every evaluation passed. Tests that were not executed are reported as NOT RUN.
"""
from __future__ import annotations

import datetime
import glob
import json
import os
import platform
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

TITLES = {
    "unit_tests": "Unit tests (core algorithms)",
    "test_01_px4_startup": "TEST 1: Single UAV PX4 startup",
    "test_02_takeoff": "TEST 2: Single UAV takeoff",
    "test_03_waypoints": "TEST 3: Single UAV waypoint",
    "test_04_landing": "TEST 4: Single UAV landing",
    "test_05_four_uav_startup": "TEST 5: Four UAV startup",
    "test_06_independent_control": "TEST 6: Four UAV independent control",
    "test_07_ros_communication": "TEST 7: ROS communication",
    "test_08_gcs_communication": "TEST 8: GCS communication",
    "test_09_uav_to_uav_communication": "TEST 9: UAV-to-UAV communication",
    "test_10_multi_hop_routing": "TEST 10: Multi-hop routing",
    "test_11_relay_selection": "TEST 11: Relay selection",
    "test_12_relay_failure": "TEST 12: Relay failure",
    "test_13_communication_outage": "TEST 13: Communication outage",
    "test_14_packet_loss": "TEST 14: Packet loss",
    "test_15_new_priority_poi": "TEST 15: New priority PoI",
    "test_16_low_battery": "TEST 16: Low battery",
    "test_17_return_to_home": "TEST 17: Return-to-home",
    "test_18_collision_avoidance": "TEST 18: Collision avoidance",
    "test_19_geofence": "TEST 19: Geo-fence",
    "test_20_complete_mission": "TEST 20: Complete mission",
    "test_21_failure_recovery_mission_completion": "TEST 21: Failure + recovery + mission completion",
}


def versions() -> dict:
    def sh(cmd):
        try:
            return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=20).stdout.strip()
        except Exception:
            return ""
    return {
        "os": sh("lsb_release -ds"), "kernel": platform.release(),
        "ros": os.environ.get("ROS_DISTRO") or sh("ls /opt/ros | head -1"),
        "gazebo": sh("env -i PATH=/usr/bin:/bin gz sim --versions 2>/dev/null | head -1"),
        "px4": sh(f"git -C {ROOT}/external/PX4-Autopilot describe --tags 2>/dev/null"),
        "python": platform.python_version(),
    }


def main() -> int:
    out = sys.argv[1]
    # --partial: a subset of the suite was run on purpose (--unit / --sim / --scenarios);
    # tests outside that subset are NOT RUN and do not make the run fail.
    partial = "--partial" in sys.argv[2:]
    results: dict[str, list] = {}

    def add(name, ok, detail, src):
        results.setdefault(name, []).append({"pass": bool(ok), "detail": detail, "source": src})

    for f in glob.glob(os.path.join(out, "unit.json")):
        for k, v in json.load(open(f)).items():
            add(k, v["pass"], v["detail"], "tests/unit")
    for sub in ("single_uav", "four_uav"):
        f = os.path.join(out, sub, "results.json")
        if os.path.isfile(f):
            for k, v in json.load(open(f)).items():
                add(k, v["pass"], v["detail"], f"tests/sim/{sub}")
    live = os.path.join(out, "ros_live.json")
    if os.path.isfile(live):
        v = json.load(open(live))
        add("test_07_ros_communication", v["pass"], "live graph: " + v["detail"], "tests/sim/ros_live_check.py")
    for f in sorted(glob.glob(os.path.join(out, "*.checks.json"))):
        scen = os.path.basename(f).replace(".checks.json", "")
        for k, v in json.load(open(f)).items():
            add(k, v["pass"], v["detail"], f"scenario {scen} (results/runs/{v.get('run', '')})")

    final = {}
    for name in TITLES:
        runs = results.get(name)
        if not runs:
            final[name] = {"status": "NOT RUN", "evidence": []}
        else:
            final[name] = {"status": "PASS" if all(r["pass"] for r in runs) else "FAIL", "evidence": runs}
    ver = versions()
    doc = {"suite": os.path.basename(out), "generated": datetime.datetime.now().isoformat(timespec="seconds"),
           "versions": ver, "results": final}
    json.dump(doc, open(os.path.join(out, "test_results.json"), "w"), indent=2)

    n_pass = sum(1 for v in final.values() if v["status"] == "PASS")
    n_fail = sum(1 for v in final.values() if v["status"] == "FAIL")
    n_nr = sum(1 for v in final.values() if v["status"] == "NOT RUN")
    lines = ["# Test Results", "",
             f"Suite `{doc['suite']}`, generated {doc['generated']} by `./scripts/run_tests.sh`.", "",
             f"**{n_pass} PASS, {n_fail} FAIL, {n_nr} NOT RUN** (of {len(final)}).", "",
             "Environment: " + ", ".join(f"{k}: {v}" for k, v in ver.items()), "",
             "A test is PASS only if every execution of it passed. Evidence comes from the recorded run",
             "data (results/runs/<run>/summary.json, events.json, CSVs) or the live checks.", "",
             "| Test | Status | Evidence |", "|---|---|---|"]
    for name, title in TITLES.items():
        v = final[name]
        ev = " <br> ".join(f"*{r['source']}*: {r['detail']}".replace("|", "/") for r in v["evidence"]) or "–"
        lines.append(f"| {title} | **{v['status']}** | {ev} |")
    md = "\n".join(lines) + "\n"
    open(os.path.join(out, "TEST_RESULTS.md"), "w").write(md)
    if n_nr == 0 or os.environ.get("UAVX_WRITE_TEST_RESULTS"):
        open(os.path.join(ROOT, "TEST_RESULTS.md"), "w").write(md)
    print(f"\n{n_pass} PASS, {n_fail} FAIL, {n_nr} NOT RUN -> {os.path.join(out, 'TEST_RESULTS.md')}")
    if partial:
        return 0 if n_fail == 0 and n_pass > 0 else 1
    return 0 if n_fail == 0 and n_nr == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
