#!/usr/bin/env python3
"""TEST 5-6: N PX4 instances alive, uniquely addressed, and independently controllable.

TEST 5 (startup): every UAV k answers on UDP 14540+k-1 with MAV_SYS_ID k only,
       has a valid local position, passes pre-arm checks, and its Gazebo model
       x500_<k-1> sits on its configured home pad (Gazebo ground truth).
TEST 6 (independent control): all UAVs take off to different altitudes at the
       same time; then ONLY UAV2 is commanded 15 m East. Gazebo ground truth must
       show UAV2 moved +15 m in world x (East) while all others stayed put.
       This also verifies the PX4 NED -> world ENU mapping.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "src", "uav_x_swarm"))
sys.path.insert(0, os.path.join(ROOT, "scripts", "tools"))
from uav_x_swarm.px4.link import PX4Link  # noqa: E402
from sim_plan import home_positions  # noqa: E402
import yaml  # noqa: E402
from pymavlink import mavutil  # noqa: E402

ML = mavutil.mavlink


def gz_pose(model: str) -> tuple[float, float, float] | None:
    env = {"PATH": "/usr/bin:/bin", "HOME": os.environ["HOME"],
           "GZ_IP": os.environ.get("GZ_IP", "127.0.0.1"),
           "GZ_PARTITION": os.environ.get("GZ_PARTITION", "uavx")}
    try:
        out = subprocess.run(["gz", "model", "-m", model, "-p"], env=env, capture_output=True,
                             text=True, timeout=15).stdout
    except subprocess.TimeoutExpired:
        return None
    m = re.search(r"Pose \[ XYZ \(m\) \] \[ RPY \(rad\) \]:\s*\[([-\d.e ]+)\]", out)
    if not m:
        return None
    x, y, z = (float(v) for v in m.group(1).split())
    return (x, y, z)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(ROOT, "config", "swarm.yaml"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "tests", "four_uav"))
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    cfg = yaml.safe_load(open(a.config))
    homes = home_positions(cfg)
    n = len(homes)
    results: dict = {}

    def result(name, ok, detail):
        results[name] = {"pass": bool(ok), "detail": detail}
        print(f"  {'PASS' if ok else 'FAIL'}  {name}: {detail}", flush=True)

    links = {k: PX4Link(14540 + k - 1, k) for k in range(1, n + 1)}
    try:
        # ------------------------------------------------------------ TEST 5
        t0 = time.monotonic()
        while time.monotonic() - t0 < 90:
            tels = {k: l.telemetry() for k, l in links.items()}
            if all(l.connected() and t.local_valid and t.prearm_ok for (k, l), t in zip(links.items(), tels.values())):
                break
            time.sleep(0.5)
        details, ok5 = [], True
        for k, link in links.items():
            t = link.telemetry()
            gp = gz_pose(f"x500_{k - 1}")
            hx, hy = homes[k - 1]
            on_pad = gp is not None and math.hypot(gp[0] - hx, gp[1] - hy) < 1.0
            foreign = sorted(link._foreign_sysids)
            good = link.connected() and t.local_valid and t.prearm_ok and on_pad and not foreign
            ok5 &= good
            details.append(f"uav{k}: sysid={k} udp={14540 + k - 1} hb={link.connected()} "
                           f"prearm={t.prearm_ok} gz_model=x500_{k - 1}@"
                           f"{'(%.1f,%.1f)' % gp[:2] if gp else 'MISSING'} home=({hx},{hy}) "
                           f"foreign_sysids={foreign or 'none'}")
        result("test_05_four_uav_startup", ok5, " | ".join(details))
        if not ok5:
            return 1

        # ------------------------------------------------------------ TEST 6
        alts = {k: 10.0 + 4.0 * (k - 1) for k in links}
        home_ned = {k: links[k].telemetry().ned for k in links}
        targets = {k: [home_ned[k][0], home_ned[k][1], home_ned[k][2] - alts[k]] for k in links}

        def stream(duration, cond=None):
            t_end = time.monotonic() + duration
            while time.monotonic() < t_end:
                for k, l in links.items():
                    l.send_setpoint_ned(*targets[k], use_velocity=False)
                if cond and cond():
                    return True
                time.sleep(0.05)
            return cond() if cond else True

        stream(1.0)
        t_arm = time.monotonic()
        while time.monotonic() - t_arm < 25:
            done = True
            for k, l in links.items():
                t = l.telemetry()
                if not t.is_offboard:
                    l.set_offboard(); done = False
                elif not t.armed:
                    l.arm(); done = False
            if done:
                break
            stream(0.3)
        up = stream(40, lambda: all(abs(links[k].telemetry().ned[2] - targets[k][2]) < 0.6 for k in links))
        stream(3)
        before = {k: gz_pose(f"x500_{k - 1}") for k in links}
        # command ONLY uav2: 15 m East  (NED: +e)
        mover = 2 if n >= 2 else 1
        targets[mover][1] += 15.0
        moved = stream(30, lambda: math.dist(links[mover].telemetry().ned, targets[mover]) < 0.8)
        stream(3)
        after = {k: gz_pose(f"x500_{k - 1}") for k in links}
        det, ok6 = [f"all airborne={up}"], up and moved
        for k in links:
            b, a_ = before[k], after[k]
            if b is None or a_ is None:
                ok6 = False; det.append(f"uav{k}: gz pose missing"); continue
            dx, dy, dz = a_[0] - b[0], a_[1] - b[1], a_[2] - b[2]
            alt_ok = abs(a_[2] - alts[k]) < 1.5
            if k == mover:
                good = abs(dx - 15.0) < 1.5 and abs(dy) < 1.5 and alt_ok
            else:
                good = math.hypot(dx, dy) < 1.0 and alt_ok
            ok6 &= good
            det.append(f"uav{k}: world dx={dx:+.2f} dy={dy:+.2f} alt={a_[2]:.1f}m (cmd {alts[k]:.0f}m) "
                       f"{'MOVED' if k == mover else 'held'} {'ok' if good else 'WRONG'}")
        result("test_06_independent_control", ok6, " | ".join(det))

        # land all
        for l in links.values():
            l.land()
        t_l = time.monotonic()
        while time.monotonic() - t_l < 60:
            if all(l.telemetry().landed_state == ML.MAV_LANDED_STATE_ON_GROUND and not l.telemetry().armed
                   for l in links.values()):
                break
            time.sleep(0.5)
        landed = all(not l.telemetry().armed for l in links.values())
        print(f"  info: all vehicles landed and disarmed = {landed}", flush=True)
        return 0 if (ok5 and ok6 and landed) else 1
    finally:
        for l in links.values():
            l.close()
        with open(os.path.join(a.out, "results.json"), "w") as f:
            json.dump(results, f, indent=2)


if __name__ == "__main__":
    rc = main()
    print("RESULT:", "PASS" if rc == 0 else "FAIL", flush=True)
    sys.exit(rc)
