#!/usr/bin/env python3
"""TEST 1-4: single PX4 SITL vehicle startup, takeoff, waypoints, landing.

Talks to one running PX4 instance through pymavlink (offboard control) and
records telemetry. Every verdict is derived from vehicle telemetry; nothing is assumed.

Usage: single_uav_flight.py --instance 0 --out results/tests/single_uav
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src", "uav_x_swarm"))
from uav_x_swarm.px4.link import PX4Link  # noqa: E402
from pymavlink import mavutil  # noqa: E402

ML = mavutil.mavlink


class Recorder:
    def __init__(self, path: str):
        self.f = open(path, "w", newline="")
        self.w = csv.writer(self.f)
        self.w.writerow(["t", "phase", "armed", "mode", "landed_state", "n", "e", "d", "vn", "ve", "vd"])
        self.t0 = time.monotonic()

    def log(self, link: PX4Link, phase: str):
        t = link.telemetry()
        self.w.writerow([f"{time.monotonic() - self.t0:.2f}", phase, int(t.armed), t.mode_name,
                         t.landed_state, *(f"{v:.3f}" for v in t.ned), *(f"{v:.3f}" for v in t.ned_vel)])

    def close(self):
        self.f.close()


def run(instance: int, out_dir: str, alt: float, timeout: float) -> dict:
    os.makedirs(out_dir, exist_ok=True)
    port, sysid = 14540 + instance, instance + 1
    results: dict[str, dict] = {}
    rec = Recorder(os.path.join(out_dir, "telemetry.csv"))
    link = PX4Link(port, sysid)

    def result(name, ok, detail):
        results[name] = {"pass": bool(ok), "detail": detail}
        print(f"  {'PASS' if ok else 'FAIL'}  {name}: {detail}", flush=True)
        return ok

    def stream_until(target_ned, cond, phase, limit):
        t0 = time.monotonic()
        while time.monotonic() - t0 < limit:
            link.send_setpoint_ned(*target_ned, use_velocity=False)
            rec.log(link, phase)
            if cond(link.telemetry()):
                return True, time.monotonic() - t0
            time.sleep(0.05)
        return False, limit

    try:
        # ---------------- TEST 1: startup / telemetry
        t0 = time.monotonic()
        while time.monotonic() - t0 < timeout and not link.connected():
            time.sleep(0.2)
        hb = link.connected()
        t_hb = time.monotonic() - t0
        while time.monotonic() - t0 < timeout:
            tel = link.telemetry()
            if tel.local_valid and tel.prearm_ok:
                break
            time.sleep(0.5)
        tel = link.telemetry()
        if not result("test_01_px4_startup", hb and tel.local_valid,
                      f"heartbeat from sysid {sysid} on udp {port} after {t_hb:.1f}s, "
                      f"local_position_valid={tel.local_valid}, prearm_ok={tel.prearm_ok}, mode={tel.mode_name}"):
            return results
        home = tel.ned

        # ---------------- TEST 2: arm + offboard takeoff
        target = (home[0], home[1], home[2] - alt)
        for _ in range(20):  # PX4 requires setpoints before accepting OFFBOARD
            link.send_setpoint_ned(home[0], home[1], home[2], use_velocity=False)
            time.sleep(0.05)
        t_arm = time.monotonic()
        while time.monotonic() - t_arm < 20:
            tel = link.telemetry()
            if tel.armed and tel.is_offboard:
                break
            link.send_setpoint_ned(home[0], home[1], home[2], use_velocity=False)
            if not tel.is_offboard:
                link.set_offboard()
            elif not tel.armed:
                link.arm()
            time.sleep(0.25)
        tel = link.telemetry()
        armed_ok = tel.armed and tel.is_offboard
        ok, dt = stream_until(target, lambda t: abs(t.ned[2] - target[2]) < 0.5, "takeoff", 40) if armed_ok else (False, 0)
        tel = link.telemetry()
        result("test_02_takeoff", armed_ok and ok,
               f"armed={tel.armed} mode={tel.mode_name} altitude={-tel.ned[2]:.2f} m (target {alt} m) in {dt:.1f}s")
        if not ok:
            return results

        # ---------------- TEST 3: waypoints
        wps = [(home[0] + 20.0, home[1], target[2]), (home[0] + 20.0, home[1] + 20.0, target[2])]
        wp_ok = True
        details = []
        for i, wp in enumerate(wps, 1):
            ok, dt = stream_until(wp, lambda t, wp=wp: math.dist(t.ned, wp) < 1.0, f"wp{i}", 40)
            ok2, _ = stream_until(wp, lambda t: math.hypot(*t.ned_vel) < 0.5, f"wp{i}_settle", 10)
            err = math.dist(link.telemetry().ned, wp)
            details.append(f"WP{i} {'reached' if ok else 'NOT reached'} in {dt:.1f}s (final error {err:.2f} m)")
            wp_ok &= ok
        result("test_03_waypoints", wp_ok, "; ".join(details))

        # ---------------- TEST 4: landing
        link.land()
        t_l = time.monotonic()
        landed = False
        while time.monotonic() - t_l < 60:
            rec.log(link, "land")
            tel = link.telemetry()
            if tel.landed_state == ML.MAV_LANDED_STATE_ON_GROUND and not tel.armed:
                landed = True
                break
            time.sleep(0.1)
        tel = link.telemetry()
        result("test_04_landing", landed,
               f"landed_state={tel.landed_state} armed={tel.armed} mode={tel.mode_name} "
               f"altitude={-(tel.ned[2] - home[2]):.2f} m after {time.monotonic() - t_l:.1f}s")
        return results
    finally:
        rec.close()
        link.close()
        with open(os.path.join(out_dir, "results.json"), "w") as f:
            json.dump(results, f, indent=2)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--instance", type=int, default=0)
    ap.add_argument("--out", default="results/tests/single_uav")
    ap.add_argument("--alt", type=float, default=15.0)
    ap.add_argument("--timeout", type=float, default=90.0)
    a = ap.parse_args()
    print(f"Single-UAV flight test (PX4 instance {a.instance})", flush=True)
    res = run(a.instance, a.out, a.alt, a.timeout)
    expected = ["test_01_px4_startup", "test_02_takeoff", "test_03_waypoints", "test_04_landing"]
    ok = all(res.get(k, {}).get("pass") for k in expected)
    print("RESULT:", "PASS" if ok else "FAIL", flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
