#!/usr/bin/env python3
"""TEST 7 (live part): while the swarm stack runs, verify the ROS 2 graph.

* every expected node is present (ros2 node list equivalent),
* every required per-UAV topic exists AND delivers messages:
  /uavN/{state,position,velocity,battery,role,communication,mission_status}
* the GCS/swarm topics deliver messages: /swarm/status, /network/state, /events
Writes a JSON verdict to --out.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import rclpy
from geometry_msgs.msg import PointStamped, Vector3Stamped
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import BatteryState
from std_msgs.msg import String

TOPIC_TYPES = {"state": String, "position": PointStamped, "velocity": Vector3Stamped, "battery": BatteryState,
               "role": String, "communication": String, "mission_status": String}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--uavs", type=int, default=4)
    # /events is event-driven (published only when something happens), so the window must be
    # long enough to contain a mission event; the check ends as soon as every topic was seen.
    ap.add_argument("--timeout", type=float, default=60.0)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    rclpy.init()
    node = Node("ros_live_check")
    got: dict[str, int] = {}
    subs = []
    topics = []
    for k in range(1, a.uavs + 1):
        for name, typ in TOPIC_TYPES.items():
            topics.append((f"/uav{k}/{name}", typ))
    topics += [("/swarm/status", String), ("/network/state", String), ("/events", String)]
    latched = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE, durability=DurabilityPolicy.TRANSIENT_LOCAL)
    for t, typ in topics:
        got[t] = 0
        qos = latched if t.endswith("/role") else 10

        def cb(_msg, t=t):
            got[t] += 1
        subs.append(node.create_subscription(typ, t, cb, qos))
    t_end = time.time() + a.timeout
    while time.time() < t_end and not all(v > 0 for v in got.values()):
        rclpy.spin_once(node, timeout_sec=0.2)
    names = {f"{ns.rstrip('/')}/{n}" if ns != "/" else f"/{n}" for n, ns in node.get_node_names_and_namespaces()}
    expected_nodes = {"/comm_manager", "/gcs", "/swarm_manager", "/metrics_logger"} | \
        {f"/uav{k}/uav_agent" for k in range(1, a.uavs + 1)}
    missing_nodes = sorted(expected_nodes - names)
    missing_topics = sorted(t for t, n in got.items() if n == 0)
    event_publishers = node.count_publishers("/events")
    # comm_manager, gcs, swarm_manager and every uav_agent publish events
    ok = not missing_nodes and not missing_topics and event_publishers >= 3 + a.uavs
    verdict = {"pass": ok, "nodes_seen": sorted(names), "missing_nodes": missing_nodes,
               "topics_checked": len(got), "missing_topics": missing_topics,
               "detail": f"{len(expected_nodes) - len(missing_nodes)}/{len(expected_nodes)} expected nodes present; "
                         f"{len(got) - len(missing_topics)}/{len(got)} topics delivered messages; "
                         f"/events publishers: {event_publishers}"
                         + (f"; missing nodes {missing_nodes}" if missing_nodes else "")
                         + (f"; silent topics {missing_topics}" if missing_topics else "")}
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as f:
        json.dump(verdict, f, indent=2)
    print(f"  {'PASS' if ok else 'FAIL'}  test_07_ros_communication (live): {verdict['detail']}", flush=True)
    node.destroy_node()
    rclpy.try_shutdown()
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
