// Runtime check of dashboard/index.html rendering logic against a real /api/state snapshot.
// Usage: node dashboard_render_check.js <dash.js> <state.json>
const fs = require("fs");
const [jsPath, statePath] = process.argv.slice(2);
const calls = { fillText: 0, arc: 0, lineTo: 0 };
const ctx = new Proxy({}, { get: (t, k) => (k in t ? t[k] : (...a) => { if (k in calls) calls[k]++; }),
                            set: (t, k, v) => { t[k] = v; return true; } });
const els = {};
global.document = { getElementById: id => (els[id] ||= { id, textContent: "", innerHTML: "", style: {},
                                                          width: 1040, height: 880, getContext: () => ctx }) };
global.fetch = async () => { throw new Error("offline"); };
global.setTimeout = () => 0;
let src = fs.readFileSync(jsPath, "utf8").replace(/\npoll\(\);\s*$/, "\n");
eval(src + "\nglobal.__render = render;");
const state = JSON.parse(fs.readFileSync(statePath, "utf8"));
global.__render(state);
const rows = (els.uavs.innerHTML.match(/<tr>/g) || []).length;
const tiles = (els.tiles.innerHTML.match(/class="tile"/g) || []).length;
if (rows !== state.config.uav_ids.length || tiles < 12 || calls.arc < 4 || !els.phase.textContent)
  { console.error("FAIL", { rows, tiles, calls, phase: els.phase.textContent }); process.exit(1); }
console.log(`PASS dashboard render: phase=${els.phase.textContent}, ${rows} UAV rows, ${tiles} metric tiles, ` +
            `${calls.arc} map circles, ${calls.fillText} labels, events=${(state.events || []).length}`);
